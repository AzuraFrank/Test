interface GopayConfig {
  userId: string
  clientKey: string
  serverKey: string
  phoneNumber: string
  environment: "sandbox" | "production"
}

interface GopayBalance {
  balance: number
  availableBalance: number
  pendingBalance: number
  currency: string
  timestamp: string
}

interface GopayTransaction {
  transactionId: string
  orderId: string
  amount: number
  status: string
  transactionTime: string
  settlementTime?: string
  paymentType: string
  grossAmount: number
  fraudStatus?: string
}

export class GopayClient {
  private config: GopayConfig
  private baseUrl: string

  constructor() {
    this.config = {
      userId: "G082083595",
      clientKey: "Mid-client-Xv_CpPRaXK_R-dj0",
      serverKey: "Mid-server-Gbr3kjXtYY88uEdxlD6LdazR",
      phoneNumber: "0895340205302",
      environment: "production",
    }

    this.baseUrl =
      this.config.environment === "production" ? "https://api.midtrans.com/v2" : "https://api.sandbox.midtrans.com/v2"
  }

  private getAuthHeader(): string {
    return Buffer.from(this.config.serverKey + ":").toString("base64")
  }

  async getBalance(): Promise<GopayBalance> {
    try {
      const response = await fetch(`${this.baseUrl}/account/balance`, {
        method: "GET",
        headers: {
          Authorization: `Basic ${this.getAuthHeader()}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()

      return {
        balance: Number.parseFloat(data.balance || "0"),
        availableBalance: Number.parseFloat(data.available_balance || "0"),
        pendingBalance: Number.parseFloat(data.pending_balance || "0"),
        currency: data.currency || "IDR",
        timestamp: new Date().toISOString(),
      }
    } catch (error) {
      console.error("Error fetching GoPay balance:", error)
      throw error
    }
  }

  async getTransactions(startDate?: string, endDate?: string, limit = 100): Promise<GopayTransaction[]> {
    try {
      const params = new URLSearchParams({
        limit: limit.toString(),
      })

      if (startDate) params.append("from_date", startDate)
      if (endDate) params.append("to_date", endDate)

      const response = await fetch(`${this.baseUrl}/transactions?${params}`, {
        method: "GET",
        headers: {
          Authorization: `Basic ${this.getAuthHeader()}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()

      return (
        data.transactions?.map((tx: any) => ({
          transactionId: tx.transaction_id,
          orderId: tx.order_id,
          amount: Number.parseFloat(tx.gross_amount || "0"),
          status: tx.transaction_status,
          transactionTime: tx.transaction_time,
          settlementTime: tx.settlement_time,
          paymentType: tx.payment_type,
          grossAmount: Number.parseFloat(tx.gross_amount || "0"),
          fraudStatus: tx.fraud_status,
        })) || []
      )
    } catch (error) {
      console.error("Error fetching GoPay transactions:", error)
      throw error
    }
  }

  async getTransactionStatus(transactionId: string): Promise<any> {
    try {
      const response = await fetch(`${this.baseUrl}/${transactionId}/status`, {
        method: "GET",
        headers: {
          Authorization: `Basic ${this.getAuthHeader()}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      return await response.json()
    } catch (error) {
      console.error("Error fetching transaction status:", error)
      throw error
    }
  }

  async createPayment(orderData: any): Promise<any> {
    try {
      const response = await fetch(`${this.baseUrl}/charge`, {
        method: "POST",
        headers: {
          Authorization: `Basic ${this.getAuthHeader()}`,
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify({
          ...orderData,
          payment_type: "gopay",
        }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      return await response.json()
    } catch (error) {
      console.error("Error creating GoPay payment:", error)
      throw error
    }
  }
}

export const gopayClient = new GopayClient()
