-- Enable RLS for team management tables
ALTER TABLE public.team_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.marketing_campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.support_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.performance_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quality_checks ENABLE ROW LEVEL SECURITY;

-- Team members policies
CREATE POLICY "Team members can view team data" ON public.team_members
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.team_members tm 
            WHERE tm.user_id = auth.uid() AND tm.status = 'active'
        )
    );

-- Tasks policies
CREATE POLICY "Team members can view assigned tasks" ON public.tasks
    FOR SELECT USING (
        assigned_to IN (
            SELECT id FROM public.team_members WHERE user_id = auth.uid()
        ) OR
        created_by IN (
            SELECT id FROM public.team_members WHERE user_id = auth.uid()
        )
    );

-- Support tickets policies
CREATE POLICY "Customers can view own tickets" ON public.support_tickets
    FOR SELECT USING (customer_id = auth.uid());

CREATE POLICY "Support team can view all tickets" ON public.support_tickets
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.team_members tm 
            WHERE tm.user_id = auth.uid() 
            AND tm.role IN ('admin', 'support', 'manager')
            AND tm.status = 'active'
        )
    );

-- AI conversations policies
CREATE POLICY "Users can view own conversations" ON public.ai_conversations
    FOR SELECT USING (user_id = auth.uid());

-- Performance metrics policies (admin only)
CREATE POLICY "Admins can view performance metrics" ON public.performance_metrics
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.team_members tm 
            WHERE tm.user_id = auth.uid() 
            AND tm.role IN ('admin', 'manager')
            AND tm.status = 'active'
        )
    );
