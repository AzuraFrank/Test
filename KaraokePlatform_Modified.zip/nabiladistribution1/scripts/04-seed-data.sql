-- Insert sample streaming platforms
INSERT INTO public.platform_distributions (track_id, platform_name, distribution_status, platform_url) VALUES
    ('00000000-0000-0000-0000-000000000001', 'Spotify', 'active', 'https://open.spotify.com'),
    ('00000000-0000-0000-0000-000000000001', 'Apple Music', 'active', 'https://music.apple.com'),
    ('00000000-0000-0000-0000-000000000001', 'YouTube Music', 'active', 'https://music.youtube.com'),
    ('00000000-0000-0000-0000-000000000001', 'Amazon Music', 'active', 'https://music.amazon.com'),
    (gen_random_uuid(), 'Deezer', 'active', 'https://deezer.com'),
    (gen_random_uuid(), 'Tidal', 'active', 'https://tidal.com')
ON CONFLICT DO NOTHING;

-- Insert sample streaming analytics data
INSERT INTO public.streaming_analytics (track_id, platform_name, streams, revenue, country_code, date) VALUES
    ('00000000-0000-0000-0000-000000000001', 'Spotify', 456000, 1247.50, 'US', CURRENT_DATE - INTERVAL '1 day'),
    ('00000000-0000-0000-0000-000000000001', 'Apple Music', 389000, 1089.30, 'US', CURRENT_DATE - INTERVAL '1 day'),
    ('00000000-0000-0000-0000-000000000001', 'YouTube Music', 298000, 834.80, 'GB', CURRENT_DATE - INTERVAL '1 day'),
    ('00000000-0000-0000-0000-000000000001', 'Amazon Music', 267000, 748.40, 'CA', CURRENT_DATE - INTERVAL '1 day');

-- Insert sample product categories
INSERT INTO public.products (seller_id, title, description, price, category, status, inventory_count) VALUES
    ('00000000-0000-0000-0000-000000000002', 'Vintage Guitar Pick Set', 'Premium guitar picks made from vintage materials', 24.99, 'Music Equipment', 'active', 50),
    ('00000000-0000-0000-0000-000000000002', 'Music Production Course', 'Complete online course for music production', 99.99, 'Education', 'active', 100),
    ('00000000-0000-0000-0000-000000000002', 'Custom Beat Pack', 'High-quality beats for hip-hop and R&B', 49.99, 'Digital Products', 'active', 25);

-- Insert sample genres
CREATE TABLE IF NOT EXISTS public.music_genres (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

INSERT INTO public.music_genres (name, description) VALUES
    ('Pop', 'Popular music genre'),
    ('Rock', 'Rock music genre'),
    ('Hip Hop', 'Hip hop and rap music'),
    ('Electronic', 'Electronic dance music'),
    ('Jazz', 'Jazz music genre'),
    ('Classical', 'Classical music'),
    ('Country', 'Country music'),
    ('R&B', 'Rhythm and blues'),
    ('Reggae', 'Reggae music'),
    ('Folk', 'Folk music')
ON CONFLICT (name) DO NOTHING;

-- Insert sample countries
CREATE TABLE IF NOT EXISTS public.countries (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    region TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

INSERT INTO public.countries (code, name, region) VALUES
    ('US', 'United States', 'North America'),
    ('GB', 'United Kingdom', 'Europe'),
    ('DE', 'Germany', 'Europe'),
    ('FR', 'France', 'Europe'),
    ('CA', 'Canada', 'North America'),
    ('AU', 'Australia', 'Oceania'),
    ('JP', 'Japan', 'Asia'),
    ('KR', 'South Korea', 'Asia'),
    ('BR', 'Brazil', 'South America'),
    ('MX', 'Mexico', 'North America'),
    ('ID', 'Indonesia', 'Asia'),
    ('MY', 'Malaysia', 'Asia'),
    ('SG', 'Singapore', 'Asia'),
    ('TH', 'Thailand', 'Asia'),
    ('PH', 'Philippines', 'Asia')
ON CONFLICT (code) DO NOTHING;
