-- Legal and contract management tables
CREATE TYPE contract_type AS ENUM ('partnership', 'distribution', 'licensing', 'service', 'employment', 'nda');
CREATE TYPE contract_status AS ENUM ('draft', 'review', 'negotiation', 'approved', 'signed', 'active', 'expired', 'terminated');
CREATE TYPE legal_entity_type AS ENUM ('individual', 'company', 'collective', 'government', 'ngo');

-- Legal entities (partners, artists, companies)
CREATE TABLE public.legal_entities (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    entity_name TEXT NOT NULL,
    entity_type legal_entity_type NOT NULL,
    registration_number TEXT,
    tax_id TEXT,
    country_code TEXT NOT NULL,
    address JSONB,
    contact_info JSONB,
    legal_representative TEXT,
    authorized_signatory TEXT,
    business_license TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Contract templates
CREATE TABLE public.contract_templates (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    template_name TEXT NOT NULL,
    contract_type contract_type NOT NULL,
    template_version TEXT DEFAULT '1.0',
    language_code TEXT DEFAULT 'en',
    template_content TEXT NOT NULL,
    variables JSONB DEFAULT '{}', -- Template variables for customization
    legal_requirements JSONB DEFAULT '{}',
    compliance_standards TEXT[],
    created_by UUID REFERENCES public.profiles(id),
    approved_by UUID REFERENCES public.profiles(id),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Contracts
CREATE TABLE public.contracts (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    contract_number TEXT UNIQUE NOT NULL,
    contract_title TEXT NOT NULL,
    contract_type contract_type NOT NULL,
    template_id UUID REFERENCES public.contract_templates(id),
    party_a_id UUID REFERENCES public.legal_entities(id), -- NABILA
    party_b_id UUID REFERENCES public.legal_entities(id), -- Partner/Artist
    contract_content TEXT NOT NULL,
    contract_summary TEXT,
    key_terms JSONB DEFAULT '{}',
    financial_terms JSONB DEFAULT '{}',
    duration_months INTEGER,
    start_date DATE,
    end_date DATE,
    auto_renewal BOOLEAN DEFAULT false,
    renewal_notice_days INTEGER DEFAULT 30,
    status contract_status DEFAULT 'draft',
    negotiation_notes TEXT,
    approval_workflow JSONB DEFAULT '{}',
    signed_date TIMESTAMP WITH TIME ZONE,
    effective_date TIMESTAMP WITH TIME ZONE,
    created_by UUID REFERENCES public.profiles(id),
    assigned_lawyer UUID REFERENCES public.team_members(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Contract clauses library
CREATE TABLE public.contract_clauses (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    clause_title TEXT NOT NULL,
    clause_category TEXT NOT NULL, -- 'payment', 'termination', 'liability', etc.
    clause_content TEXT NOT NULL,
    clause_type TEXT NOT NULL, -- 'standard', 'optional', 'conditional'
    applicable_contract_types contract_type[],
    legal_jurisdiction TEXT[],
    risk_level TEXT DEFAULT 'medium', -- 'low', 'medium', 'high'
    compliance_notes TEXT,
    created_by UUID REFERENCES public.profiles(id),
    approved_by UUID REFERENCES public.profiles(id),
    version TEXT DEFAULT '1.0',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Terms and conditions
CREATE TABLE public.terms_conditions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    document_title TEXT NOT NULL,
    document_type TEXT NOT NULL, -- 'terms_of_service', 'privacy_policy', 'user_agreement'
    version TEXT NOT NULL,
    language_code TEXT DEFAULT 'en',
    content TEXT NOT NULL,
    effective_date DATE NOT NULL,
    last_updated DATE NOT NULL,
    applies_to TEXT[], -- 'artists', 'listeners', 'partners', 'all'
    legal_basis TEXT,
    compliance_standards TEXT[],
    approval_status TEXT DEFAULT 'draft',
    approved_by UUID REFERENCES public.profiles(id),
    created_by UUID REFERENCES public.profiles(id),
    is_current BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Collective music organization
CREATE TABLE public.collective_organization (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    organization_name TEXT NOT NULL,
    organization_type TEXT NOT NULL, -- 'collective_management', 'rights_society', 'union'
    registration_number TEXT UNIQUE NOT NULL,
    license_number TEXT,
    country_of_incorporation TEXT NOT NULL,
    headquarters_address JSONB,
    legal_status TEXT NOT NULL,
    founding_date DATE,
    board_members JSONB DEFAULT '{}',
    executive_team JSONB DEFAULT '{}',
    membership_criteria JSONB DEFAULT '{}',
    services_offered TEXT[],
    territorial_scope TEXT[],
    affiliated_organizations JSONB DEFAULT '{}',
    regulatory_compliance JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Legal compliance tracking
CREATE TABLE public.legal_compliance (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    compliance_area TEXT NOT NULL, -- 'copyright', 'data_protection', 'tax', 'labor'
    regulation_name TEXT NOT NULL,
    jurisdiction TEXT NOT NULL,
    compliance_status TEXT DEFAULT 'compliant', -- 'compliant', 'non_compliant', 'pending'
    last_audit_date DATE,
    next_audit_date DATE,
    compliance_officer UUID REFERENCES public.team_members(id),
    documentation JSONB DEFAULT '{}',
    action_items TEXT[],
    risk_assessment TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- AI legal assistant logs
CREATE TABLE public.ai_legal_logs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id),
    query_type TEXT NOT NULL, -- 'contract_review', 'clause_suggestion', 'compliance_check'
    query_content TEXT NOT NULL,
    ai_response TEXT NOT NULL,
    confidence_score DECIMAL(3,2),
    legal_accuracy DECIMAL(3,2),
    reviewed_by_lawyer BOOLEAN DEFAULT false,
    lawyer_notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
