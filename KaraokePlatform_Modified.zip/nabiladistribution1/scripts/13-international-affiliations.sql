-- International music organization affiliations
CREATE TYPE affiliation_status AS ENUM ('pending', 'approved', 'active', 'suspended', 'terminated');
CREATE TYPE organization_type AS ENUM ('cisac', 'ifpi', 'wipo', 'ascap', 'bmi', 'prs', 'gema', 'jasrac');

-- International affiliations table
CREATE TABLE public.international_affiliations (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    organization_name TEXT NOT NULL,
    organization_type organization_type NOT NULL,
    organization_code TEXT UNIQUE,
    country TEXT NOT NULL,
    region TEXT NOT NULL, -- 'americas', 'europe', 'asia_pacific', 'africa', 'middle_east'
    membership_type TEXT NOT NULL, -- 'full_member', 'associate_member', 'observer'
    application_date DATE,
    approval_date DATE,
    membership_start_date DATE,
    membership_end_date DATE,
    affiliation_status affiliation_status DEFAULT 'pending',
    membership_fees JSONB DEFAULT '{}',
    contact_information JSONB NOT NULL,
    services_provided TEXT[],
    reciprocal_agreements JSONB DEFAULT '{}',
    reporting_requirements JSONB DEFAULT '{}',
    compliance_status BOOLEAN DEFAULT false,
    last_compliance_check DATE,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- International royalty distribution
CREATE TABLE public.international_royalty_distribution (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    affiliation_id UUID REFERENCES public.international_affiliations(id),
    distribution_period TEXT NOT NULL, -- 'Q1-2024', 'Q2-2024', etc.
    total_amount DECIMAL(15,2) NOT NULL,
    currency_code TEXT NOT NULL DEFAULT 'USD',
    exchange_rate DECIMAL(10,6),
    amount_in_idr DECIMAL(15,2),
    distribution_type TEXT NOT NULL, -- 'performance', 'mechanical', 'synchronization'
    source_territories TEXT[],
    recipient_count INTEGER,
    processing_fee DECIMAL(15,2),
    net_amount DECIMAL(15,2),
    distribution_date DATE,
    payment_status TEXT DEFAULT 'pending', -- 'pending', 'processed', 'completed', 'failed'
    payment_reference TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Cross-border licensing agreements
CREATE TABLE public.cross_border_licensing (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    partner_organization_id UUID REFERENCES public.international_affiliations(id),
    license_type TEXT NOT NULL, -- 'reciprocal', 'bilateral', 'multilateral'
    territory_coverage TEXT[] NOT NULL,
    rights_covered TEXT[] NOT NULL, -- 'performance', 'mechanical', 'synchronization', 'digital'
    effective_date DATE NOT NULL,
    expiry_date DATE,
    revenue_share_percentage DECIMAL(5,2),
    minimum_guarantee DECIMAL(15,2),
    reporting_frequency TEXT NOT NULL, -- 'monthly', 'quarterly', 'annually'
    currency_code TEXT NOT NULL DEFAULT 'USD',
    agreement_status TEXT DEFAULT 'active', -- 'draft', 'active', 'suspended', 'terminated'
    agreement_document_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- International compliance tracking
CREATE TABLE public.international_compliance (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    affiliation_id UUID REFERENCES public.international_affiliations(id),
    compliance_area TEXT NOT NULL, -- 'reporting', 'payment', 'documentation', 'audit'
    requirement_name TEXT NOT NULL,
    requirement_description TEXT,
    due_date DATE,
    completion_date DATE,
    compliance_status TEXT DEFAULT 'pending', -- 'pending', 'completed', 'overdue', 'waived'
    evidence_documents TEXT[],
    responsible_person UUID REFERENCES public.team_members(id),
    priority_level TEXT DEFAULT 'medium', -- 'low', 'medium', 'high', 'critical'
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
