-- Seed international affiliations
INSERT INTO public.international_affiliations (
    organization_name,
    organization_type,
    organization_code,
    country,
    region,
    membership_type,
    application_date,
    affiliation_status,
    membership_fees,
    contact_information,
    services_provided,
    reciprocal_agreements,
    reporting_requirements
) VALUES 
    ('CISAC - International Confederation of Societies of Authors and Composers', 'cisac', 'CISAC-ID', 'France', 'europe', 'full_member', '2024-02-01', 'pending', '{"annual_fee": 50000, "currency": "EUR"}', '{"email": "membership@cisac.org", "phone": "+33-1-55-56-91-00", "address": "20-26 Boulevard du Parc, 92200 Neuilly-sur-Seine, France"}', ARRAY['Global Rights Management', 'International Distribution', 'Legal Support'], '{"reciprocal_territories": ["EU", "US", "CA", "AU"], "revenue_share": 0.85}', '{"frequency": "quarterly", "deadline": "30 days after quarter end"}'),
    
    ('IFPI - International Federation of the Phonographic Industry', 'ifpi', 'IFPI-ID', 'United Kingdom', 'europe', 'associate_member', '2024-02-15', 'pending', '{"annual_fee": 25000, "currency": "GBP"}', '{"email": "info@ifpi.org", "phone": "+44-20-7878-7900", "address": "10 Piccadilly, London W1J 0DD, United Kingdom"}', ARRAY['Industry Advocacy', 'Anti-Piracy', 'Market Research'], '{"data_sharing": true, "joint_campaigns": true}', '{"frequency": "annually", "deadline": "March 31"}'),
    
    ('ASCAP - American Society of Composers, Authors and Publishers', 'ascap', 'ASCAP-ID', 'United States', 'americas', 'reciprocal_agreement', '2024-03-01', 'pending', '{"setup_fee": 10000, "currency": "USD"}', '{"email": "international@ascap.com", "phone": "+1-212-621-6000", "address": "250 West 57th Street, New York, NY 10107, USA"}', ARRAY['US Performance Rights', 'Digital Licensing', 'Royalty Collection'], '{"territory": "US", "revenue_share": 0.80, "minimum_guarantee": 100000}', '{"frequency": "monthly", "deadline": "15th of following month"}'),
    
    ('JASRAC - Japanese Society for Rights of Authors, Composers and Publishers', 'jasrac', 'JASRAC-ID', 'Japan', 'asia_pacific', 'reciprocal_agreement', '2024-03-15', 'pending', '{"annual_fee": 3000000, "currency": "JPY"}', '{"email": "international@jasrac.or.jp", "phone": "+81-3-3481-2121", "address": "3-6-12 Uehara, Shibuya-ku, Tokyo 151-8540, Japan"}', ARRAY['Japan Performance Rights', 'Mechanical Rights', 'Digital Distribution'], '{"territory": "JP", "revenue_share": 0.82}', '{"frequency": "quarterly", "deadline": "Last day of quarter"}');

-- Seed payment gateways
INSERT INTO public.payment_gateways (
    gateway_name,
    gateway_type,
    supported_methods,
    supported_currencies,
    configuration,
    is_active,
    processing_fee_percentage,
    processing_fee_fixed,
    minimum_amount,
    maximum_amount,
    settlement_period_days
) VALUES 
    ('Midtrans', 'domestic', ARRAY['bank_transfer', 'digital_wallet'], ARRAY['IDR'], '{"server_key": "SB-Mid-server-xxx", "client_key": "SB-Mid-client-xxx", "environment": "sandbox"}', true, 2.90, 2000, 10000, 500000000, 1),
    ('Xendit', 'domestic', ARRAY['bank_transfer', 'digital_wallet'], ARRAY['IDR'], '{"secret_key": "xnd_development_xxx", "public_key": "xnd_public_xxx"}', true, 2.90, 2000, 10000, 1000000000, 1),
    ('PayPal', 'international', ARRAY['paypal'], ARRAY['USD', 'EUR', 'GBP', 'SGD', 'MYR'], '{"client_id": "paypal_client_xxx", "client_secret": "paypal_secret_xxx", "environment": "sandbox"}', true, 3.49, 0, 1, 10000000, 3),
    ('Stripe', 'international', ARRAY['stripe'], ARRAY['USD', 'EUR', 'GBP', 'SGD', 'MYR', 'IDR'], '{"publishable_key": "pk_test_xxx", "secret_key": "sk_test_xxx"}', true, 2.90, 30, 50, 99999999, 2),
    ('Wise (TransferWise)', 'international', ARRAY['international_wire'], ARRAY['USD', 'EUR', 'GBP', 'SGD', 'MYR', 'IDR'], '{"api_key": "wise_api_xxx", "profile_id": "wise_profile_xxx"}', true, 0.50, 5000, 100000, 1000000000, 5);

-- Seed sample payment accounts
INSERT INTO public.payment_accounts (
    account_holder_name,
    account_type,
    payment_method,
    account_details,
    currency_code,
    is_verified,
    verification_date,
    created_by
) VALUES 
    ('Nabila Razali', 'artist', 'bank_transfer', '{"bank_name": "Bank Mandiri", "account_number": "1234567890", "account_name": "Nabila Razali", "branch": "Kemang Jakarta"}', 'IDR', true, '2024-01-20 10:00:00+07', (SELECT id FROM public.profiles LIMIT 1)),
    ('Ahmad Dhani', 'artist', 'digital_wallet', '{"wallet_type": "GoPay", "phone_number": "+62812345678", "account_name": "Ahmad Dhani"}', 'IDR', true, '2024-01-22 14:30:00+07', (SELECT id FROM public.profiles LIMIT 1)),
    ('Rossa Roslaina', 'artist', 'international_wire', '{"bank_name": "HSBC Singapore", "swift_code": "HSBCSGSG", "account_number": "SGD123456789", "account_name": "Rossa Roslaina", "address": "Singapore"}', 'SGD', true, '2024-01-25 09:15:00+07', (SELECT id FROM public.profiles LIMIT 1));

-- Seed AI chat sessions table
CREATE TABLE public.ai_chat_sessions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    session_id TEXT NOT NULL,
    user_id UUID REFERENCES public.profiles(id),
    user_message TEXT NOT NULL,
    ai_response TEXT NOT NULL,
    context TEXT,
    intent TEXT,
    confidence_score DECIMAL(3,2),
    actions_executed JSONB DEFAULT '[]',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Seed notifications table
CREATE TABLE public.notifications (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    recipient_id UUID REFERENCES public.profiles(id),
    notification_type TEXT NOT NULL,
    channel TEXT NOT NULL, -- 'email', 'sms', 'push', 'in_app'
    subject TEXT,
    content TEXT NOT NULL,
    status TEXT DEFAULT 'pending', -- 'pending', 'sent', 'delivered', 'failed'
    sent_at TIMESTAMP WITH TIME ZONE,
    delivered_at TIMESTAMP WITH TIME ZONE,
    read_at TIMESTAMP WITH TIME ZONE,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Seed streaming platform tracks table
CREATE TABLE public.streaming_platform_tracks (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    song_id UUID REFERENCES public.songs(id),
    platform_name TEXT NOT NULL,
    platform_track_id TEXT NOT NULL,
    platform_url TEXT,
    sync_status TEXT DEFAULT 'pending', -- 'pending', 'synced', 'failed', 'removed'
    last_sync_date TIMESTAMP WITH TIME ZONE,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Seed streaming analytics table
CREATE TABLE public.streaming_analytics (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    track_id UUID REFERENCES public.streaming_platform_tracks(id),
    platform_name TEXT NOT NULL,
    streams BIGINT DEFAULT 0,
    listeners INTEGER DEFAULT 0,
    revenue DECIMAL(15,2) DEFAULT 0,
    territories JSONB DEFAULT '{}',
    demographics JSONB DEFAULT '{}',
    date_recorded DATE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX idx_legal_entity_registration_status ON public.legal_entity_registration(registration_status);
CREATE INDEX idx_registration_documents_type ON public.registration_documents(document_type);
CREATE INDEX idx_registration_workflow_status ON public.registration_workflow(step_status);
CREATE INDEX idx_international_affiliations_status ON public.international_affiliations(affiliation_status);
CREATE INDEX idx_payment_transactions_status ON public.payment_transactions(payment_status);
CREATE INDEX idx_streaming_analytics_date ON public.streaming_analytics(date_recorded);
CREATE INDEX idx_notifications_recipient ON public.notifications(recipient_id, status);
CREATE INDEX idx_ai_chat_sessions_user ON public.ai_chat_sessions(user_id, session_id);

-- Create RLS policies for new tables
ALTER TABLE public.legal_entity_registration ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.registration_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.registration_workflow ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.international_affiliations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payment_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_chat_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.streaming_platform_tracks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.streaming_analytics ENABLE ROW LEVEL SECURITY;

-- RLS policies for legal entity registration (admin only)
CREATE POLICY "Admin can manage legal entity registration" ON public.legal_entity_registration
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.team_members tm
            WHERE tm.user_id = auth.uid()
            AND tm.role IN ('admin', 'legal_counsel')
        )
    );

-- RLS policies for payment accounts (users can manage their own)
CREATE POLICY "Users can manage their own payment accounts" ON public.payment_accounts
    FOR ALL USING (created_by = auth.uid());

-- RLS policies for notifications (users can view their own)
CREATE POLICY "Users can view their own notifications" ON public.notifications
    FOR SELECT USING (recipient_id = auth.uid());

-- RLS policies for AI chat sessions (users can access their own)
CREATE POLICY "Users can access their own chat sessions" ON public.ai_chat_sessions
    FOR ALL USING (user_id = auth.uid());

-- Insert sample streaming analytics data
INSERT INTO public.streaming_analytics (
    track_id,
    platform_name,
    streams,
    listeners,
    revenue,
    territories,
    demographics,
    date_recorded
) SELECT 
    spt.id,
    spt.platform_name,
    FLOOR(RANDOM() * 1000000)::BIGINT,
    FLOOR(RANDOM() * 100000)::INTEGER,
    RANDOM() * 1000,
    '{"ID": 45, "MY": 25, "SG": 15, "TH": 10, "PH": 5}'::JSONB,
    '{"age_groups": {"18-24": 30, "25-34": 40, "35-44": 20, "45+": 10}, "gender": {"male": 55, "female": 45}}'::JSONB,
    CURRENT_DATE - INTERVAL '1 day' * FLOOR(RANDOM() * 30)
FROM public.streaming_platform_tracks spt
LIMIT 100;

-- Create stored procedures for common operations
CREATE OR REPLACE FUNCTION public.cache_user_royalty_summary(user_id UUID)
RETURNS VOID AS $$
BEGIN
    -- Cache user royalty summary for AI chat
    INSERT INTO public.user_cache (user_id, cache_key, cache_data, expires_at)
    VALUES (
        user_id,
        'royalty_summary',
        (
            SELECT jsonb_build_object(
                'total_earnings', COALESCE(SUM(net_amount), 0),
                'pending_payments', COUNT(*) FILTER (WHERE payment_status = 'pending'),
                'last_payment_date', MAX(payment_date),
                'top_earning_songs', (
                    SELECT jsonb_agg(jsonb_build_object('title', song_title, 'earnings', net_amount))
                    FROM (
                        SELECT song_title, SUM(net_amount) as net_amount
                        FROM public.royalty_payments
                        WHERE recipient_id = user_id
                        GROUP BY song_title
                        ORDER BY net_amount DESC
                        LIMIT 5
                    ) top_songs
                )
            )
            FROM public.royalty_payments
            WHERE recipient_id = user_id
        ),
        NOW() + INTERVAL '1 hour'
    )
    ON CONFLICT (user_id, cache_key) 
    DO UPDATE SET 
        cache_data = EXCLUDED.cache_data,
        expires_at = EXCLUDED.expires_at,
        updated_at = NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create user cache table for AI optimization
CREATE TABLE public.user_cache (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id),
    cache_key TEXT NOT NULL,
    cache_data JSONB NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, cache_key)
);

-- Enable RLS on user cache
ALTER TABLE public.user_cache ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can access their own cache" ON public.user_cache
    FOR ALL USING (user_id = auth.uid());
