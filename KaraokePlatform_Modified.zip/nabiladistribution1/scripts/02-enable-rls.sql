-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.artist_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.business_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tracks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.platform_distributions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.streaming_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.royalty_payments ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view own profile" ON public.profiles
    FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.profiles
    FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON public.profiles
    FOR INSERT WITH CHECK (auth.uid() = id);

-- Artist profiles policies
CREATE POLICY "Users can view own artist profile" ON public.artist_profiles
    FOR SELECT USING (profile_id = auth.uid());

CREATE POLICY "Users can manage own artist profile" ON public.artist_profiles
    FOR ALL USING (profile_id = auth.uid());

-- Business profiles policies
CREATE POLICY "Users can view own business profile" ON public.business_profiles
    FOR SELECT USING (profile_id = auth.uid());

CREATE POLICY "Users can manage own business profile" ON public.business_profiles
    FOR ALL USING (profile_id = auth.uid());

-- Tracks policies
CREATE POLICY "Artists can view own tracks" ON public.tracks
    FOR SELECT USING (artist_id = auth.uid());

CREATE POLICY "Artists can manage own tracks" ON public.tracks
    FOR ALL USING (artist_id = auth.uid());

-- Platform distributions policies
CREATE POLICY "Users can view distributions for own tracks" ON public.platform_distributions
    FOR SELECT USING (
        track_id IN (
            SELECT id FROM public.tracks WHERE artist_id = auth.uid()
        )
    );

-- Streaming analytics policies
CREATE POLICY "Users can view analytics for own tracks" ON public.streaming_analytics
    FOR SELECT USING (
        track_id IN (
            SELECT id FROM public.tracks WHERE artist_id = auth.uid()
        )
    );

-- Royalty payments policies
CREATE POLICY "Users can view own royalty payments" ON public.royalty_payments
    FOR SELECT USING (artist_id = auth.uid());
