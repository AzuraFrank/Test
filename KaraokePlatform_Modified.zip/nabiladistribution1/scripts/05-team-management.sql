-- Team management tables
CREATE TYPE team_role AS ENUM ('admin', 'manager', 'marketing', 'support', 'developer', 'analyst');
CREATE TYPE team_status AS ENUM ('active', 'inactive', 'suspended');
CREATE TYPE task_status AS ENUM ('pending', 'in_progress', 'completed', 'cancelled');
CREATE TYPE task_priority AS ENUM ('low', 'medium', 'high', 'urgent');

-- Team members table
CREATE TABLE public.team_members (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id),
    role team_role NOT NULL,
    department TEXT,
    status team_status DEFAULT 'active',
    permissions JSONB DEFAULT '{}',
    hire_date DATE DEFAULT CURRENT_DATE,
    manager_id UUID REFERENCES public.team_members(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tasks and projects
CREATE TABLE public.tasks (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT,
    assigned_to UUID REFERENCES public.team_members(id),
    created_by UUID REFERENCES public.team_members(id),
    status task_status DEFAULT 'pending',
    priority task_priority DEFAULT 'medium',
    due_date TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    tags TEXT[],
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- AI marketing campaigns
CREATE TABLE public.marketing_campaigns (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT NOT NULL, -- 'email', 'social', 'content', 'ads'
    target_audience JSONB,
    ai_generated_content JSONB,
    performance_metrics JSONB DEFAULT '{}',
    status TEXT DEFAULT 'draft',
    budget DECIMAL(10,2),
    start_date TIMESTAMP WITH TIME ZONE,
    end_date TIMESTAMP WITH TIME ZONE,
    created_by UUID REFERENCES public.team_members(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Customer service tickets
CREATE TABLE public.support_tickets (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    ticket_number TEXT UNIQUE NOT NULL,
    customer_id UUID REFERENCES public.profiles(id),
    assigned_to UUID REFERENCES public.team_members(id),
    subject TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'open',
    priority task_priority DEFAULT 'medium',
    category TEXT,
    ai_analysis JSONB,
    resolution_time INTEGER, -- in minutes
    satisfaction_score INTEGER CHECK (satisfaction_score >= 1 AND satisfaction_score <= 5),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- AI chat conversations
CREATE TABLE public.ai_conversations (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id),
    conversation_type TEXT DEFAULT 'support', -- 'support', 'marketing', 'sales'
    messages JSONB NOT NULL DEFAULT '[]',
    ai_model TEXT DEFAULT 'gpt-4',
    sentiment_analysis JSONB,
    intent_classification TEXT,
    resolution_status TEXT DEFAULT 'ongoing',
    escalated_to UUID REFERENCES public.team_members(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Performance monitoring
CREATE TABLE public.performance_metrics (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    metric_type TEXT NOT NULL, -- 'website', 'api', 'database', 'user_engagement'
    metric_name TEXT NOT NULL,
    value DECIMAL(15,4),
    unit TEXT,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    metadata JSONB DEFAULT '{}'
);

-- Quality assurance checks
CREATE TABLE public.quality_checks (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    check_type TEXT NOT NULL,
    target_entity TEXT, -- 'user_registration', 'music_upload', 'payment', etc.
    status TEXT DEFAULT 'passed',
    issues_found JSONB DEFAULT '[]',
    automated BOOLEAN DEFAULT true,
    performed_by UUID REFERENCES public.team_members(id),
    performed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
