-- Insert sample team members
INSERT INTO public.team_members (user_id, role, department, permissions) VALUES
    ('00000000-0000-0000-0000-000000000001', 'admin', 'Management', '{"all": true}'),
    ('00000000-0000-0000-0000-000000000002', 'manager', 'Operations', '{"team_management": true, "analytics": true}'),
    ('00000000-0000-0000-0000-000000000003', 'marketing', 'Marketing', '{"campaigns": true, "analytics": true}'),
    ('00000000-0000-0000-0000-000000000004', 'support', 'Customer Service', '{"tickets": true, "chat": true}'),
    ('00000000-0000-0000-0000-000000000005', 'developer', 'Technology', '{"system": true, "api": true}'),
    ('00000000-0000-0000-0000-000000000006', 'analyst', 'Data & Analytics', '{"analytics": true, "reports": true}');

-- Insert sample marketing campaigns
INSERT INTO public.marketing_campaigns (name, type, target_audience, ai_generated_content, status, budget) VALUES
    ('Artist Onboarding Campaign', 'email', '{"segment": "new_artists", "genre": "all"}', '{"subject": "Welcome to NABILA DISTRIBUTION", "content": "AI-generated welcome sequence"}', 'active', 5000.00),
    ('Social Media Engagement', 'social', '{"platform": "instagram", "age_range": "18-35"}', '{"posts": ["AI-generated content"], "hashtags": ["#music", "#distribution"]}', 'active', 3000.00),
    ('Marketplace Promotion', 'ads', '{"user_type": "business", "location": "global"}', '{"ad_copy": "AI-optimized ad content", "targeting": "lookalike_audience"}', 'active', 10000.00);

-- Insert sample performance metrics
INSERT INTO public.performance_metrics (metric_type, metric_name, value, unit) VALUES
    ('website', 'page_load_time', 1.2, 'seconds'),
    ('website', 'uptime', 99.9, 'percentage'),
    ('api', 'response_time', 150, 'milliseconds'),
    ('database', 'query_performance', 50, 'milliseconds'),
    ('user_engagement', 'daily_active_users', 2500, 'count'),
    ('user_engagement', 'conversion_rate', 3.5, 'percentage');
