-- Insert major streaming platform partners
INSERT INTO public.streaming_partners (
    platform_name, platform_type, website_url, api_endpoint, api_version,
    integration_status, revenue_share_percentage, supported_countries,
    supported_formats, max_file_size_mb, payout_frequency
) VALUES
-- Major Streaming Platforms
('Spotify', 'streaming', 'https://open.spotify.com', 'https://api.spotify.com/v1', 'v1', 
 'active', 70.00, ARRAY['US','GB','DE','FR','CA','AU','NL','SE','NO','DK','FI','ES','IT','BR','MX','AR','CL','CO','PE','EC','UY','PY','BO','VE','CR','GT','HN','SV','NI','PA','DO','CU','JM','TT','BB','GY','SR','GF','FK','BZ','KN','LC','VC','GD','AG','DM','MS','AI','VG','TC','KY','BM','PM','GL','FO','IS','IE','PT','CH','AT','BE','LU','LI','MC','SM','VA','MT','CY','GR','BG','RO','MD','UA','BY','LT','LV','EE','PL','CZ','SK','HU','SI','HR','BA','RS','ME','MK','AL','XK','TR','GE','AM','AZ','KZ','KG','TJ','TM','UZ','AF','PK','IN','BD','LK','MV','NP','BT','MM','TH','LA','VN','KH','MY','SG','BN','ID','TL','PH','CN','TW','HK','MO','JP','KR','KP','MN','RU'], 
 ARRAY['mp3','flac'], 200, 'monthly'),

('Apple Music', 'streaming', 'https://music.apple.com', 'https://api.music.apple.com/v1', 'v1',
 'active', 70.00, ARRAY['US','GB','DE','FR','CA','AU','JP','KR','CN','IN','BR','MX','ES','IT','NL','SE','NO','DK','FI','BE','CH','AT','IE','PT','GR','PL','CZ','HU','SK','SI','HR','EE','LV','LT','BG','RO','CY','MT','LU','IS','TR','IL','SA','AE','QA','KW','BH','OM','JO','LB','EG','MA','TN','DZ','LY','SD','ET','KE','UG','TZ','RW','BI','DJ','SO','ER','SS','CF','TD','CM','GQ','GA','CG','CD','AO','ZM','ZW','BW','NA','ZA','SZ','LS','MW','MZ','MG','MU','SC','KM','YT','RE','SH','ST','CV','GW','GN','SL','LR','CI','GH','TG','BJ','NE','BF','ML','SN','GM','GN','MR','EH','MA','DZ','TN','LY','EG','SD','SS','ET','ER','DJ','SO','KE','UG','RW','BI','TZ','MW','ZM','ZW','BW','NA','ZA','LS','SZ','MZ','MG','MU','SC','KM','YT','RE'], 
 ARRAY['mp3','aac','alac'], 200, 'monthly'),

('YouTube Music', 'streaming', 'https://music.youtube.com', 'https://www.googleapis.com/youtube/v3', 'v3',
 'active', 55.00, ARRAY['GLOBAL'], ARRAY['mp3','wav','flac'], 128, 'monthly'),

('Amazon Music', 'streaming', 'https://music.amazon.com', 'https://api.amazonalexa.com', 'v1',
 'active', 65.00, ARRAY['US','GB','DE','FR','CA','AU','JP','IN','BR','MX','ES','IT'], 
 ARRAY['mp3','flac'], 200, 'monthly'),

('Deezer', 'streaming', 'https://www.deezer.com', 'https://api.deezer.com', 'v2',
 'active', 65.00, ARRAY['FR','DE','GB','ES','IT','BR','AR','MX','TR','PL','BE','NL','CH','AT','PT','RO','BG','HR','SI','SK','CZ','HU','EE','LV','LT','DK','SE','NO','FI','IS','IE','LU','MT','CY','GR'], 
 ARRAY['mp3','flac'], 200, 'monthly'),

('Tidal', 'streaming', 'https://tidal.com', 'https://api.tidal.com/v1', 'v1',
 'active', 75.00, ARRAY['US','GB','DE','FR','CA','AU','NO','SE','DK','NL','BE','AT','CH','IE','FI','PL','ES','IT','PT','BR','AR','MX','JP'], 
 ARRAY['mp3','flac','mqa'], 200, 'monthly'),

('SoundCloud', 'streaming', 'https://soundcloud.com', 'https://api.soundcloud.com', 'v2',
 'active', 55.00, ARRAY['GLOBAL'], ARRAY['mp3','wav','aiff','flac'], 500, 'monthly'),

('Pandora', 'streaming', 'https://www.pandora.com', 'https://api.pandora.com/v1', 'v1',
 'active', 60.00, ARRAY['US','AU','NZ'], ARRAY['mp3','aac'], 200, 'monthly'),

-- Social Media Platforms
('TikTok', 'social', 'https://www.tiktok.com', 'https://open-api.tiktok.com/platform/v1', 'v1',
 'active', 50.00, ARRAY['GLOBAL'], ARRAY['mp3'], 50, 'monthly'),

('Instagram', 'social', 'https://www.instagram.com', 'https://graph.facebook.com/v18.0', 'v18.0',
 'active', 45.00, ARRAY['GLOBAL'], ARRAY['mp3'], 30, 'monthly'),

('Facebook', 'social', 'https://www.facebook.com', 'https://graph.facebook.com/v18.0', 'v18.0',
 'active', 45.00, ARRAY['GLOBAL'], ARRAY['mp3'], 100, 'monthly'),

('Twitter/X', 'social', 'https://twitter.com', 'https://api.twitter.com/2', 'v2',
 'testing', 40.00, ARRAY['GLOBAL'], ARRAY['mp3'], 25, 'monthly'),

-- Regional Platforms
('JioSaavn', 'streaming', 'https://www.jiosaavn.com', 'https://api.jiosaavn.com/v1', 'v1',
 'active', 60.00, ARRAY['IN','BD','LK','NP','PK'], ARRAY['mp3','aac'], 200, 'monthly'),

('Anghami', 'streaming', 'https://www.anghami.com', 'https://api.anghami.com/v1', 'v1',
 'active', 65.00, ARRAY['AE','SA','EG','LB','JO','KW','QA','BH','OM','IQ','YE','SY','PS','MA','TN','DZ','LY','SD'], 
 ARRAY['mp3','aac'], 200, 'monthly'),

('NetEase Cloud Music', 'streaming', 'https://music.163.com', 'https://api.music.163.com/v1', 'v1',
 'pending', 70.00, ARRAY['CN','HK','MO','TW'], ARRAY['mp3','flac'], 200, 'monthly'),

('QQ Music', 'streaming', 'https://y.qq.com', 'https://api.qq.com/music/v1', 'v1',
 'pending', 70.00, ARRAY['CN','HK','MO','TW'], ARRAY['mp3','flac'], 200, 'monthly'),

-- Indonesian Platforms
('Joox', 'streaming', 'https://www.joox.com', 'https://api.joox.com/v1', 'v1',
 'active', 65.00, ARRAY['ID','MY','TH','HK','ZA','MM'], ARRAY['mp3','aac'], 200, 'monthly'),

('Langit Musik', 'streaming', 'https://www.langitmusik.co.id', 'https://api.langitmusik.co.id/v1', 'v1',
 'active', 70.00, ARRAY['ID'], ARRAY['mp3'], 200, 'monthly'),

-- Podcast Platforms
('Spotify Podcasts', 'podcast', 'https://podcasters.spotify.com', 'https://api.spotify.com/v1', 'v1',
 'active', 50.00, ARRAY['GLOBAL'], ARRAY['mp3','wav'], 200, 'monthly'),

('Apple Podcasts', 'podcast', 'https://podcasts.apple.com', 'https://api.podcasts.apple.com/v1', 'v1',
 'active', 70.00, ARRAY['GLOBAL'], ARRAY['mp3','aac'], 200, 'monthly'),

('Google Podcasts', 'podcast', 'https://podcasts.google.com', 'https://api.googlepodcasts.com/v1', 'v1',
 'active', 0.00, ARRAY['GLOBAL'], ARRAY['mp3'], 200, 'monthly'),

-- Radio Platforms
('iHeartRadio', 'radio', 'https://www.iheart.com', 'https://api.iheart.com/v1', 'v1',
 'active', 55.00, ARRAY['US','CA','AU','NZ','MX'], ARRAY['mp3','aac'], 200, 'monthly'),

('Radio.com', 'radio', 'https://www.radio.com', 'https://api.radio.com/v1', 'v1',
 'active', 50.00, ARRAY['US'], ARRAY['mp3'], 200, 'monthly');

-- Insert partner team assignments
INSERT INTO public.partner_team_assignments (partner_id, team_member_id, role) 
SELECT 
    sp.id,
    tm.id,
    CASE 
        WHEN tm.role = 'manager' THEN 'account_manager'
        WHEN tm.role = 'developer' THEN 'technical_lead'
        ELSE 'primary_contact'
    END
FROM public.streaming_partners sp
CROSS JOIN public.team_members tm
WHERE tm.role IN ('manager', 'developer', 'marketing')
AND sp.platform_name IN ('Spotify', 'Apple Music', 'YouTube Music', 'Amazon Music', 'TikTok');
