-- Function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, email, full_name, user_type)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
        COALESCE(NEW.raw_user_meta_data->>'user_type', 'artist')::user_type
    );
    
    -- Create artist profile if user_type is artist
    IF COALESCE(NEW.raw_user_meta_data->>'user_type', 'artist') = 'artist' THEN
        INSERT INTO public.artist_profiles (profile_id, stage_name)
        VALUES (
            NEW.id,
            COALESCE(NEW.raw_user_meta_data->>'full_name', 'Unknown Artist')
        );
    END IF;
    
    -- Create business profile if user_type is business
    IF COALESCE(NEW.raw_user_meta_data->>'user_type', 'artist') = 'business' THEN
        INSERT INTO public.business_profiles (profile_id, company_name)
        VALUES (
            NEW.id,
            COALESCE(NEW.raw_user_meta_data->>'full_name', 'Unknown Company')
        );
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for new user signup
CREATE OR REPLACE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Function to calculate total earnings for an artist
CREATE OR REPLACE FUNCTION public.calculate_artist_earnings(artist_uuid UUID)
RETURNS DECIMAL AS $$
DECLARE
    total_earnings DECIMAL := 0;
BEGIN
    SELECT COALESCE(SUM(amount), 0)
    INTO total_earnings
    FROM public.royalty_payments
    WHERE artist_id = artist_uuid AND status = 'completed';
    
    RETURN total_earnings;
END;
$$ LANGUAGE plpgsql;

-- Function to get track statistics
CREATE OR REPLACE FUNCTION public.get_track_stats(track_uuid UUID)
RETURNS TABLE (
    total_streams BIGINT,
    total_listeners BIGINT,
    total_revenue DECIMAL,
    top_country TEXT
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COALESCE(SUM(streams), 0) as total_streams,
        COALESCE(SUM(listeners), 0) as total_listeners,
        COALESCE(SUM(revenue), 0) as total_revenue,
        (
            SELECT country 
            FROM public.streaming_analytics 
            WHERE track_id = track_uuid AND country IS NOT NULL
            GROUP BY country 
            ORDER BY SUM(streams) DESC 
            LIMIT 1
        ) as top_country
    FROM public.streaming_analytics
    WHERE track_id = track_uuid;
END;
$$ LANGUAGE plpgsql;
