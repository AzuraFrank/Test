-- Payment processing system
CREATE TYPE payment_method AS ENUM ('bank_transfer', 'digital_wallet', 'cryptocurrency', 'international_wire', 'paypal', 'stripe');
CREATE TYPE payment_status AS ENUM ('pending', 'processing', 'completed', 'failed', 'cancelled', 'refunded');
CREATE TYPE transaction_type AS ENUM ('royalty_payment', 'license_fee', 'membership_fee', 'service_fee', 'penalty', 'refund');

-- Payment accounts and methods
CREATE TABLE public.payment_accounts (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    account_holder_name TEXT NOT NULL,
    account_type TEXT NOT NULL, -- 'artist', 'label', 'publisher', 'organization'
    payment_method payment_method NOT NULL,
    account_details JSONB NOT NULL, -- Bank details, wallet info, etc.
    currency_code TEXT NOT NULL DEFAULT 'IDR',
    is_verified BOOLEAN DEFAULT false,
    verification_date TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT true,
    created_by UUID REFERENCES public.profiles(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Payment transactions
CREATE TABLE public.payment_transactions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    transaction_reference TEXT UNIQUE NOT NULL,
    transaction_type transaction_type NOT NULL,
    payer_id UUID REFERENCES public.profiles(id),
    payee_id UUID REFERENCES public.profiles(id),
    payment_account_id UUID REFERENCES public.payment_accounts(id),
    amount DECIMAL(15,2) NOT NULL,
    currency_code TEXT NOT NULL DEFAULT 'IDR',
    exchange_rate DECIMAL(10,6),
    amount_in_base_currency DECIMAL(15,2),
    processing_fee DECIMAL(15,2) DEFAULT 0,
    net_amount DECIMAL(15,2),
    payment_status payment_status DEFAULT 'pending',
    payment_method payment_method NOT NULL,
    payment_gateway TEXT, -- 'midtrans', 'xendit', 'gopay', 'ovo', etc.
    gateway_transaction_id TEXT,
    gateway_response JSONB,
    scheduled_date DATE,
    processed_date TIMESTAMP WITH TIME ZONE,
    completed_date TIMESTAMP WITH TIME ZONE,
    failure_reason TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Royalty payment batches
CREATE TABLE public.royalty_payment_batches (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    batch_name TEXT NOT NULL,
    batch_reference TEXT UNIQUE NOT NULL,
    payment_period TEXT NOT NULL, -- 'Q1-2024', 'January-2024', etc.
    total_amount DECIMAL(15,2) NOT NULL,
    total_recipients INTEGER NOT NULL,
    currency_code TEXT NOT NULL DEFAULT 'IDR',
    batch_status TEXT DEFAULT 'draft', -- 'draft', 'approved', 'processing', 'completed', 'failed'
    approval_date TIMESTAMP WITH TIME ZONE,
    processing_start_date TIMESTAMP WITH TIME ZONE,
    processing_end_date TIMESTAMP WITH TIME ZONE,
    approved_by UUID REFERENCES public.team_members(id),
    processed_by UUID REFERENCES public.team_members(id),
    payment_method payment_method NOT NULL,
    processing_notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Individual royalty payments within batches
CREATE TABLE public.royalty_payments (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    batch_id UUID REFERENCES public.royalty_payment_batches(id),
    transaction_id UUID REFERENCES public.payment_transactions(id),
    recipient_id UUID REFERENCES public.profiles(id),
    payment_account_id UUID REFERENCES public.payment_accounts(id),
    artist_name TEXT NOT NULL,
    song_title TEXT,
    usage_type TEXT, -- 'streaming', 'radio', 'tv', 'live_performance', 'sync'
    territory TEXT,
    usage_count BIGINT,
    rate_per_usage DECIMAL(10,6),
    gross_amount DECIMAL(15,2) NOT NULL,
    commission_rate DECIMAL(5,2) DEFAULT 15.00,
    commission_amount DECIMAL(15,2),
    tax_rate DECIMAL(5,2) DEFAULT 0,
    tax_amount DECIMAL(15,2) DEFAULT 0,
    net_amount DECIMAL(15,2) NOT NULL,
    currency_code TEXT NOT NULL DEFAULT 'IDR',
    payment_status payment_status DEFAULT 'pending',
    payment_date TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Payment gateway configurations
CREATE TABLE public.payment_gateways (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    gateway_name TEXT NOT NULL,
    gateway_type TEXT NOT NULL, -- 'domestic', 'international', 'cryptocurrency'
    supported_methods payment_method[],
    supported_currencies TEXT[],
    configuration JSONB NOT NULL, -- API keys, endpoints, etc.
    is_active BOOLEAN DEFAULT true,
    processing_fee_percentage DECIMAL(5,2),
    processing_fee_fixed DECIMAL(10,2),
    minimum_amount DECIMAL(15,2),
    maximum_amount DECIMAL(15,2),
    settlement_period_days INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert GoPay gateway configuration
INSERT INTO public.payment_gateways (
    gateway_name,
    gateway_type,
    supported_methods,
    supported_currencies,
    configuration,
    is_active,
    processing_fee_percentage,
    processing_fee_fixed,
    minimum_amount,
    maximum_amount,
    settlement_period_days
) VALUES (
    'GoPay',
    'domestic',
    ARRAY['digital_wallet']::payment_method[],
    ARRAY['IDR'],
    '{
        "user_id": "G082083595",
        "client_key": "Mid-client-Xv_CpPRaXK_R-dj0",
        "server_key": "Mid-server-Gbr3kjXtYY88uEdxlD6LdazR",
        "phone_number": "0895340205302",
        "api_endpoint": "https://api.midtrans.com/v2",
        "sandbox_endpoint": "https://api.sandbox.midtrans.com/v2",
        "environment": "production"
    }',
    true,
    2.50,
    0,
    10000,
    20000000,
    1
);
