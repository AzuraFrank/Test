-- Partner platform streaming tables
CREATE TYPE platform_type AS ENUM ('streaming', 'social', 'marketplace', 'radio', 'podcast');
CREATE TYPE integration_status AS ENUM ('active', 'pending', 'maintenance', 'suspended', 'testing');
CREATE TYPE api_status AS ENUM ('connected', 'disconnected', 'error', 'rate_limited');

-- Streaming platform partners
CREATE TABLE public.streaming_partners (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    platform_name TEXT NOT NULL UNIQUE,
    platform_type platform_type NOT NULL,
    logo_url TEXT,
    website_url TEXT,
    api_endpoint TEXT,
    api_version TEXT,
    integration_status integration_status DEFAULT 'pending',
    api_status api_status DEFAULT 'disconnected',
    revenue_share_percentage DECIMAL(5,2), -- Platform's revenue share
    minimum_payout DECIMAL(10,2) DEFAULT 0,
    payout_frequency TEXT DEFAULT 'monthly', -- daily, weekly, monthly
    supported_countries TEXT[], -- Array of country codes
    supported_formats TEXT[], -- mp3, flac, wav, etc.
    max_file_size_mb INTEGER,
    metadata_requirements JSONB DEFAULT '{}',
    api_credentials JSONB DEFAULT '{}', -- Encrypted API keys
    webhook_url TEXT,
    last_sync TIMESTAMP WITH TIME ZONE,
    sync_frequency_hours INTEGER DEFAULT 24,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Partner API integrations
CREATE TABLE public.partner_integrations (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    partner_id UUID REFERENCES public.streaming_partners(id),
    integration_name TEXT NOT NULL,
    api_key_encrypted TEXT,
    api_secret_encrypted TEXT,
    access_token TEXT,
    refresh_token TEXT,
    token_expires_at TIMESTAMP WITH TIME ZONE,
    rate_limit_per_hour INTEGER,
    current_usage INTEGER DEFAULT 0,
    last_request TIMESTAMP WITH TIME ZONE,
    error_count INTEGER DEFAULT 0,
    last_error TEXT,
    configuration JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Distribution tracking per platform
CREATE TABLE public.platform_distributions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    track_id UUID REFERENCES public.tracks(id),
    partner_id UUID REFERENCES public.streaming_partners(id),
    distribution_id TEXT, -- Platform's internal ID
    status TEXT DEFAULT 'pending',
    submitted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    approved_at TIMESTAMP WITH TIME ZONE,
    live_date TIMESTAMP WITH TIME ZONE,
    platform_url TEXT,
    metadata_sent JSONB,
    platform_response JSONB,
    error_message TEXT,
    retry_count INTEGER DEFAULT 0,
    last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Revenue tracking per platform
CREATE TABLE public.platform_revenues (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    track_id UUID REFERENCES public.tracks(id),
    partner_id UUID REFERENCES public.streaming_partners(id),
    artist_id UUID REFERENCES public.profiles(id),
    reporting_period_start DATE,
    reporting_period_end DATE,
    streams INTEGER DEFAULT 0,
    downloads INTEGER DEFAULT 0,
    gross_revenue DECIMAL(12,4) DEFAULT 0,
    platform_fee DECIMAL(12,4) DEFAULT 0,
    net_revenue DECIMAL(12,4) DEFAULT 0,
    currency TEXT DEFAULT 'USD',
    exchange_rate DECIMAL(10,6) DEFAULT 1,
    country_code TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Partner team assignments
CREATE TABLE public.partner_team_assignments (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    partner_id UUID REFERENCES public.streaming_partners(id),
    team_member_id UUID REFERENCES public.team_members(id),
    role TEXT NOT NULL, -- 'primary_contact', 'technical_lead', 'account_manager'
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    is_active BOOLEAN DEFAULT true
);

-- API monitoring and logs
CREATE TABLE public.api_monitoring_logs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    partner_id UUID REFERENCES public.streaming_partners(id),
    endpoint TEXT,
    method TEXT,
    request_payload JSONB,
    response_payload JSONB,
    response_time_ms INTEGER,
    status_code INTEGER,
    success BOOLEAN,
    error_message TEXT,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Partner notifications and alerts
CREATE TABLE public.partner_alerts (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    partner_id UUID REFERENCES public.streaming_partners(id),
    alert_type TEXT NOT NULL, -- 'api_error', 'sync_failure', 'revenue_discrepancy', 'contract_renewal'
    severity TEXT DEFAULT 'medium', -- 'low', 'medium', 'high', 'critical'
    title TEXT NOT NULL,
    description TEXT,
    is_resolved BOOLEAN DEFAULT false,
    assigned_to UUID REFERENCES public.team_members(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    resolved_at TIMESTAMP WITH TIME ZONE
);
