-- Insert NCMO legal entity registration
INSERT INTO public.legal_entity_registration (
    entity_name,
    entity_type,
    registration_purpose,
    business_activities,
    authorized_capital,
    paid_capital,
    shareholders,
    board_members,
    registered_address,
    operational_address,
    contact_information,
    registration_status,
    submission_date,
    approval_date,
    registration_numbers,
    created_by
) VALUES (
    'NABILA Collective Music Organization',
    'yayasan',
    'Collective Management of Music Rights and Distribution',
    ARRAY[
        'Pengelolaan Hak Cipta Musik Kolektif',
        'Distribusi Royalti Musik',
        'Lisensi Hak Pertunjukan',
        'Advokasi Industri Musik',
        'Layanan Teknologi Musik Digital'
    ],
    5000000000.00, -- 5 Miliar IDR
    1000000000.00, -- 1 Miliar IDR
    '{"founders": [{"name": "Nabila Razali", "share": 40}, {"name": "Ahmad Dhani", "share": 30}, {"name": "Rossa Roslaina", "share": 30}]}',
    '{"board_of_directors": [{"position": "Chairman", "name": "Prof. Dr. Slamet Sjukur"}, {"position": "Vice Chairman", "name": "Melly Goeslaw"}, {"position": "Member", "name": "Glenn Fredly"}], "executives": [{"position": "CEO", "name": "Nabila Razali"}, {"position": "COO", "name": "Ahmad Dhani"}, {"position": "CFO", "name": "Rossa Roslaina"}, {"position": "CLO", "name": "Hotman Paris"}]}',
    '{"street": "Jl. Kemang Raya No. 123", "city": "Jakarta Selatan", "province": "DKI Jakarta", "postal_code": "12560", "country": "Indonesia"}',
    '{"street": "Jl. Kemang Raya No. 123", "city": "Jakarta Selatan", "province": "DKI Jakarta", "postal_code": "12560", "country": "Indonesia"}',
    '{"phone": "+62-21-7194-5678", "email": "legal@nabila-music.com", "website": "https://nabila-music.com"}',
    'in_progress',
    '2024-01-05 09:00:00+07',
    '2024-01-25 14:30:00+07',
    '{"akta_pendirian": "No. 123 Tanggal 15 Januari 2024", "sk_kemenkumham": "AHU-0001234.AH.01.04.2024", "npwp": "01.234.567.8-901.000", "siup": "Pending - 510/1.824.1/2024", "tdp": "Pending - 09.05.1.72.12345"}',
    (SELECT id FROM public.profiles LIMIT 1)
);

-- Insert registration documents
INSERT INTO public.registration_documents (
    registration_id,
    document_type,
    document_name,
    document_number,
    issuing_authority,
    issue_date,
    expiry_date,
    document_status
) VALUES 
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'akta_pendirian', 'Akta Pendirian Yayasan NCMO', 'No. 123 Tanggal 15 Januari 2024', 'notaris', '2024-01-15', NULL, 'approved'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'sk_kemenkumham', 'SK Pengesahan Kemenkumham', 'AHU-0001234.AH.01.04.2024', 'kemenkumham', '2024-01-25', NULL, 'approved'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'npwp', 'NPWP Yayasan', '01.234.567.8-901.000', 'pajak', '2024-01-30', NULL, 'approved'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'siup', 'SIUP Application', '510/1.824.1/2024', 'oss', NULL, NULL, 'pending'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'tdp', 'TDP Application', '09.05.1.72.12345', 'oss', NULL, NULL, 'pending'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'izin_usaha', 'Izin Usaha Musik', 'IUM/2024/001', 'kemenparekraf', NULL, NULL, 'pending');

-- Insert registration workflow steps
INSERT INTO public.registration_workflow (
    registration_id,
    step_name,
    step_order,
    authority,
    required_documents,
    estimated_duration_days,
    actual_duration_days,
    step_status,
    started_date,
    completed_date
) VALUES 
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'Persiapan Dokumen Akta Pendirian', 1, 'notaris', ARRAY['akta_pendirian'], 3, 2, 'completed', '2024-01-05 09:00:00+07', '2024-01-10 16:00:00+07'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'Penandatanganan Akta Pendirian', 2, 'notaris', ARRAY['akta_pendirian'], 1, 1, 'completed', '2024-01-10 09:00:00+07', '2024-01-15 11:00:00+07'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'Pengajuan SK Kemenkumham', 3, 'kemenkumham', ARRAY['sk_kemenkumham'], 14, 10, 'completed', '2024-01-15 14:00:00+07', '2024-01-25 10:00:00+07'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'Registrasi NPWP', 4, 'pajak', ARRAY['npwp'], 3, 2, 'completed', '2024-01-25 11:00:00+07', '2024-01-30 15:00:00+07'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'Pengurusan SIUP', 5, 'oss', ARRAY['siup'], 7, NULL, 'in_progress', '2024-02-01 09:00:00+07', NULL),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'Registrasi TDP', 6, 'oss', ARRAY['tdp'], 5, NULL, 'pending', NULL, NULL),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'Izin Usaha Musik', 7, 'kemenparekraf', ARRAY['izin_usaha'], 21, NULL, 'pending', NULL, NULL),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'Pembukaan Rekening Bank', 8, 'bank_indonesia', ARRAY['domicile_letter'], 3, NULL, 'pending', NULL, NULL);

-- Insert government authorities
INSERT INTO public.government_authorities (
    authority_name,
    authority_type,
    jurisdiction,
    contact_person,
    phone_number,
    email,
    address,
    office_hours,
    online_portal_url,
    required_documents,
    processing_time_days,
    fees
) VALUES 
    ('Kementerian Hukum dan HAM RI', 'kemenkumham', 'national', 'Budi Santoso', '+62-21-3441-5555', 'info@kemenkumham.go.id', '{"street": "Jl. HR Rasuna Said Kav. 6-7", "city": "Jakarta Selatan", "postal_code": "12940"}', '08:00-16:00 WIB', 'https://ahu.go.id', ARRAY['Akta Pendirian', 'Anggaran Dasar'], 14, '{"sk_pengesahan": 500000}'),
    ('OSS (Online Single Submission)', 'oss', 'national', 'Customer Service OSS', '+62-21-1500-175', 'cs@oss.go.id', '{"street": "Online Platform", "city": "Jakarta", "postal_code": ""}', '24/7 Online', 'https://oss.go.id', ARRAY['SIUP', 'TDP', 'NIB'], 7, '{"siup": 300000, "tdp": 250000}'),
    ('Direktorat Jenderal Pajak', 'pajak', 'national', 'KPP Jakarta Selatan', '+62-21-7394-4000', 'kpp.jaksel@pajak.go.id', '{"street": "Jl. Prapatan Raya No. 142", "city": "Jakarta Selatan", "postal_code": "12790"}', '08:00-15:00 WIB', 'https://djp.kemenkeu.go.id', ARRAY['NPWP', 'PKP'], 3, '{"npwp": 0, "pkp": 0}'),
    ('Kementerian Pariwisata dan Ekonomi Kreatif', 'kemenparekraf', 'national', 'Direktorat Musik', '+62-21-3838-4899', 'musik@kemenparekraf.go.id', '{"street": "Jl. Medan Merdeka Barat No. 17", "city": "Jakarta Pusat", "postal_code": "10110"}', '08:00-16:00 WIB', 'https://kemenparekraf.go.id', ARRAY['Izin Usaha Musik'], 21, '{"izin_usaha_musik": 1000000}');

-- Insert compliance checklist
INSERT INTO public.compliance_checklist (
    registration_id,
    compliance_area,
    requirement_name,
    requirement_description,
    is_mandatory,
    completion_status,
    completion_date,
    due_date
) VALUES 
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'corporate', 'Akta Pendirian', 'Akta pendirian yayasan yang disahkan notaris', true, true, '2024-01-15', '2024-  'Akta Pendirian', 'Akta pendirian yayasan yang disahkan notaris', true, true, '2024-01-15', '2024-01-15'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'corporate', 'SK Kemenkumham', 'Surat Keputusan pengesahan badan hukum', true, true, '2024-01-25', '2024-01-25'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'corporate', 'Anggaran Dasar', 'Anggaran dasar dan anggaran rumah tangga', true, true, '2024-01-15', '2024-01-15'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'corporate', 'Struktur Kepengurusan', 'Penetapan struktur pengurus dan pengawas', true, true, '2024-01-20', '2024-01-20'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'tax', 'NPWP Registration', 'Nomor Pokok Wajib Pajak yayasan', true, true, '2024-01-30', '2024-01-30'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'tax', 'PKP Registration', 'Pengukuhan Pengusaha Kena Pajak', true, false, NULL, '2024-02-15'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'tax', 'Tax Reporting Setup', 'Setup sistem pelaporan pajak bulanan', true, false, NULL, '2024-02-20'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'licensing', 'SIUP', 'Surat Izin Usaha Perdagangan', true, false, NULL, '2024-02-10'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'licensing', 'TDP', 'Tanda Daftar Perusahaan', true, false, NULL, '2024-02-15'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'licensing', 'Izin Usaha Musik', 'Izin usaha khusus bidang musik', true, false, NULL, '2024-03-01'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'licensing', 'Domicile Letter', 'Surat keterangan domisili usaha', true, true, '2024-01-25', '2024-01-25'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'banking', 'Corporate Bank Account', 'Pembukaan rekening bank korporat', true, false, NULL, '2024-02-20'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'banking', 'Authorized Signatories', 'Penetapan pejabat berwenang menandatangani', true, false, NULL, '2024-02-25'),
    ((SELECT id FROM public.legal_entity_registration WHERE entity_name = 'NABILA Collective Music Organization'), 'banking', 'Banking Resolutions', 'Resolusi dewan pengurus untuk perbankan', true, false, NULL, '2024-02-25');
