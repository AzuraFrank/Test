-- Legal entity registration management
CREATE TYPE registration_status AS ENUM ('draft', 'submitted', 'under_review', 'approved', 'rejected', 'completed');
CREATE TYPE document_type AS ENUM ('akta_pendirian', 'sk_kemenkumham', 'siup', 'tdp', 'npwp', 'izin_usaha', 'domicile_letter', 'board_resolution');
CREATE TYPE authority_type AS ENUM ('kemenkumham', 'oss', 'pajak', 'kemenparekraf', 'notaris', 'bank_indonesia');

-- Legal entity registration process
CREATE TABLE public.legal_entity_registration (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    entity_name TEXT NOT NULL,
    entity_type TEXT NOT NULL, -- 'yayasan', 'perkumpulan', 'pt', 'cv'
    registration_purpose TEXT NOT NULL,
    business_activities TEXT[],
    authorized_capital DECIMAL(15,2),
    paid_capital DECIMAL(15,2),
    shareholders JSONB DEFAULT '{}',
    board_members JSONB DEFAULT '{}',
    registered_address JSONB NOT NULL,
    operational_address JSONB,
    contact_information JSONB NOT NULL,
    registration_status registration_status DEFAULT 'draft',
    submission_date TIMESTAMP WITH TIME ZONE,
    approval_date TIMESTAMP WITH TIME ZONE,
    completion_date TIMESTAMP WITH TIME ZONE,
    registration_numbers JSONB DEFAULT '{}', -- Store all registration numbers
    created_by UUID REFERENCES public.profiles(id),
    assigned_lawyer UUID REFERENCES public.team_members(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Registration documents
CREATE TABLE public.registration_documents (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    registration_id UUID REFERENCES public.legal_entity_registration(id),
    document_type document_type NOT NULL,
    document_name TEXT NOT NULL,
    document_number TEXT,
    issuing_authority authority_type,
    issue_date DATE,
    expiry_date DATE,
    document_url TEXT, -- File storage URL
    document_status TEXT DEFAULT 'pending', -- 'pending', 'approved', 'rejected'
    verification_notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Registration workflow steps
CREATE TABLE public.registration_workflow (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    registration_id UUID REFERENCES public.legal_entity_registration(id),
    step_name TEXT NOT NULL,
    step_order INTEGER NOT NULL,
    authority authority_type,
    required_documents document_type[],
    estimated_duration_days INTEGER,
    actual_duration_days INTEGER,
    step_status TEXT DEFAULT 'pending', -- 'pending', 'in_progress', 'completed', 'rejected'
    started_date TIMESTAMP WITH TIME ZONE,
    completed_date TIMESTAMP WITH TIME ZONE,
    notes TEXT,
    assigned_to UUID REFERENCES public.team_members(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Government authority contacts
CREATE TABLE public.government_authorities (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    authority_name TEXT NOT NULL,
    authority_type authority_type NOT NULL,
    jurisdiction TEXT NOT NULL, -- 'national', 'provincial', 'city'
    contact_person TEXT,
    phone_number TEXT,
    email TEXT,
    address JSONB,
    office_hours TEXT,
    online_portal_url TEXT,
    required_documents TEXT[],
    processing_time_days INTEGER,
    fees JSONB DEFAULT '{}',
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Legal compliance checklist
CREATE TABLE public.compliance_checklist (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    registration_id UUID REFERENCES public.legal_entity_registration(id),
    compliance_area TEXT NOT NULL, -- 'corporate', 'tax', 'licensing', 'banking'
    requirement_name TEXT NOT NULL,
    requirement_description TEXT,
    is_mandatory BOOLEAN DEFAULT true,
    completion_status BOOLEAN DEFAULT false,
    completion_date TIMESTAMP WITH TIME ZONE,
    evidence_documents TEXT[],
    responsible_person UUID REFERENCES public.team_members(id),
    due_date DATE,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
