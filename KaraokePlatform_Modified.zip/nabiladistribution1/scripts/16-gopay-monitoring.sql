-- GoPay real-time monitoring tables
CREATE TABLE public.gopay_balance_history (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    account_id TEXT NOT NULL DEFAULT 'G082083595',
    balance_amount DECIMAL(15,2) NOT NULL,
    available_balance DECIMAL(15,2) NOT NULL,
    pending_balance DECIMAL(15,2) DEFAULT 0,
    currency_code TEXT NOT NULL DEFAULT 'IDR',
    balance_timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    sync_timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    metadata JSONB DEFAULT '{}'
);

-- GoPay transaction monitoring
CREATE TABLE public.gopay_transactions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    transaction_id TEXT UNIQUE NOT NULL,
    order_id TEXT,
    transaction_type TEXT NOT NULL, -- 'payment', 'refund', 'settlement', 'fee'
    amount DECIMAL(15,2) NOT NULL,
    currency TEXT NOT NULL DEFAULT 'IDR',
    status TEXT NOT NULL, -- 'pending', 'settlement', 'capture', 'deny', 'cancel', 'expire', 'failure'
    payment_type TEXT DEFAULT 'gopay',
    transaction_time TIMESTAMP WITH TIME ZONE NOT NULL,
    settlement_time TIMESTAMP WITH TIME ZONE,
    merchant_id TEXT DEFAULT 'G082083595',
    gross_amount DECIMAL(15,2),
    fraud_status TEXT,
    customer_details JSONB,
    item_details JSONB,
    raw_response JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- GoPay monitoring alerts
CREATE TABLE public.gopay_monitoring_alerts (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    alert_type TEXT NOT NULL, -- 'low_balance', 'failed_transaction', 'high_volume', 'suspicious_activity'
    severity TEXT NOT NULL DEFAULT 'medium', -- 'low', 'medium', 'high', 'critical'
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    threshold_value DECIMAL(15,2),
    current_value DECIMAL(15,2),
    is_resolved BOOLEAN DEFAULT false,
    resolved_at TIMESTAMP WITH TIME ZONE,
    resolved_by UUID REFERENCES public.team_members(id),
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- GoPay API sync logs
CREATE TABLE public.gopay_sync_logs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    sync_type TEXT NOT NULL, -- 'balance', 'transactions', 'status_check'
    sync_status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'success', 'failed', 'partial'
    records_processed INTEGER DEFAULT 0,
    records_failed INTEGER DEFAULT 0,
    sync_start_time TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    sync_end_time TIMESTAMP WITH TIME ZONE,
    error_message TEXT,
    api_response JSONB,
    next_sync_time TIMESTAMP WITH TIME ZONE
);

-- Create indexes for better performance
CREATE INDEX idx_gopay_balance_timestamp ON public.gopay_balance_history(balance_timestamp DESC);
CREATE INDEX idx_gopay_transactions_time ON public.gopay_transactions(transaction_time DESC);
CREATE INDEX idx_gopay_transactions_status ON public.gopay_transactions(status);
CREATE INDEX idx_gopay_alerts_created ON public.gopay_monitoring_alerts(created_at DESC);
CREATE INDEX idx_gopay_alerts_unresolved ON public.gopay_monitoring_alerts(is_resolved) WHERE is_resolved = false;
