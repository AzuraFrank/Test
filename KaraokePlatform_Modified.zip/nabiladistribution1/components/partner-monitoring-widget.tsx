"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Wifi, WifiOff, AlertTriangle, Clock, RefreshCw } from "lucide-react"

interface PartnerStatus {
  platform: string
  status: "connected" | "disconnected" | "error" | "rate_limited"
  responseTime: number
  uptime: number
  lastSync: string
  apiUsage: { used: number; total: number }
  errorCount: number
}

export function PartnerMonitoringWidget() {
  const [partnerStatuses, setPartnerStatuses] = useState<PartnerStatus[]>([
    {
      platform: "Spotify",
      status: "connected",
      responseTime: 120,
      uptime: 99.98,
      lastSync: "2 minutes ago",
      apiUsage: { used: 847, total: 1000 },
      errorCount: 0,
    },
    {
      platform: "Apple Music",
      status: "connected",
      responseTime: 95,
      uptime: 99.95,
      lastSync: "5 minutes ago",
      apiUsage: { used: 623, total: 1000 },
      errorCount: 0,
    },
    {
      platform: "YouTube Music",
      status: "connected",
      responseTime: 180,
      uptime: 99.92,
      lastSync: "1 minute ago",
      apiUsage: { used: 1234, total: 2000 },
      errorCount: 1,
    },
    {
      platform: "Amazon Music",
      status: "connected",
      responseTime: 110,
      uptime: 99.89,
      lastSync: "8 minutes ago",
      apiUsage: { used: 456, total: 1000 },
      errorCount: 0,
    },
    {
      platform: "TikTok",
      status: "rate_limited",
      responseTime: 250,
      uptime: 98.45,
      lastSync: "15 minutes ago",
      apiUsage: { used: 500, total: 500 },
      errorCount: 3,
    },
    {
      platform: "Deezer",
      status: "connected",
      responseTime: 140,
      uptime: 99.97,
      lastSync: "3 minutes ago",
      apiUsage: { used: 234, total: 1000 },
      errorCount: 0,
    },
  ])

  const [isRefreshing, setIsRefreshing] = useState(false)

  const refreshStatuses = async () => {
    setIsRefreshing(true)
    // Simulate API call to refresh statuses
    setTimeout(() => {
      setPartnerStatuses((prev) =>
        prev.map((partner) => ({
          ...partner,
          responseTime: Math.floor(Math.random() * 100) + 80,
          lastSync: "Just now",
          apiUsage: {
            ...partner.apiUsage,
            used: Math.min(partner.apiUsage.used + Math.floor(Math.random() * 10), partner.apiUsage.total),
          },
        })),
      )
      setIsRefreshing(false)
    }, 2000)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "connected":
        return <Wifi className="w-4 h-4 text-green-600" />
      case "rate_limited":
        return <Clock className="w-4 h-4 text-yellow-600" />
      case "error":
      case "disconnected":
        return <WifiOff className="w-4 h-4 text-red-600" />
      default:
        return <AlertTriangle className="w-4 h-4 text-gray-600" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "connected":
        return <Badge className="bg-green-100 text-green-800">Connected</Badge>
      case "rate_limited":
        return <Badge className="bg-yellow-100 text-yellow-800">Rate Limited</Badge>
      case "error":
        return <Badge className="bg-red-100 text-red-800">Error</Badge>
      case "disconnected":
        return <Badge className="bg-gray-100 text-gray-800">Disconnected</Badge>
      default:
        return <Badge variant="secondary">Unknown</Badge>
    }
  }

  const connectedCount = partnerStatuses.filter((p) => p.status === "connected").length
  const totalCount = partnerStatuses.length
  const avgResponseTime = Math.round(partnerStatuses.reduce((sum, p) => sum + p.responseTime, 0) / totalCount)
  const avgUptime = (partnerStatuses.reduce((sum, p) => sum + p.uptime, 0) / totalCount).toFixed(2)

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center space-x-2">
              <span>Partner Platform Status</span>
              <Badge className="bg-gradient-to-r from-green-600 to-blue-600 text-white">
                {connectedCount}/{totalCount} Online
              </Badge>
            </CardTitle>
            <CardDescription>Real-time monitoring semua platform streaming partner</CardDescription>
          </div>
          <Button
            onClick={refreshStatuses}
            disabled={isRefreshing}
            variant="outline"
            size="sm"
            className="bg-white text-gray-700"
          >
            <RefreshCw className={`w-4 h-4 mr-1 ${isRefreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {/* Summary Stats */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="text-center p-3 bg-gray-50 rounded-lg">
            <div className="text-2xl font-bold text-gray-900">{avgResponseTime}ms</div>
            <p className="text-sm text-gray-600">Avg Response Time</p>
          </div>
          <div className="text-center p-3 bg-gray-50 rounded-lg">
            <div className="text-2xl font-bold text-gray-900">{avgUptime}%</div>
            <p className="text-sm text-gray-600">Avg Uptime</p>
          </div>
          <div className="text-center p-3 bg-gray-50 rounded-lg">
            <div className="text-2xl font-bold text-gray-900">
              {partnerStatuses.reduce((sum, p) => sum + p.errorCount, 0)}
            </div>
            <p className="text-sm text-gray-600">Total Errors</p>
          </div>
        </div>

        {/* Platform Status List */}
        <div className="space-y-3">
          {partnerStatuses.map((partner, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                {getStatusIcon(partner.status)}
                <div>
                  <p className="font-medium text-gray-900">{partner.platform}</p>
                  <p className="text-sm text-gray-600">Last sync: {partner.lastSync}</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-900">{partner.responseTime}ms</p>
                  <p className="text-xs text-gray-600">Response</p>
                </div>

                <div className="text-center">
                  <p className="text-sm font-medium text-gray-900">{partner.uptime}%</p>
                  <p className="text-xs text-gray-600">Uptime</p>
                </div>

                <div className="text-center">
                  <p className="text-sm font-medium text-gray-900">
                    {partner.apiUsage.used}/{partner.apiUsage.total}
                  </p>
                  <p className="text-xs text-gray-600">API Usage</p>
                </div>

                <div className="text-center">
                  <p className="text-sm font-medium text-gray-900">{partner.errorCount}</p>
                  <p className="text-xs text-gray-600">Errors</p>
                </div>

                {getStatusBadge(partner.status)}
              </div>
            </div>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="mt-6 pt-4 border-t">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-600">
              Monitoring aktif 24/7 • Last updated: {new Date().toLocaleTimeString()}
            </p>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" className="bg-white text-gray-700">
                View Logs
              </Button>
              <Button variant="outline" size="sm" className="bg-white text-gray-700">
                Configure Alerts
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
