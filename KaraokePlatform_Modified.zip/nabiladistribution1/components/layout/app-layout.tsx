"use client"

import type React from "react"

import { useState } from "react"
import { cn } from "@/lib/utils"
import { Sidebar } from "@/components/navigation/sidebar"
import { Breadcrumbs } from "@/components/navigation/breadcrumbs"
import { QuickActions } from "@/components/quick-actions"
import { StatusBar } from "@/components/status-bar"

interface AppLayoutProps {
  children: React.ReactNode
  className?: string
}

export function AppLayout({ children, className }: AppLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      {/* Status Bar */}
      <StatusBar />

      <div className="flex h-screen">
        {/* Sidebar */}
        <Sidebar className="w-64 border-r" />

        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
            <div className="container flex h-14 items-center justify-between px-4">
              <Breadcrumbs />
              <QuickActions />
            </div>
          </header>

          {/* Page Content */}
          <main className={cn("flex-1 overflow-y-auto", className)}>{children}</main>
        </div>
      </div>
    </div>
  )
}
