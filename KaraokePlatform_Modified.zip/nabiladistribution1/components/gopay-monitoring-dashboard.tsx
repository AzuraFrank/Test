"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Wallet,
  AlertTriangle,
  RefreshCw,
  DollarSign,
  Activity,
  Clock,
  CheckCircle,
  XCircle,
  Phone,
  CreditCard,
} from "lucide-react"

interface GopayBalance {
  balance_amount: number
  available_balance: number
  pending_balance: number
  currency_code: string
  balance_timestamp: string
}

interface GopayTransaction {
  transaction_id: string
  order_id: string
  amount: number
  status: string
  transaction_time: string
  payment_type: string
}

interface GopayAlert {
  id: string
  alert_type: string
  severity: string
  title: string
  message: string
  current_value: number
  created_at: string
  is_resolved: boolean
}

export function GopayMonitoringDashboard() {
  const [balance, setBalance] = useState<GopayBalance | null>(null)
  const [transactions, setTransactions] = useState<GopayTransaction[]>([])
  const [alerts, setAlerts] = useState<GopayAlert[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isSyncing, setIsSyncing] = useState(false)
  const [lastSync, setLastSync] = useState<string>("")

  useEffect(() => {
    fetchGopayData()

    // Set up real-time updates every 30 seconds
    const interval = setInterval(fetchGopayData, 30000)
    return () => clearInterval(interval)
  }, [])

  const fetchGopayData = async () => {
    try {
      const response = await fetch("/api/gopay/sync")
      const data = await response.json()

      if (data.latestBalance) {
        setBalance(data.latestBalance)
      }

      setAlerts(data.alerts || [])
      setLastSync(new Date().toLocaleTimeString())
      setIsLoading(false)
    } catch (error) {
      console.error("Error fetching GoPay data:", error)
      setIsLoading(false)
    }
  }

  const syncGopayData = async (syncType = "all") => {
    setIsSyncing(true)
    try {
      const response = await fetch("/api/gopay/sync", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ syncType }),
      })

      const result = await response.json()
      if (result.success) {
        await fetchGopayData()
      }
    } catch (error) {
      console.error("Error syncing GoPay data:", error)
    } finally {
      setIsSyncing(false)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case "settlement":
      case "capture":
        return <CheckCircle className="w-4 h-4 text-green-600" />
      case "pending":
        return <Clock className="w-4 h-4 text-yellow-600" />
      case "deny":
      case "cancel":
      case "expire":
      case "failure":
        return <XCircle className="w-4 h-4 text-red-600" />
      default:
        return <Activity className="w-4 h-4 text-blue-600" />
    }
  }

  const getAlertSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-red-100 text-red-800"
      case "high":
        return "bg-orange-100 text-orange-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-blue-100 text-blue-800"
    }
  }

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center h-64">
          <RefreshCw className="w-8 h-8 animate-spin text-blue-600" />
          <span className="ml-2">Loading GoPay data...</span>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 flex items-center">
            <Wallet className="w-8 h-8 mr-3 text-green-600" />
            GoPay Admin Monitoring
          </h2>
          <p className="text-gray-600 flex items-center mt-1">
            <Phone className="w-4 h-4 mr-1" />
            0895340205302 • User ID: G082083595
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <Badge className="bg-green-100 text-green-800">
            <Activity className="w-3 h-3 mr-1" />
            Live Monitoring
          </Badge>
          <Button
            onClick={() => syncGopayData()}
            disabled={isSyncing}
            className="bg-gradient-to-r from-green-600 to-blue-600 text-white"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isSyncing ? "animate-spin" : ""}`} />
            {isSyncing ? "Syncing..." : "Sync Now"}
          </Button>
        </div>
      </div>

      {/* Balance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
            <Wallet className="h-4 w-4" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Rp {balance?.balance_amount?.toLocaleString() || "0"}</div>
            <p className="text-xs text-green-100">
              Last updated:{" "}
              {balance?.balance_timestamp ? new Date(balance.balance_timestamp).toLocaleTimeString() : "Never"}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Available Balance</CardTitle>
            <DollarSign className="h-4 w-4" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Rp {balance?.available_balance?.toLocaleString() || "0"}</div>
            <p className="text-xs text-blue-100">Ready for transactions</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Balance</CardTitle>
            <Clock className="h-4 w-4" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Rp {balance?.pending_balance?.toLocaleString() || "0"}</div>
            <p className="text-xs text-yellow-100">Processing settlements</p>
          </CardContent>
        </Card>
      </div>

      {/* Alerts Section */}
      {alerts.length > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="flex items-center text-orange-800">
              <AlertTriangle className="w-5 h-5 mr-2" />
              Active Alerts ({alerts.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {alerts.map((alert) => (
              <div key={alert.id} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                <div className="flex items-center space-x-3">
                  <AlertTriangle className="w-5 h-5 text-orange-600" />
                  <div>
                    <p className="font-medium text-gray-900">{alert.title}</p>
                    <p className="text-sm text-gray-600">{alert.message}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge className={getAlertSeverityColor(alert.severity)}>{alert.severity.toUpperCase()}</Badge>
                  <span className="text-xs text-gray-500">{new Date(alert.created_at).toLocaleTimeString()}</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Detailed Monitoring */}
      <Tabs defaultValue="realtime" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="realtime">Real-time Status</TabsTrigger>
          <TabsTrigger value="transactions">Transaction History</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="realtime" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Account Status</CardTitle>
                <CardDescription>Real-time GoPay account monitoring</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">Account Status</p>
                      <p className="text-sm text-gray-600">Active & Verified</p>
                    </div>
                  </div>
                  <Badge className="bg-green-100 text-green-800">ACTIVE</Badge>
                </div>

                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <CreditCard className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">Payment Gateway</p>
                      <p className="text-sm text-gray-600">Midtrans Integration</p>
                    </div>
                  </div>
                  <Badge className="bg-blue-100 text-blue-800">CONNECTED</Badge>
                </div>

                <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                      <Activity className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">API Status</p>
                      <p className="text-sm text-gray-600">Last sync: {lastSync}</p>
                    </div>
                  </div>
                  <Badge className="bg-purple-100 text-purple-800">SYNCED</Badge>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Balance Trend</CardTitle>
                <CardDescription>Balance changes over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Available Balance</span>
                    <span className="font-medium">Rp {balance?.available_balance?.toLocaleString() || "0"}</span>
                  </div>
                  <Progress
                    value={balance ? (balance.available_balance / (balance.balance_amount || 1)) * 100 : 0}
                    className="h-2"
                  />

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Pending Balance</span>
                    <span className="font-medium">Rp {balance?.pending_balance?.toLocaleString() || "0"}</span>
                  </div>
                  <Progress
                    value={balance ? (balance.pending_balance / (balance.balance_amount || 1)) * 100 : 0}
                    className="h-2"
                  />

                  <div className="pt-4 border-t">
                    <div className="text-center">
                      <p className="text-2xl font-bold text-gray-900">
                        Rp {balance?.balance_amount?.toLocaleString() || "0"}
                      </p>
                      <p className="text-sm text-gray-600">Total Balance</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="transactions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Transactions</CardTitle>
              <CardDescription>Latest GoPay transaction activity</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {transactions.length === 0 ? (
                  <div className="text-center py-8">
                    <Activity className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">No recent transactions</p>
                    <Button onClick={() => syncGopayData("transactions")} variant="outline" className="mt-2">
                      Sync Transactions
                    </Button>
                  </div>
                ) : (
                  transactions.map((tx) => (
                    <div
                      key={tx.transaction_id}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                    >
                      <div className="flex items-center space-x-3">
                        {getStatusIcon(tx.status)}
                        <div>
                          <p className="font-medium text-gray-900">Transaction {tx.transaction_id.slice(-8)}</p>
                          <p className="text-sm text-gray-600">{new Date(tx.transaction_time).toLocaleString()}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-gray-900">Rp {tx.amount.toLocaleString()}</p>
                        <Badge variant="outline" className="text-xs">
                          {tx.status.toUpperCase()}
                        </Badge>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Daily Volume</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">Rp 0</div>
                <p className="text-xs text-gray-600">Today's transactions</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Success Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">100%</div>
                <p className="text-xs text-gray-600">Transaction success</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Avg Response</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">120ms</div>
                <p className="text-xs text-gray-600">API response time</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Uptime</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">99.9%</div>
                <p className="text-xs text-gray-600">Service availability</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>GoPay Configuration</CardTitle>
              <CardDescription>Current payment gateway settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-700">User ID</label>
                  <p className="text-sm text-gray-900 bg-gray-50 p-2 rounded">G082083595</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Phone Number</label>
                  <p className="text-sm text-gray-900 bg-gray-50 p-2 rounded">0895340205302</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Environment</label>
                  <p className="text-sm text-gray-900 bg-gray-50 p-2 rounded">Production</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Auto Sync</label>
                  <p className="text-sm text-gray-900 bg-gray-50 p-2 rounded">Every 30 seconds</p>
                </div>
              </div>

              <div className="pt-4 border-t">
                <Button
                  onClick={() => syncGopayData()}
                  className="w-full bg-gradient-to-r from-green-600 to-blue-600 text-white"
                >
                  Test Connection & Sync
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
