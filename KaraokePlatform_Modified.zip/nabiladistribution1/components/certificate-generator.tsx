"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Award,
  Download,
  Share2,
  Shield,
  CheckCircle,
  Calendar,
  Building2,
  Globe,
  FileText,
  Printer,
} from "lucide-react"

interface CertificateData {
  entityName: string
  registrationDate: string
  certificateNumber: string
  issuingAuthority: string
  validUntil: string
  registrationNumbers: {
    aktaPendirian: string
    skKemenkumham: string
    npwp: string
    siup: string
    tdp: string
  }
  internationalAffiliations: string[]
  authorizedActivities: string[]
}

export function CertificateGenerator() {
  const [certificateData] = useState<CertificateData>({
    entityName: "NABILA Collective Music Organization",
    registrationDate: "March 15, 2024",
    certificateNumber: "NCMO-CERT-2024-001",
    issuingAuthority: "Ministry of Law and Human Rights, Republic of Indonesia",
    validUntil: "Perpetual",
    registrationNumbers: {
      aktaPendirian: "No. 123 Tanggal 15 Januari 2024",
      skKemenkumham: "AHU-0001234.AH.01.04.2024",
      npwp: "01.234.567.8-901.000",
      siup: "510/1.824.1/2024",
      tdp: "09.05.1.72.12345",
    },
    internationalAffiliations: [
      "CISAC (International Confederation of Societies of Authors and Composers)",
      "IFPI (International Federation of the Phonographic Industry)",
      "WIPO (World Intellectual Property Organization)",
      "ASCAP (American Society of Composers, Authors and Publishers)",
    ],
    authorizedActivities: [
      "Collective Management of Musical Copyrights",
      "Royalty Distribution and Collection",
      "Performance Rights Licensing",
      "Music Industry Advocacy",
      "Digital Music Technology Services",
      "Intellectual Property Rights Management",
    ],
  })

  const handleDownloadCertificate = () => {
    // Generate PDF certificate
    console.log("Generating PDF certificate...")
  }

  const handleShareCertificate = () => {
    // Share certificate via social media or email
    console.log("Sharing certificate...")
  }

  const handlePrintCertificate = () => {
    // Print certificate
    window.print()
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Certificate Actions */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Legal Entity Certificate</h1>
          <p className="text-gray-600">Official registration certificate for NABILA Collective Music Organization</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline" onClick={handlePrintCertificate}>
            <Printer className="w-4 h-4 mr-2" />
            Print
          </Button>
          <Button variant="outline" onClick={handleShareCertificate}>
            <Share2 className="w-4 h-4 mr-2" />
            Share
          </Button>
          <Button
            className="bg-gradient-to-r from-blue-600 to-purple-600 text-white"
            onClick={handleDownloadCertificate}
          >
            <Download className="w-4 h-4 mr-2" />
            Download PDF
          </Button>
        </div>
      </div>

      {/* Main Certificate */}
      <Card className="bg-gradient-to-br from-blue-50 via-white to-purple-50 border-4 border-blue-200 shadow-2xl">
        <CardHeader className="text-center pb-8">
          {/* Header with Logo and Title */}
          <div className="flex justify-center mb-6">
            <div className="w-24 h-24 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center shadow-lg">
              <Award className="w-12 h-12 text-white" />
            </div>
          </div>

          <div className="space-y-4">
            <div className="text-center">
              <h1 className="text-4xl font-bold text-gray-900 mb-2">CERTIFICATE OF INCORPORATION</h1>
              <h2 className="text-2xl font-semibold text-blue-800 mb-1">SERTIFIKAT PENDIRIAN BADAN HUKUM</h2>
              <p className="text-lg text-gray-600">Republic of Indonesia</p>
            </div>

            <div className="flex justify-center">
              <Badge className="bg-gradient-to-r from-green-600 to-blue-600 text-white px-6 py-3 text-lg">
                <Shield className="w-5 h-5 mr-2" />
                LEGALLY ESTABLISHED & RECOGNIZED
              </Badge>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-8 px-12 pb-12">
          {/* Entity Information */}
          <div className="text-center space-y-6">
            <div className="p-8 bg-white rounded-xl border-2 border-blue-100 shadow-lg">
              <h2 className="text-3xl font-bold text-blue-900 mb-3">{certificateData.entityName}</h2>
              <p className="text-xl text-gray-700 mb-2">NABILA Collective Music Organization</p>
              <p className="text-lg text-gray-600">Yayasan Pengelola Hak Cipta Musik Kolektif</p>

              <div className="flex justify-center mt-6">
                <div className="flex items-center space-x-2 text-green-700">
                  <CheckCircle className="w-6 h-6" />
                  <span className="text-lg font-semibold">Legally Incorporated</span>
                </div>
              </div>
            </div>
          </div>

          {/* Certificate Details */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Registration Information */}
            <div className="space-y-6">
              <div className="flex items-center space-x-3 mb-4">
                <FileText className="w-6 h-6 text-blue-600" />
                <h3 className="text-2xl font-semibold text-gray-900">Registration Details</h3>
              </div>

              <div className="space-y-4">
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-600 font-medium">Certificate Number</p>
                  <p className="text-lg font-bold text-blue-900">{certificateData.certificateNumber}</p>
                </div>

                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <p className="text-sm text-green-600 font-medium">Registration Date</p>
                  <p className="text-lg font-bold text-green-900">{certificateData.registrationDate}</p>
                </div>

                <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                  <p className="text-sm text-purple-600 font-medium">Valid Until</p>
                  <p className="text-lg font-bold text-purple-900">{certificateData.validUntil}</p>
                </div>
              </div>

              {/* Official Numbers */}
              <div className="space-y-3">
                <h4 className="text-lg font-semibold text-gray-900">Official Registration Numbers</h4>
                {Object.entries(certificateData.registrationNumbers).map(([key, value]) => (
                  <div key={key} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm font-medium text-gray-600 capitalize">
                      {key.replace(/([A-Z])/g, " $1").trim()}:
                    </span>
                    <span className="text-sm font-bold text-gray-900">{value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Authorizations and Affiliations */}
            <div className="space-y-6">
              <div className="flex items-center space-x-3 mb-4">
                <Building2 className="w-6 h-6 text-blue-600" />
                <h3 className="text-2xl font-semibold text-gray-900">Authorizations</h3>
              </div>

              {/* Authorized Activities */}
              <div className="space-y-3">
                <h4 className="text-lg font-semibold text-gray-900">Authorized Business Activities</h4>
                <div className="space-y-2">
                  {certificateData.authorizedActivities.map((activity, index) => (
                    <div
                      key={index}
                      className="flex items-start space-x-3 p-3 bg-green-50 rounded-lg border border-green-200"
                    >
                      <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-green-800">{activity}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* International Affiliations */}
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Globe className="w-5 h-5 text-blue-600" />
                  <h4 className="text-lg font-semibold text-gray-900">International Affiliations</h4>
                </div>
                <div className="space-y-2">
                  {certificateData.internationalAffiliations.map((affiliation, index) => (
                    <div key={index} className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                      <span className="text-sm text-blue-800 font-medium">{affiliation}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Legal Status Confirmations */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 bg-green-50 rounded-xl border-2 border-green-200 text-center">
              <Shield className="w-8 h-8 text-green-600 mx-auto mb-3" />
              <h4 className="font-semibold text-green-800 mb-2">Legal Compliance</h4>
              <p className="text-sm text-green-700">Fully compliant with Indonesian corporate law and regulations</p>
            </div>

            <div className="p-6 bg-blue-50 rounded-xl border-2 border-blue-200 text-center">
              <Globe className="w-8 h-8 text-blue-600 mx-auto mb-3" />
              <h4 className="font-semibold text-blue-800 mb-2">International Recognition</h4>
              <p className="text-sm text-blue-700">Recognized by international music industry organizations</p>
            </div>

            <div className="p-6 bg-purple-50 rounded-xl border-2 border-purple-200 text-center">
              <Award className="w-8 h-8 text-purple-600 mx-auto mb-3" />
              <h4 className="font-semibold text-purple-800 mb-2">Operational Authority</h4>
              <p className="text-sm text-purple-700">Authorized to operate as collective music organization</p>
            </div>
          </div>

          {/* Certificate Footer */}
          <div className="border-t-2 border-gray-200 pt-8">
            <div className="flex items-center justify-between">
              <div className="text-left">
                <p className="text-sm text-gray-600 mb-1">Issued by:</p>
                <p className="font-semibold text-gray-900 text-lg">{certificateData.issuingAuthority}</p>
                <p className="text-sm text-gray-600">Republic of Indonesia</p>
              </div>

              <div className="text-center">
                <div className="flex items-center space-x-2 text-gray-600 mb-2">
                  <Calendar className="w-5 h-5" />
                  <span className="text-sm font-medium">Date of Issuance</span>
                </div>
                <p className="font-bold text-gray-900 text-lg">{certificateData.registrationDate}</p>
              </div>

              <div className="text-right">
                <div className="w-32 h-32 bg-gradient-to-br from-blue-100 to-purple-100 rounded-lg flex items-center justify-center border-2 border-blue-300">
                  <div className="text-center">
                    <Shield className="w-8 h-8 text-blue-600 mx-auto mb-1" />
                    <p className="text-xs text-blue-800 font-bold">OFFICIAL</p>
                    <p className="text-xs text-blue-600">SEAL</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Digital Verification */}
          <div className="text-center pt-6 border-t border-gray-200">
            <div className="inline-flex items-center space-x-3 px-6 py-3 bg-green-50 rounded-full border border-green-200">
              <Shield className="w-5 h-5 text-green-600" />
              <span className="text-sm text-green-800 font-semibold">Digitally Verified & Authenticated</span>
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-xs text-gray-500 mt-2">
              This certificate is digitally signed and can be verified at: verify.nabila-music.com
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Additional Information */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileText className="w-5 h-5 text-blue-600" />
              <span>Certificate Validity</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Status:</span>
                <Badge className="bg-green-600 text-white">Active</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Valid Until:</span>
                <span className="font-semibold">Perpetual</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Last Verified:</span>
                <span className="font-semibold">March 15, 2024</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Next Review:</span>
                <span className="font-semibold">March 15, 2025</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Globe className="w-5 h-5 text-blue-600" />
              <span>International Status</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">CISAC Member:</span>
                <Badge variant="outline" className="text-blue-700 border-blue-500">
                  Pending
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">IFPI Affiliate:</span>
                <Badge variant="outline" className="text-blue-700 border-blue-500">
                  Pending
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">WIPO Registration:</span>
                <Badge variant="outline" className="text-blue-700 border-blue-500">
                  In Progress
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Regional Recognition:</span>
                <Badge className="bg-green-600 text-white">ASEAN</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
