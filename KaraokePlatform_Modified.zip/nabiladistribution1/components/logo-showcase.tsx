"use client"

import { Logo, AnimatedLogo } from "./logo"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function LogoShowcase() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white">NABILA DISTRIBUTION</h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">Modern Logo Design System</p>
          <Badge variant="secondary" className="text-sm">
            Enterprise Grade • Music Distribution • Global Marketplace
          </Badge>
        </div>

        {/* Main Logo Display */}
        <Card className="bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm border-0 shadow-xl">
          <CardHeader className="text-center">
            <CardTitle>Primary Logo</CardTitle>
            <CardDescription>Full logo with gradient theme</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center py-12">
            <Logo variant="full" size="xl" theme="gradient" />
          </CardContent>
        </Card>

        {/* Logo Variations */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Icon Only */}
          <Card className="bg-white dark:bg-slate-800">
            <CardHeader>
              <CardTitle className="text-lg">Icon Only</CardTitle>
              <CardDescription>Perfect for favicons and small spaces</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center py-8">
              <Logo variant="icon" size="lg" theme="gradient" />
            </CardContent>
          </Card>

          {/* Text Only */}
          <Card className="bg-white dark:bg-slate-800">
            <CardHeader>
              <CardTitle className="text-lg">Text Only</CardTitle>
              <CardDescription>Clean typography version</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center py-8">
              <Logo variant="text" size="lg" theme="gradient" />
            </CardContent>
          </Card>

          {/* Animated Version */}
          <Card className="bg-white dark:bg-slate-800">
            <CardHeader>
              <CardTitle className="text-lg">Animated</CardTitle>
              <CardDescription>Special occasions and loading states</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center py-8">
              <AnimatedLogo size="lg" />
            </CardContent>
          </Card>
        </div>

        {/* Size Variations */}
        <Card className="bg-white dark:bg-slate-800">
          <CardHeader>
            <CardTitle>Size Variations</CardTitle>
            <CardDescription>Scalable for all use cases</CardDescription>
          </CardHeader>
          <CardContent className="space-y-8">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Extra Large (XL)</span>
              <Logo variant="full" size="xl" theme="gradient" />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Large (LG)</span>
              <Logo variant="full" size="lg" theme="gradient" />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Medium (MD)</span>
              <Logo variant="full" size="md" theme="gradient" />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Small (SM)</span>
              <Logo variant="full" size="sm" theme="gradient" />
            </div>
          </CardContent>
        </Card>

        {/* Theme Variations */}
        <Card className="bg-white dark:bg-slate-800">
          <CardHeader>
            <CardTitle>Theme Variations</CardTitle>
            <CardDescription>Adaptable to any brand context</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Gradient Theme */}
            <div className="text-center space-y-4">
              <h4 className="font-semibold">Gradient (Default)</h4>
              <div className="bg-gradient-to-br from-slate-50 to-slate-100 p-6 rounded-lg">
                <Logo variant="full" size="lg" theme="gradient" />
              </div>
            </div>

            {/* Light Theme */}
            <div className="text-center space-y-4">
              <h4 className="font-semibold">Light Theme</h4>
              <div className="bg-white p-6 rounded-lg border">
                <Logo variant="full" size="lg" theme="light" />
              </div>
            </div>

            {/* Dark Theme */}
            <div className="text-center space-y-4">
              <h4 className="font-semibold">Dark Theme</h4>
              <div className="bg-slate-900 p-6 rounded-lg">
                <Logo variant="full" size="lg" theme="dark" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Logo Meaning */}
        <Card className="bg-gradient-to-r from-indigo-500/10 via-purple-500/10 to-pink-500/10 border-0">
          <CardHeader>
            <CardTitle>Logo Design Philosophy</CardTitle>
            <CardDescription>Every element has meaning and purpose</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <div className="w-3 h-3 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full mt-1.5"></div>
                <div>
                  <h4 className="font-semibold">Sound Waves</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Represent music, audio, and the core of our distribution business
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="w-3 h-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full mt-1.5"></div>
                <div>
                  <h4 className="font-semibold">Network Connections</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Global distribution network connecting artists to 150+ platforms
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="w-3 h-3 bg-gradient-to-r from-pink-500 to-indigo-500 rounded-full mt-1.5"></div>
                <div>
                  <h4 className="font-semibold">Central 'N' Symbol</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    NABILA brand identity with modern, tech-forward styling
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <div className="w-3 h-3 bg-gradient-to-r from-green-500 to-cyan-500 rounded-full mt-1.5"></div>
                <div>
                  <h4 className="font-semibold">Gradient Colors</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Innovation, creativity, and the dynamic nature of music
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="w-3 h-3 bg-gradient-to-r from-cyan-500 to-indigo-500 rounded-full mt-1.5"></div>
                <div>
                  <h4 className="font-semibold">Circular Design</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Unity, completeness, and global reach of our platform
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="w-3 h-3 bg-gradient-to-r from-indigo-500 to-green-500 rounded-full mt-1.5"></div>
                <div>
                  <h4 className="font-semibold">Modern Typography</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Professional, trustworthy, and enterprise-grade quality
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Usage Guidelines */}
        <Card className="bg-white dark:bg-slate-800">
          <CardHeader>
            <CardTitle>Usage Guidelines</CardTitle>
            <CardDescription>Best practices for logo implementation</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-green-600 mb-3">✅ Do's</h4>
              <ul className="space-y-2 text-sm">
                <li>• Use gradient theme for primary branding</li>
                <li>• Maintain minimum clear space around logo</li>
                <li>• Use icon version for small applications</li>
                <li>• Ensure sufficient contrast on backgrounds</li>
                <li>• Use animated version sparingly for special occasions</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-red-600 mb-3">❌ Don'ts</h4>
              <ul className="space-y-2 text-sm">
                <li>• Don't stretch or distort the logo</li>
                <li>• Don't use on busy backgrounds without backdrop</li>
                <li>• Don't change colors outside of provided themes</li>
                <li>• Don't use below minimum size requirements</li>
                <li>• Don't separate elements or rearrange layout</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
