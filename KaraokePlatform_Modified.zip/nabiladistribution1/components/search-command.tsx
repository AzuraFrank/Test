"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Search, Music, BarChart3, DollarSign, Users, Settings, Globe, Shield, Bot, ShoppingCart } from "lucide-react"

interface SearchResult {
  id: string
  title: string
  description: string
  href: string
  icon: any
  category: string
  badge?: string
}

const searchData: SearchResult[] = [
  // Dashboard & Analytics
  {
    id: "dashboard",
    title: "Dashboard",
    description: "Main dashboard overview",
    href: "/dashboard",
    icon: BarChart3,
    category: "Navigation",
  },
  {
    id: "analytics",
    title: "Analytics",
    description: "Performance metrics and insights",
    href: "/analytics",
    icon: BarChart3,
    category: "Analytics",
  },
  {
    id: "streaming-analytics",
    title: "Streaming Analytics",
    description: "Stream performance data",
    href: "/analytics/streaming",
    icon: Music,
    category: "Analytics",
  },
  {
    id: "revenue-analytics",
    title: "Revenue Analytics",
    description: "Financial performance metrics",
    href: "/analytics/revenue",
    icon: DollarSign,
    category: "Analytics",
  },

  // Music Management
  {
    id: "upload-music",
    title: "Upload Music",
    description: "Upload new tracks for distribution",
    href: "/music/upload",
    icon: Music,
    category: "Music",
  },
  {
    id: "my-tracks",
    title: "My Tracks",
    description: "Manage your music library",
    href: "/music/tracks",
    icon: Music,
    category: "Music",
  },
  {
    id: "distribution-status",
    title: "Distribution Status",
    description: "Track distribution progress",
    href: "/music/distribution",
    icon: Globe,
    category: "Music",
  },

  // Royalties
  {
    id: "royalties",
    title: "Royalty Management",
    description: "Track earnings and payments",
    href: "/royalties",
    icon: DollarSign,
    category: "Finance",
  },
  {
    id: "earnings",
    title: "Earnings Overview",
    description: "Total earnings summary",
    href: "/royalties/overview",
    icon: DollarSign,
    category: "Finance",
  },
  {
    id: "payment-history",
    title: "Payment History",
    description: "Past payment records",
    href: "/royalties/payments",
    icon: DollarSign,
    category: "Finance",
  },

  // Marketplace
  {
    id: "marketplace",
    title: "Marketplace",
    description: "Buy and sell music products",
    href: "/marketplace",
    icon: ShoppingCart,
    category: "Commerce",
  },
  {
    id: "browse-products",
    title: "Browse Products",
    description: "Discover music products",
    href: "/marketplace/browse",
    icon: ShoppingCart,
    category: "Commerce",
  },
  {
    id: "my-products",
    title: "My Products",
    description: "Manage your listings",
    href: "/marketplace/products",
    icon: ShoppingCart,
    category: "Commerce",
  },

  // Partners
  {
    id: "partners",
    title: "Partner Platforms",
    description: "Manage streaming partnerships",
    href: "/partners",
    icon: Globe,
    category: "Partnerships",
  },
  {
    id: "platform-overview",
    title: "Platform Overview",
    description: "All connected platforms",
    href: "/partners/overview",
    icon: Globe,
    category: "Partnerships",
  },

  // Legal
  {
    id: "legal",
    title: "Legal & Compliance",
    description: "Legal services and compliance",
    href: "/legal",
    icon: Shield,
    category: "Legal",
  },
  {
    id: "ai-legal",
    title: "AI Legal Assistant",
    description: "Legal AI support",
    href: "/legal/ai-assistant",
    icon: Bot,
    category: "Legal",
    badge: "NEW",
  },
  {
    id: "entity-registration",
    title: "Entity Registration",
    description: "Business registration services",
    href: "/legal/registration",
    icon: Shield,
    category: "Legal",
  },

  // AI Tools
  {
    id: "ai-assistant",
    title: "AI Assistant",
    description: "General AI support",
    href: "/ai-assistant",
    icon: Bot,
    category: "AI Tools",
    badge: "NEW",
  },
  {
    id: "ai-support",
    title: "AI Support",
    description: "Customer support AI",
    href: "/ai-support",
    icon: Bot,
    category: "AI Tools",
  },
  {
    id: "ai-marketing",
    title: "AI Marketing",
    description: "Marketing automation",
    href: "/ai-marketing",
    icon: Bot,
    category: "AI Tools",
  },

  // Admin
  {
    id: "admin",
    title: "Administration",
    description: "System administration",
    href: "/admin",
    icon: Settings,
    category: "Admin",
  },
  {
    id: "team-management",
    title: "Team Management",
    description: "Manage team members",
    href: "/admin/team",
    icon: Users,
    category: "Admin",
  },
  {
    id: "gopay-monitor",
    title: "GoPay Monitor",
    description: "Payment gateway monitoring",
    href: "/admin/gopay",
    icon: DollarSign,
    category: "Admin",
    badge: "LIVE",
  },
]

export function SearchCommand() {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState("")
  const router = useRouter()

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault()
        setOpen((open) => !open)
      }
    }
    document.addEventListener("keydown", down)
    return () => document.removeEventListener("keydown", down)
  }, [])

  const filteredResults = searchData.filter(
    (item) =>
      item.title.toLowerCase().includes(query.toLowerCase()) ||
      item.description.toLowerCase().includes(query.toLowerCase()) ||
      item.category.toLowerCase().includes(query.toLowerCase()),
  )

  const groupedResults = filteredResults.reduce(
    (acc, item) => {
      if (!acc[item.category]) {
        acc[item.category] = []
      }
      acc[item.category].push(item)
      return acc
    },
    {} as Record<string, SearchResult[]>,
  )

  const handleSelect = (href: string) => {
    setOpen(false)
    router.push(href)
  }

  return (
    <>
      <Button
        variant="outline"
        className="relative h-9 w-9 p-0 xl:h-10 xl:w-60 xl:justify-start xl:px-3 xl:py-2"
        onClick={() => setOpen(true)}
      >
        <Search className="h-4 w-4 xl:mr-2" />
        <span className="hidden xl:inline-flex">Search...</span>
        <kbd className="pointer-events-none absolute right-1.5 top-2 hidden h-6 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium opacity-100 xl:flex">
          <span className="text-xs">⌘</span>K
        </kbd>
      </Button>

      <CommandDialog open={open} onOpenChange={setOpen}>
        <CommandInput placeholder="Search features, pages, and tools..." value={query} onValueChange={setQuery} />
        <CommandList>
          <CommandEmpty>No results found.</CommandEmpty>
          {Object.entries(groupedResults).map(([category, items]) => (
            <div key={category}>
              <CommandGroup heading={category}>
                {items.map((item) => (
                  <CommandItem
                    key={item.id}
                    value={item.title}
                    onSelect={() => handleSelect(item.href)}
                    className="flex items-center space-x-3"
                  >
                    <item.icon className="h-4 w-4" />
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <span className="font-medium">{item.title}</span>
                        {item.badge && (
                          <Badge variant="secondary" className="text-xs">
                            {item.badge}
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
              <CommandSeparator />
            </div>
          ))}
        </CommandList>
      </CommandDialog>
    </>
  )
}
