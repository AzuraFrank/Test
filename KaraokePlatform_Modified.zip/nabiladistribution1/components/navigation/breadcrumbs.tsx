"use client"

import { usePathname } from "next/navigation"
import Link from "next/link"
import { ChevronRight, Home } from "lucide-react"
import { cn } from "@/lib/utils"

interface BreadcrumbItem {
  label: string
  href: string
  current?: boolean
}

const routeLabels: Record<string, string> = {
  dashboard: "Dashboard",
  music: "Music",
  upload: "Upload",
  tracks: "Tracks",
  distribution: "Distribution",
  metadata: "Metadata",
  calendar: "Calendar",
  analytics: "Analytics",
  streaming: "Streaming",
  revenue: "Revenue",
  audience: "Audience",
  geographic: "Geographic",
  platforms: "Platforms",
  royalties: "Royalties",
  overview: "Overview",
  payments: "Payments",
  calculator: "Calculator",
  tax: "Tax",
  settings: "Settings",
  marketplace: "Marketplace",
  browse: "Browse",
  products: "Products",
  orders: "Orders",
  sales: "Sales",
  reviews: "Reviews",
  partners: "Partners",
  integrations: "Integrations",
  requirements: "Requirements",
  legal: "Legal",
  "ai-assistant": "AI Assistant",
  registration: "Registration",
  contracts: "Contracts",
  compliance: "Compliance",
  international: "International",
  ai: "AI Tools",
  "ai-support": "AI Support",
  "ai-marketing": "AI Marketing",
  content: "Content",
  trends: "Trends",
  admin: "Admin",
  team: "Team",
  gopay: "GoPay",
  users: "Users",
  security: "Security",
  "complete-dashboard": "Complete Dashboard",
}

export function Breadcrumbs() {
  const pathname = usePathname()

  const generateBreadcrumbs = (): BreadcrumbItem[] => {
    const segments = pathname.split("/").filter(Boolean)
    const breadcrumbs: BreadcrumbItem[] = []

    // Add home
    breadcrumbs.push({
      label: "Home",
      href: "/dashboard",
    })

    // Add segments
    let currentPath = ""
    segments.forEach((segment, index) => {
      currentPath += `/${segment}`
      const isLast = index === segments.length - 1

      breadcrumbs.push({
        label: routeLabels[segment] || segment.charAt(0).toUpperCase() + segment.slice(1),
        href: currentPath,
        current: isLast,
      })
    })

    return breadcrumbs
  }

  const breadcrumbs = generateBreadcrumbs()

  if (breadcrumbs.length <= 1) {
    return null
  }

  return (
    <nav className="flex items-center space-x-1 text-sm text-muted-foreground">
      {breadcrumbs.map((item, index) => (
        <div key={item.href} className="flex items-center">
          {index > 0 && <ChevronRight className="h-4 w-4 mx-1" />}
          {item.current ? (
            <span className="font-medium text-foreground">{item.label}</span>
          ) : (
            <Link
              href={item.href}
              className={cn("hover:text-foreground transition-colors", index === 0 && "flex items-center")}
            >
              {index === 0 && <Home className="h-4 w-4 mr-1" />}
              {item.label}
            </Link>
          )}
        </div>
      ))}
    </nav>
  )
}
