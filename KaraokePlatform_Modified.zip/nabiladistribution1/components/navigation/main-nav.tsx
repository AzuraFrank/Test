"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/lib/auth-context"
import {
  Music,
  BarChart3,
  DollarSign,
  Users,
  Settings,
  Globe,
  Shield,
  FileText,
  Headphones,
  Zap,
  Bot,
  ShoppingCart,
  CreditCard,
  Building2,
  Award,
  Search,
  Upload,
  Eye,
  TrendingUp,
  Wallet,
  MessageSquare,
  Calendar,
  Archive,
  Lock,
  Disc,
  Star,
  MapPin,
  CheckCircle,
  HelpCircle,
  ChevronDown,
  ChevronRight,
  Calculator,
} from "lucide-react"

interface NavItem {
  title: string
  href: string
  icon: any
  badge?: string
  description?: string
  children?: NavItem[]
  roles?: string[]
  isNew?: boolean
  isComingSoon?: boolean
}

const navigationItems: NavItem[] = [
  {
    title: "Dashboard",
    href: "/dashboard",
    icon: BarChart3,
    description: "Overview and analytics",
  },
  {
    title: "Music Distribution",
    href: "/music",
    icon: Music,
    description: "Manage your music catalog",
    children: [
      {
        title: "Upload Music",
        href: "/music/upload",
        icon: Upload,
        description: "Upload new tracks",
      },
      {
        title: "My Tracks",
        href: "/music/tracks",
        icon: Disc,
        description: "Manage your music library",
      },
      {
        title: "Distribution Status",
        href: "/music/distribution",
        icon: Globe,
        description: "Track distribution progress",
      },
      {
        title: "Metadata Manager",
        href: "/music/metadata",
        icon: FileText,
        description: "Edit track information",
      },
      {
        title: "Release Calendar",
        href: "/music/calendar",
        icon: Calendar,
        description: "Schedule releases",
      },
    ],
  },
  {
    title: "Analytics & Insights",
    href: "/analytics",
    icon: TrendingUp,
    description: "Performance metrics",
    children: [
      {
        title: "Streaming Analytics",
        href: "/analytics/streaming",
        icon: Headphones,
        description: "Stream performance data",
      },
      {
        title: "Revenue Analytics",
        href: "/analytics/revenue",
        icon: DollarSign,
        description: "Financial performance",
      },
      {
        title: "Audience Insights",
        href: "/analytics/audience",
        icon: Users,
        description: "Listener demographics",
      },
      {
        title: "Geographic Data",
        href: "/analytics/geographic",
        icon: MapPin,
        description: "Global performance",
      },
      {
        title: "Platform Performance",
        href: "/analytics/platforms",
        icon: Globe,
        description: "Platform-specific data",
      },
    ],
  },
  {
    title: "Royalty Management",
    href: "/royalties",
    icon: DollarSign,
    description: "Track earnings and payments",
    children: [
      {
        title: "Earnings Overview",
        href: "/royalties/overview",
        icon: BarChart3,
        description: "Total earnings summary",
      },
      {
        title: "Payment History",
        href: "/royalties/payments",
        icon: CreditCard,
        description: "Past payment records",
      },
      {
        title: "Royalty Calculator",
        href: "/royalties/calculator",
        icon: Calculator,
        description: "Estimate earnings",
      },
      {
        title: "Tax Documents",
        href: "/royalties/tax",
        icon: FileText,
        description: "Tax forms and reports",
      },
      {
        title: "Payment Settings",
        href: "/royalties/settings",
        icon: Settings,
        description: "Configure payment methods",
      },
    ],
  },
  {
    title: "Marketplace",
    href: "/marketplace",
    icon: ShoppingCart,
    description: "Buy and sell music products",
    children: [
      {
        title: "Browse Products",
        href: "/marketplace/browse",
        icon: Search,
        description: "Discover music products",
      },
      {
        title: "My Products",
        href: "/marketplace/products",
        icon: Archive,
        description: "Manage your listings",
      },
      {
        title: "Orders",
        href: "/marketplace/orders",
        icon: ShoppingCart,
        description: "Track your orders",
      },
      {
        title: "Sales Dashboard",
        href: "/marketplace/sales",
        icon: TrendingUp,
        description: "Monitor your sales",
      },
      {
        title: "Reviews & Ratings",
        href: "/marketplace/reviews",
        icon: Star,
        description: "Customer feedback",
      },
    ],
  },
  {
    title: "Partner Platforms",
    href: "/partners",
    icon: Globe,
    description: "Manage streaming partnerships",
    children: [
      {
        title: "Platform Overview",
        href: "/partners/overview",
        icon: Globe,
        description: "All connected platforms",
      },
      {
        title: "Integration Status",
        href: "/partners/integrations",
        icon: Zap,
        description: "API connections",
      },
      {
        title: "Revenue Tracking",
        href: "/partners/revenue",
        icon: DollarSign,
        description: "Platform earnings",
      },
      {
        title: "Requirements",
        href: "/partners/requirements",
        icon: CheckCircle,
        description: "Platform requirements",
      },
      {
        title: "Marketplace Partners",
        href: "/partners/marketplace",
        icon: ShoppingCart,
        description: "Marketplace integrations",
      },
    ],
  },
  {
    title: "Legal & Compliance",
    href: "/legal",
    icon: Shield,
    description: "Legal services and compliance",
    children: [
      {
        title: "AI Legal Assistant",
        href: "/legal/ai-assistant",
        icon: Bot,
        description: "Legal AI support",
        isNew: true,
      },
      {
        title: "Entity Registration",
        href: "/legal/registration",
        icon: Building2,
        description: "Business registration",
      },
      {
        title: "Contract Management",
        href: "/legal/contracts",
        icon: FileText,
        description: "Legal agreements",
      },
      {
        title: "Compliance Monitor",
        href: "/legal/compliance",
        icon: Shield,
        description: "Regulatory compliance",
      },
      {
        title: "International Law",
        href: "/legal/international",
        icon: Globe,
        description: "Global legal requirements",
      },
    ],
  },
  {
    title: "AI Tools",
    href: "/ai",
    icon: Bot,
    description: "AI-powered features",
    badge: "NEW",
    children: [
      {
        title: "AI Assistant",
        href: "/ai-assistant",
        icon: MessageSquare,
        description: "General AI support",
      },
      {
        title: "AI Support",
        href: "/ai-support",
        icon: HelpCircle,
        description: "Customer support AI",
      },
      {
        title: "AI Marketing",
        href: "/ai-marketing",
        icon: TrendingUp,
        description: "Marketing automation",
      },
      {
        title: "Content Analysis",
        href: "/ai/content",
        icon: Eye,
        description: "AI content analysis",
        isComingSoon: true,
      },
      {
        title: "Trend Prediction",
        href: "/ai/trends",
        icon: TrendingUp,
        description: "Market trend analysis",
        isComingSoon: true,
      },
    ],
  },
  {
    title: "Administration",
    href: "/admin",
    icon: Settings,
    description: "System administration",
    roles: ["admin", "super_admin"],
    children: [
      {
        title: "Team Management",
        href: "/admin/team",
        icon: Users,
        description: "Manage team members",
        roles: ["admin", "super_admin"],
      },
      {
        title: "GoPay Monitor",
        href: "/admin/gopay",
        icon: Wallet,
        description: "Payment gateway monitoring",
        roles: ["admin", "super_admin"],
        badge: "LIVE",
      },
      {
        title: "System Settings",
        href: "/admin/settings",
        icon: Settings,
        description: "System configuration",
        roles: ["super_admin"],
      },
      {
        title: "User Management",
        href: "/admin/users",
        icon: Users,
        description: "Manage all users",
        roles: ["admin", "super_admin"],
      },
      {
        title: "Analytics Dashboard",
        href: "/admin/analytics",
        icon: BarChart3,
        description: "System analytics",
        roles: ["admin", "super_admin"],
      },
      {
        title: "Security Center",
        href: "/admin/security",
        icon: Lock,
        description: "Security monitoring",
        roles: ["super_admin"],
      },
    ],
  },
  {
    title: "Complete Dashboard",
    href: "/complete-dashboard",
    icon: Award,
    description: "Comprehensive overview",
    badge: "PREMIUM",
  },
]

interface MainNavProps {
  className?: string
}

export function MainNav({ className }: MainNavProps) {
  const pathname = usePathname()
  const { profile } = useAuth()
  const [expandedItems, setExpandedItems] = useState<string[]>([])

  const toggleExpanded = (title: string) => {
    setExpandedItems((prev) => (prev.includes(title) ? prev.filter((item) => item !== title) : [...prev, title]))
  }

  const hasAccess = (item: NavItem) => {
    if (!item.roles) return true
    if (!profile) return false
    return item.roles.includes(profile.user_type)
  }

  const isActive = (href: string) => {
    if (href === "/dashboard") return pathname === href
    return pathname.startsWith(href)
  }

  const renderNavItem = (item: NavItem, level = 0) => {
    if (!hasAccess(item)) return null

    const hasChildren = item.children && item.children.length > 0
    const isExpanded = expandedItems.includes(item.title)
    const active = isActive(item.href)

    return (
      <div key={item.title} className={cn("space-y-1", level > 0 && "ml-4")}>
        <div className="flex items-center">
          {hasChildren ? (
            <Button
              variant="ghost"
              className={cn(
                "w-full justify-start h-auto p-2 font-normal",
                active && "bg-accent text-accent-foreground",
              )}
              onClick={() => toggleExpanded(item.title)}
            >
              <item.icon className="mr-2 h-4 w-4" />
              <span className="flex-1 text-left">{item.title}</span>
              {item.badge && (
                <Badge variant="secondary" className="ml-2 text-xs">
                  {item.badge}
                </Badge>
              )}
              {item.isNew && (
                <Badge variant="default" className="ml-2 text-xs bg-green-500">
                  NEW
                </Badge>
              )}
              {hasChildren && (
                <div className="ml-2">
                  {isExpanded ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
                </div>
              )}
            </Button>
          ) : (
            <Button
              variant="ghost"
              className={cn(
                "w-full justify-start h-auto p-2 font-normal",
                active && "bg-accent text-accent-foreground",
                item.isComingSoon && "opacity-50 cursor-not-allowed",
              )}
              asChild={!item.isComingSoon}
              disabled={item.isComingSoon}
            >
              {item.isComingSoon ? (
                <div>
                  <item.icon className="mr-2 h-4 w-4" />
                  <span className="flex-1 text-left">{item.title}</span>
                  <Badge variant="outline" className="ml-2 text-xs">
                    SOON
                  </Badge>
                </div>
              ) : (
                <Link href={item.href}>
                  <item.icon className="mr-2 h-4 w-4" />
                  <span className="flex-1 text-left">{item.title}</span>
                  {item.badge && (
                    <Badge variant="secondary" className="ml-2 text-xs">
                      {item.badge}
                    </Badge>
                  )}
                  {item.isNew && (
                    <Badge variant="default" className="ml-2 text-xs bg-green-500">
                      NEW
                    </Badge>
                  )}
                </Link>
              )}
            </Button>
          )}
        </div>

        {hasChildren && isExpanded && (
          <div className="space-y-1 ml-4">{item.children?.map((child) => renderNavItem(child, level + 1))}</div>
        )}
      </div>
    )
  }

  return (
    <ScrollArea className={cn("h-full", className)}>
      <div className="space-y-2 p-2">
        <div className="px-3 py-2">
          <h2 className="mb-2 px-4 text-lg font-semibold tracking-tight">Navigation</h2>
          <div className="space-y-1">{navigationItems.map((item) => renderNavItem(item))}</div>
        </div>
      </div>
    </ScrollArea>
  )
}
