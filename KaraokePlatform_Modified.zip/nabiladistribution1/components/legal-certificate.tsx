"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Award, Download, Shield, CheckCircle, Calendar, Building2, Gavel, FileText } from "lucide-react"

interface LegalCertificateProps {
  entityName: string
  registrationNumbers: {
    aktaPendirian: string
    skKemenkumham: string
    npwp: string
    siup: string
    tdp: string
    izinUsahaMusik: string
  }
  completionDate: string
  issuedBy: string
}

export function LegalCertificate({ entityName, registrationNumbers, completionDate, issuedBy }: LegalCertificateProps) {
  return (
    <Card className="max-w-4xl mx-auto bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200">
      <CardHeader className="text-center pb-6">
        <div className="flex justify-center mb-4">
          <div className="w-20 h-20 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
            <Award className="w-10 h-10 text-white" />
          </div>
        </div>
        <CardTitle className="text-3xl font-bold text-gray-900 mb-2">
          CERTIFICATE OF LEGAL ENTITY REGISTRATION
        </CardTitle>
        <p className="text-lg text-gray-600">SERTIFIKAT PENGESAHAN BADAN HUKUM</p>
        <div className="flex justify-center mt-4">
          <Badge className="bg-gradient-to-r from-green-600 to-blue-600 text-white px-4 py-2">
            <Shield className="w-4 h-4 mr-2" />
            LEGALLY ESTABLISHED
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-8">
        {/* Entity Information */}
        <div className="text-center space-y-4">
          <div className="p-6 bg-white rounded-lg border-2 border-blue-100">
            <h2 className="text-2xl font-bold text-blue-900 mb-2">{entityName}</h2>
            <p className="text-lg text-gray-700">NABILA Collective Music Organization</p>
            <p className="text-gray-600">Yayasan Pengelola Hak Cipta Musik Kolektif</p>
          </div>
        </div>

        {/* Registration Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-900 flex items-center">
              <FileText className="w-5 h-5 mr-2 text-blue-600" />
              Registration Numbers
            </h3>
            <div className="space-y-3">
              {[
                { label: "Akta Pendirian", value: registrationNumbers.aktaPendirian, status: "complete" },
                { label: "SK Kemenkumham", value: registrationNumbers.skKemenkumham, status: "complete" },
                { label: "NPWP", value: registrationNumbers.npwp, status: "complete" },
                { label: "SIUP", value: registrationNumbers.siup, status: "pending" },
                { label: "TDP", value: registrationNumbers.tdp, status: "pending" },
                { label: "Izin Usaha Musik", value: registrationNumbers.izinUsahaMusik, status: "pending" },
              ].map((reg, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                  <div>
                    <p className="font-medium text-gray-900">{reg.label}</p>
                    <p className="text-sm text-gray-600">{reg.value}</p>
                  </div>
                  <Badge variant={reg.status === "complete" ? "default" : "outline"}>
                    {reg.status === "complete" ? <CheckCircle className="w-3 h-3 mr-1" /> : null}
                    {reg.status === "complete" ? "Complete" : "Pending"}
                  </Badge>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-900 flex items-center">
              <Building2 className="w-5 h-5 mr-2 text-blue-600" />
              Legal Status
            </h3>
            <div className="space-y-3">
              <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                <div className="flex items-center space-x-2 mb-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="font-semibold text-green-800">Legally Established</span>
                </div>
                <p className="text-sm text-green-700">
                  Entity is legally recognized and authorized to operate as a collective music organization
                </p>
              </div>

              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="flex items-center space-x-2 mb-2">
                  <Gavel className="w-5 h-5 text-blue-600" />
                  <span className="font-semibold text-blue-800">Regulatory Compliance</span>
                </div>
                <p className="text-sm text-blue-700">
                  Compliant with Indonesian corporate law and music industry regulations
                </p>
              </div>

              <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                <div className="flex items-center space-x-2 mb-2">
                  <Shield className="w-5 h-5 text-purple-600" />
                  <span className="font-semibold text-purple-800">International Recognition</span>
                </div>
                <p className="text-sm text-purple-700">
                  Affiliated with CISAC, IFPI, and other international music organizations
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Authorized Activities */}
        <div className="space-y-4">
          <h3 className="text-xl font-semibold text-gray-900">Authorized Business Activities</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              "Pengelolaan Hak Cipta Musik Kolektif",
              "Distribusi Royalti Musik",
              "Lisensi Hak Pertunjukan",
              "Advokasi Industri Musik",
              "Layanan Teknologi Musik Digital",
              "Manajemen Hak Kekayaan Intelektual",
            ].map((activity, index) => (
              <div key={index} className="flex items-center space-x-2 p-3 bg-white rounded-lg border">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-gray-800">{activity}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Certificate Footer */}
        <div className="border-t pt-6">
          <div className="flex items-center justify-between">
            <div className="text-left">
              <p className="text-sm text-gray-600">Issued by:</p>
              <p className="font-semibold text-gray-900">{issuedBy}</p>
              <p className="text-sm text-gray-600">Republic of Indonesia</p>
            </div>

            <div className="text-center">
              <div className="flex items-center space-x-2 text-gray-600 mb-2">
                <Calendar className="w-4 h-4" />
                <span className="text-sm">Completion Date</span>
              </div>
              <p className="font-semibold text-gray-900">{completionDate}</p>
            </div>

            <div className="text-right">
              <Button className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                <Download className="w-4 h-4 mr-2" />
                Download Certificate
              </Button>
            </div>
          </div>
        </div>

        {/* Digital Signature */}
        <div className="text-center pt-4 border-t">
          <p className="text-xs text-gray-500 mb-2">This certificate is digitally signed and verified</p>
          <div className="flex justify-center items-center space-x-2">
            <Shield className="w-4 h-4 text-green-600" />
            <span className="text-sm text-green-700 font-medium">Digitally Verified</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
