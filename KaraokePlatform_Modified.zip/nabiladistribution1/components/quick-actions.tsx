"use client"

import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useRouter } from "next/navigation"
import { Plus, Upload, BarChart3, DollarSign, Bot, Settings, Zap } from "lucide-react"

export function QuickActions() {
  const router = useRouter()

  const actions = [
    {
      label: "Upload Music",
      icon: Upload,
      href: "/music/upload",
      description: "Upload new tracks",
    },
    {
      label: "View Analytics",
      icon: BarChart3,
      href: "/analytics",
      description: "Performance insights",
    },
    {
      label: "Check Royalties",
      icon: DollarSign,
      href: "/royalties",
      description: "Earnings overview",
    },
    {
      label: "AI Assistant",
      icon: Bot,
      href: "/ai-assistant",
      description: "Get AI help",
    },
    {
      label: "GoPay Monitor",
      icon: Zap,
      href: "/admin/gopay",
      description: "Payment monitoring",
    },
    {
      label: "Settings",
      icon: Settings,
      href: "/settings",
      description: "Account settings",
    },
  ]

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button size="sm" className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
          <Plus className="h-4 w-4 mr-2" />
          Quick Actions
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56" align="end">
        <DropdownMenuLabel>Quick Actions</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {actions.map((action) => (
          <DropdownMenuItem
            key={action.href}
            onClick={() => router.push(action.href)}
            className="flex items-center space-x-2 cursor-pointer"
          >
            <action.icon className="h-4 w-4" />
            <div className="flex flex-col">
              <span className="font-medium">{action.label}</span>
              <span className="text-xs text-muted-foreground">{action.description}</span>
            </div>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
