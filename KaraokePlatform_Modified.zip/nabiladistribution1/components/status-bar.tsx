"use client"

import { useState, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { Wifi, WifiOff, Zap, AlertTriangle, CheckCircle, Clock } from "lucide-react"

interface SystemStatus {
  online: boolean
  apiStatus: "operational" | "degraded" | "down"
  gopayStatus: "connected" | "disconnected" | "error"
  lastSync: Date
  activeUsers: number
}

export function StatusBar() {
  const [status, setStatus] = useState<SystemStatus>({
    online: true,
    apiStatus: "operational",
    gopayStatus: "connected",
    lastSync: new Date(),
    activeUsers: 1247,
  })

  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "operational":
      case "connected":
        return <CheckCircle className="h-3 w-3 text-green-500" />
      case "degraded":
        return <AlertTriangle className="h-3 w-3 text-yellow-500" />
      case "down":
      case "disconnected":
      case "error":
        return <AlertTriangle className="h-3 w-3 text-red-500" />
      default:
        return <Clock className="h-3 w-3 text-gray-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "operational":
      case "connected":
        return "bg-green-100 text-green-800"
      case "degraded":
        return "bg-yellow-100 text-yellow-800"
      case "down":
      case "disconnected":
      case "error":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="bg-slate-900 text-white text-xs py-1 px-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          {/* System Status */}
          <div className="flex items-center space-x-1">
            {status.online ? <Wifi className="h-3 w-3 text-green-400" /> : <WifiOff className="h-3 w-3 text-red-400" />}
            <span className="text-green-400">System Online</span>
          </div>

          {/* API Status */}
          <div className="flex items-center space-x-1">
            {getStatusIcon(status.apiStatus)}
            <span>API: {status.apiStatus}</span>
          </div>

          {/* GoPay Status */}
          <div className="flex items-center space-x-1">
            <Zap className="h-3 w-3 text-blue-400" />
            <span>GoPay: {status.gopayStatus}</span>
          </div>

          {/* Active Users */}
          <div className="flex items-center space-x-1">
            <span className="text-purple-400">{status.activeUsers} users online</span>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          {/* Last Sync */}
          <div className="flex items-center space-x-1">
            <Clock className="h-3 w-3 text-gray-400" />
            <span className="text-gray-400">Last sync: {status.lastSync.toLocaleTimeString()}</span>
          </div>

          {/* Current Time */}
          <div className="text-gray-300">
            {currentTime.toLocaleString("en-US", {
              weekday: "short",
              year: "numeric",
              month: "short",
              day: "numeric",
              hour: "2-digit",
              minute: "2-digit",
              second: "2-digit",
            })}
          </div>

          {/* Environment Badge */}
          <Badge variant="outline" className="text-xs border-green-400 text-green-400">
            PRODUCTION
          </Badge>
        </div>
      </div>
    </div>
  )
}
