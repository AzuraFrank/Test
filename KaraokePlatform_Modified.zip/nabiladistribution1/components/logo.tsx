"use client"

interface LogoProps {
  variant?: "full" | "icon" | "text"
  size?: "sm" | "md" | "lg" | "xl"
  theme?: "light" | "dark" | "gradient"
  className?: string
}

export function Logo({ variant = "full", size = "md", theme = "gradient", className = "" }: LogoProps) {
  const sizeClasses = {
    sm: "h-8",
    md: "h-12",
    lg: "h-16",
    xl: "h-24",
  }

  const getColors = () => {
    switch (theme) {
      case "light":
        return {
          primary: "#000000",
          secondary: "#666666",
          accent: "#333333",
        }
      case "dark":
        return {
          primary: "#FFFFFF",
          secondary: "#CCCCCC",
          accent: "#EEEEEE",
        }
      case "gradient":
      default:
        return {
          primary: "url(#logoGradient)",
          secondary: "url(#logoGradient2)",
          accent: "#6366F1",
        }
    }
  }

  const colors = getColors()

  if (variant === "icon") {
    return (
      <div className={`${sizeClasses[size]} ${className}`}>
        <svg viewBox="0 0 60 60" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#6366F1" />
              <stop offset="50%" stopColor="#8B5CF6" />
              <stop offset="100%" stopColor="#EC4899" />
            </linearGradient>
            <linearGradient id="logoGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#10B981" />
              <stop offset="100%" stopColor="#06B6D4" />
            </linearGradient>
          </defs>

          {/* Background Circle */}
          <circle cx="30" cy="30" r="28" fill={colors.primary} opacity="0.1" />

          {/* Sound Waves */}
          <path
            d="M15 20 Q20 15 25 20 Q30 25 35 20 Q40 15 45 20"
            stroke={colors.primary}
            strokeWidth="3"
            fill="none"
            strokeLinecap="round"
          />
          <path
            d="M12 30 Q18 25 24 30 Q30 35 36 30 Q42 25 48 30"
            stroke={colors.secondary}
            strokeWidth="2.5"
            fill="none"
            strokeLinecap="round"
          />
          <path
            d="M15 40 Q20 35 25 40 Q30 45 35 40 Q40 35 45 40"
            stroke={colors.primary}
            strokeWidth="3"
            fill="none"
            strokeLinecap="round"
          />

          {/* Central N Symbol */}
          <path
            d="M22 25 L22 35 L28 25 L28 35 L34 25 L34 35 L38 25 L38 35"
            stroke={colors.accent}
            strokeWidth="2.5"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Distribution Network Dots */}
          <circle cx="15" cy="15" r="2" fill={colors.secondary} />
          <circle cx="45" cy="15" r="2" fill={colors.secondary} />
          <circle cx="15" cy="45" r="2" fill={colors.secondary} />
          <circle cx="45" cy="45" r="2" fill={colors.secondary} />

          {/* Connection Lines */}
          <line x1="17" y1="17" x2="28" y2="28" stroke={colors.secondary} strokeWidth="1" opacity="0.5" />
          <line x1="43" y1="17" x2="32" y2="28" stroke={colors.secondary} strokeWidth="1" opacity="0.5" />
          <line x1="17" y1="43" x2="28" y2="32" stroke={colors.secondary} strokeWidth="1" opacity="0.5" />
          <line x1="43" y1="43" x2="32" y2="32" stroke={colors.secondary} strokeWidth="1" opacity="0.5" />
        </svg>
      </div>
    )
  }

  if (variant === "text") {
    return (
      <div className={`${className} flex items-center`}>
        <svg viewBox="0 0 300 60" className={sizeClasses[size]} fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="textGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#6366F1" />
              <stop offset="50%" stopColor="#8B5CF6" />
              <stop offset="100%" stopColor="#EC4899" />
            </linearGradient>
          </defs>

          {/* NABILA */}
          <text
            x="10"
            y="35"
            fontSize="24"
            fontWeight="800"
            fill={colors.primary}
            fontFamily="system-ui, -apple-system, sans-serif"
          >
            NABILA
          </text>

          {/* DISTRIBUTION */}
          <text
            x="10"
            y="52"
            fontSize="12"
            fontWeight="600"
            fill={colors.secondary}
            fontFamily="system-ui, -apple-system, sans-serif"
            letterSpacing="2px"
          >
            DISTRIBUTION
          </text>
        </svg>
      </div>
    )
  }

  // Full logo (default)
  return (
    <div className={`${className} flex items-center space-x-3`}>
      <div className={sizeClasses[size]}>
        <svg viewBox="0 0 60 60" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#6366F1" />
              <stop offset="50%" stopColor="#8B5CF6" />
              <stop offset="100%" stopColor="#EC4899" />
            </linearGradient>
            <linearGradient id="logoGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#10B981" />
              <stop offset="100%" stopColor="#06B6D4" />
            </linearGradient>
            <filter id="glow">
              <feGaussianBlur stdDeviation="3" result="coloredBlur" />
              <feMerge>
                <feMergeNode in="coloredBlur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Background Circle with Glow */}
          <circle cx="30" cy="30" r="28" fill={colors.primary} opacity="0.1" />

          {/* Sound Waves */}
          <path
            d="M15 20 Q20 15 25 20 Q30 25 35 20 Q40 15 45 20"
            stroke={colors.primary}
            strokeWidth="3"
            fill="none"
            strokeLinecap="round"
            filter="url(#glow)"
          />
          <path
            d="M12 30 Q18 25 24 30 Q30 35 36 30 Q42 25 48 30"
            stroke={colors.secondary}
            strokeWidth="2.5"
            fill="none"
            strokeLinecap="round"
          />
          <path
            d="M15 40 Q20 35 25 40 Q30 45 35 40 Q40 35 45 40"
            stroke={colors.primary}
            strokeWidth="3"
            fill="none"
            strokeLinecap="round"
            filter="url(#glow)"
          />

          {/* Central N Symbol */}
          <path
            d="M22 25 L22 35 L28 25 L28 35 L34 25 L34 35 L38 25 L38 35"
            stroke={colors.accent}
            strokeWidth="2.5"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Distribution Network */}
          <circle cx="15" cy="15" r="2" fill={colors.secondary} />
          <circle cx="45" cy="15" r="2" fill={colors.secondary} />
          <circle cx="15" cy="45" r="2" fill={colors.secondary} />
          <circle cx="45" cy="45" r="2" fill={colors.secondary} />

          {/* Connection Lines */}
          <line x1="17" y1="17" x2="28" y2="28" stroke={colors.secondary} strokeWidth="1" opacity="0.5" />
          <line x1="43" y1="17" x2="32" y2="28" stroke={colors.secondary} strokeWidth="1" opacity="0.5" />
          <line x1="17" y1="43" x2="28" y2="32" stroke={colors.secondary} strokeWidth="1" opacity="0.5" />
          <line x1="43" y1="43" x2="32" y2="32" stroke={colors.secondary} strokeWidth="1" opacity="0.5" />
        </svg>
      </div>

      <div className="flex flex-col">
        <span
          className={`font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 ${
            size === "sm" ? "text-lg" : size === "md" ? "text-xl" : size === "lg" ? "text-2xl" : "text-3xl"
          }`}
        >
          NABILA
        </span>
        <span
          className={`font-semibold text-gray-600 dark:text-gray-400 tracking-wider ${
            size === "sm" ? "text-xs" : size === "md" ? "text-sm" : size === "lg" ? "text-base" : "text-lg"
          }`}
        >
          DISTRIBUTION
        </span>
      </div>
    </div>
  )
}

// Animated version for special occasions
export function AnimatedLogo({
  className = "",
  size = "md",
}: { className?: string; size?: "sm" | "md" | "lg" | "xl" }) {
  return (
    <div className={`${className} flex items-center space-x-3`}>
      <div
        className={`${size === "sm" ? "h-8" : size === "md" ? "h-12" : size === "lg" ? "h-16" : "h-24"} animate-pulse`}
      >
        <svg viewBox="0 0 60 60" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="animatedGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#6366F1">
                <animate
                  attributeName="stop-color"
                  values="#6366F1;#8B5CF6;#EC4899;#6366F1"
                  dur="3s"
                  repeatCount="indefinite"
                />
              </stop>
              <stop offset="50%" stopColor="#8B5CF6">
                <animate
                  attributeName="stop-color"
                  values="#8B5CF6;#EC4899;#10B981;#8B5CF6"
                  dur="3s"
                  repeatCount="indefinite"
                />
              </stop>
              <stop offset="100%" stopColor="#EC4899">
                <animate
                  attributeName="stop-color"
                  values="#EC4899;#10B981;#06B6D4;#EC4899"
                  dur="3s"
                  repeatCount="indefinite"
                />
              </stop>
            </linearGradient>
          </defs>

          <circle cx="30" cy="30" r="28" fill="url(#animatedGradient)" opacity="0.1" />

          {/* Animated Sound Waves */}
          <path
            d="M15 20 Q20 15 25 20 Q30 25 35 20 Q40 15 45 20"
            stroke="url(#animatedGradient)"
            strokeWidth="3"
            fill="none"
            strokeLinecap="round"
          >
            <animate
              attributeName="d"
              values="M15 20 Q20 15 25 20 Q30 25 35 20 Q40 15 45 20;M15 22 Q20 17 25 22 Q30 27 35 22 Q40 17 45 22;M15 20 Q20 15 25 20 Q30 25 35 20 Q40 15 45 20"
              dur="2s"
              repeatCount="indefinite"
            />
          </path>

          <path
            d="M12 30 Q18 25 24 30 Q30 35 36 30 Q42 25 48 30"
            stroke="url(#animatedGradient)"
            strokeWidth="2.5"
            fill="none"
            strokeLinecap="round"
          >
            <animate
              attributeName="d"
              values="M12 30 Q18 25 24 30 Q30 35 36 30 Q42 25 48 30;M12 32 Q18 27 24 32 Q30 37 36 32 Q42 27 48 32;M12 30 Q18 25 24 30 Q30 35 36 30 Q42 25 48 30"
              dur="2.5s"
              repeatCount="indefinite"
            />
          </path>

          <path
            d="M15 40 Q20 35 25 40 Q30 45 35 40 Q40 35 45 40"
            stroke="url(#animatedGradient)"
            strokeWidth="3"
            fill="none"
            strokeLinecap="round"
          >
            <animate
              attributeName="d"
              values="M15 40 Q20 35 25 40 Q30 45 35 40 Q40 35 45 40;M15 38 Q20 33 25 38 Q30 43 35 38 Q40 33 45 38;M15 40 Q20 35 25 40 Q30 45 35 40 Q40 35 45 40"
              dur="1.8s"
              repeatCount="indefinite"
            />
          </path>

          {/* Central N Symbol */}
          <path
            d="M22 25 L22 35 L28 25 L28 35 L34 25 L34 35 L38 25 L38 35"
            stroke="#6366F1"
            strokeWidth="2.5"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />

          {/* Animated Network Dots */}
          <circle cx="15" cy="15" r="2" fill="url(#animatedGradient)">
            <animate attributeName="r" values="2;3;2" dur="2s" repeatCount="indefinite" />
          </circle>
          <circle cx="45" cy="15" r="2" fill="url(#animatedGradient)">
            <animate attributeName="r" values="2;3;2" dur="2s" begin="0.5s" repeatCount="indefinite" />
          </circle>
          <circle cx="15" cy="45" r="2" fill="url(#animatedGradient)">
            <animate attributeName="r" values="2;3;2" dur="2s" begin="1s" repeatCount="indefinite" />
          </circle>
          <circle cx="45" cy="45" r="2" fill="url(#animatedGradient)">
            <animate attributeName="r" values="2;3;2" dur="2s" begin="1.5s" repeatCount="indefinite" />
          </circle>
        </svg>
      </div>

      <div className="flex flex-col">
        <span
          className={`font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 ${
            size === "sm" ? "text-lg" : size === "md" ? "text-xl" : size === "lg" ? "text-2xl" : "text-3xl"
          }`}
        >
          NABILA
        </span>
        <span
          className={`font-semibold text-gray-600 dark:text-gray-400 tracking-wider ${
            size === "sm" ? "text-xs" : size === "md" ? "text-sm" : size === "lg" ? "text-base" : "text-lg"
          }`}
        >
          DISTRIBUTION
        </span>
      </div>
    </div>
  )
}
