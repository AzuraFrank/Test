"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Label } from "@/components/ui/label"
import {
  Building2,
  CheckCircle,
  Clock,
  AlertCircle,
  Download,
  Upload,
  Eye,
  Edit,
  Send,
  MapPin,
  Phone,
  Mail,
  Users,
  Shield,
} from "lucide-react"
import { AuthGuard } from "@/components/auth-guard"

export default function LegalEntityRegistrationPage() {
  const [activeTab, setActiveTab] = useState("overview")
  const [registrationProgress, setRegistrationProgress] = useState(75)

  const [registrationData, setRegistrationData] = useState({
    entityName: "NABILA Collective Music Organization",
    entityType: "Yayasan",
    registrationPurpose: "Collective Management of Music Rights",
    businessActivities: [
      "Pengelolaan Hak Cipta Musik Kolektif",
      "Distribusi Royalti Musik",
      "Lisensi Hak Pertunjukan",
      "Advokasi Industri Musik",
    ],
    authorizedCapital: 5000000000, // 5 Miliar IDR
    paidCapital: 1000000000, // 1 Miliar IDR
  })

  const [workflowSteps, setWorkflowSteps] = useState([
    {
      id: 1,
      stepName: "Persiapan Dokumen Akta Pendirian",
      authority: "Notaris",
      status: "completed",
      estimatedDays: 3,
      actualDays: 2,
      completedDate: "2024-01-10",
      documents: ["Draft Akta", "Anggaran Dasar", "Anggaran Rumah Tangga"],
    },
    {
      id: 2,
      stepName: "Penandatanganan Akta Pendirian",
      authority: "Notaris",
      status: "completed",
      estimatedDays: 1,
      actualDays: 1,
      completedDate: "2024-01-15",
      documents: ["Akta Pendirian Tertanda"],
    },
    {
      id: 3,
      stepName: "Pengajuan SK Kemenkumham",
      authority: "Kemenkumham",
      status: "completed",
      estimatedDays: 14,
      actualDays: 10,
      completedDate: "2024-01-25",
      documents: ["SK Pengesahan Badan Hukum"],
    },
    {
      id: 4,
      stepName: "Registrasi NPWP",
      authority: "Direktorat Jenderal Pajak",
      status: "completed",
      estimatedDays: 3,
      actualDays: 2,
      completedDate: "2024-01-30",
      documents: ["NPWP Yayasan"],
    },
    {
      id: 5,
      stepName: "Pengurusan SIUP",
      authority: "OSS (Online Single Submission)",
      status: "in_progress",
      estimatedDays: 7,
      actualDays: null,
      startedDate: "2024-02-01",
      documents: ["SIUP Pending"],
    },
    {
      id: 6,
      stepName: "Registrasi TDP",
      authority: "OSS (Online Single Submission)",
      status: "pending",
      estimatedDays: 5,
      actualDays: null,
      documents: ["TDP Application"],
    },
    {
      id: 7,
      stepName: "Izin Usaha Musik",
      authority: "Kementerian Pariwisata",
      status: "pending",
      estimatedDays: 21,
      actualDays: null,
      documents: ["Izin Usaha Musik Application"],
    },
    {
      id: 8,
      stepName: "Pembukaan Rekening Bank",
      authority: "Bank Indonesia",
      status: "pending",
      estimatedDays: 3,
      actualDays: null,
      documents: ["Corporate Banking Account"],
    },
  ])

  const [complianceChecklist, setComplianceChecklist] = useState([
    {
      area: "Corporate Governance",
      items: [
        { name: "Akta Pendirian", status: true, dueDate: "2024-01-15" },
        { name: "SK Kemenkumham", status: true, dueDate: "2024-01-25" },
        { name: "Anggaran Dasar", status: true, dueDate: "2024-01-15" },
        { name: "Struktur Kepengurusan", status: true, dueDate: "2024-01-20" },
      ],
    },
    {
      area: "Tax Compliance",
      items: [
        { name: "NPWP Registration", status: true, dueDate: "2024-01-30" },
        { name: "PKP Registration", status: false, dueDate: "2024-02-15" },
        { name: "Tax Reporting Setup", status: false, dueDate: "2024-02-20" },
      ],
    },
    {
      area: "Business Licensing",
      items: [
        { name: "SIUP", status: false, dueDate: "2024-02-10" },
        { name: "TDP", status: false, dueDate: "2024-02-15" },
        { name: "Izin Usaha Musik", status: false, dueDate: "2024-03-01" },
        { name: "Domicile Letter", status: true, dueDate: "2024-01-25" },
      ],
    },
    {
      area: "Banking & Finance",
      items: [
        { name: "Corporate Bank Account", status: false, dueDate: "2024-02-20" },
        { name: "Authorized Signatories", status: false, dueDate: "2024-02-25" },
        { name: "Banking Resolutions", status: false, dueDate: "2024-02-25" },
      ],
    },
  ])

  const [registrationNumbers, setRegistrationNumbers] = useState({
    aktaPendirian: "No. 123 Tanggal 15 Januari 2024",
    skKemenkumham: "AHU-0001234.AH.01.04.2024",
    npwp: "01.234.567.8-901.000",
    siup: "Pending - 510/1.824.1/2024",
    tdp: "Pending - 09.05.1.72.12345",
    izinUsahaMusik: "Pending Application",
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-600"
      case "in_progress":
        return "bg-blue-600"
      case "pending":
        return "bg-gray-400"
      case "rejected":
        return "bg-red-600"
      default:
        return "bg-gray-400"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-4 h-4" />
      case "in_progress":
        return <Clock className="w-4 h-4" />
      case "pending":
        return <AlertCircle className="w-4 h-4" />
      case "rejected":
        return <AlertCircle className="w-4 h-4" />
      default:
        return <Clock className="w-4 h-4" />
    }
  }

  return (
    <AuthGuard>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <Building2 className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">NCMO Legal Entity Registration</h1>
                <p className="text-gray-600">NABILA Collective Music Organization - Registration Process</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                <Building2 className="w-3 h-3 mr-1" />
                Registration Active
              </Badge>
              <Badge variant="outline" className="text-blue-700 border-blue-500">
                Progress: {registrationProgress}%
              </Badge>
            </div>
          </div>
        </header>

        <div className="p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-6 bg-white">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="workflow">Registration Workflow</TabsTrigger>
              <TabsTrigger value="documents">Documents</TabsTrigger>
              <TabsTrigger value="compliance">Compliance</TabsTrigger>
              <TabsTrigger value="authorities">Government Authorities</TabsTrigger>
              <TabsTrigger value="status">Registration Status</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Registration Progress */}
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle>NABILA Collective Music Organization (NCMO)</CardTitle>
                    <CardDescription>Legal Entity Registration Progress</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700">Registration Progress</span>
                        <span className="text-sm font-medium text-gray-900">{registrationProgress}%</span>
                      </div>
                      <Progress value={registrationProgress} className="h-3" />
                      <p className="text-sm text-gray-600">
                        5 of 8 registration steps completed. Estimated completion: March 15, 2024
                      </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h3 className="font-semibold text-gray-900">Entity Information</h3>
                        <div className="space-y-3">
                          <div>
                            <Label className="text-sm text-gray-600">Entity Name</Label>
                            <p className="font-medium text-gray-900">{registrationData.entityName}</p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-600">Entity Type</Label>
                            <p className="font-medium text-gray-900">{registrationData.entityType}</p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-600">Purpose</Label>
                            <p className="font-medium text-gray-900">{registrationData.registrationPurpose}</p>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <h3 className="font-semibold text-gray-900">Capital Structure</h3>
                        <div className="space-y-3">
                          <div>
                            <Label className="text-sm text-gray-600">Authorized Capital</Label>
                            <p className="font-medium text-gray-900">
                              IDR {registrationData.authorizedCapital.toLocaleString()}
                            </p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-600">Paid Capital</Label>
                            <p className="font-medium text-gray-900">
                              IDR {registrationData.paidCapital.toLocaleString()}
                            </p>
                          </div>
                          <div>
                            <Label className="text-sm text-gray-600">Capital Ratio</Label>
                            <p className="font-medium text-gray-900">
                              {((registrationData.paidCapital / registrationData.authorizedCapital) * 100).toFixed(1)}%
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="font-semibold text-gray-900">Business Activities</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {registrationData.businessActivities.map((activity, index) => (
                          <div key={index} className="p-3 bg-blue-50 rounded-lg">
                            <p className="text-sm text-blue-800">{activity}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Quick Stats */}
                <Card>
                  <CardHeader>
                    <CardTitle>Registration Statistics</CardTitle>
                    <CardDescription>Current status overview</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Completed Steps</span>
                        <Badge variant="outline" className="text-green-700 border-green-500">
                          5/8
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">In Progress</span>
                        <Badge variant="outline" className="text-blue-700 border-blue-500">
                          1
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Pending</span>
                        <Badge variant="outline" className="text-gray-700 border-gray-500">
                          2
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Days Elapsed</span>
                        <Badge variant="outline" className="text-purple-700 border-purple-500">
                          45
                        </Badge>
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <h4 className="font-semibold text-gray-900 mb-3">Registration Numbers</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Akta Pendirian:</span>
                          <span className="font-medium text-green-700">✓ No. 123/2024</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">SK Kemenkumham:</span>
                          <span className="font-medium text-green-700">✓ AHU-0001234</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">NPWP:</span>
                          <span className="font-medium text-green-700">✓ 01.234.567.8</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">SIUP:</span>
                          <span className="font-medium text-blue-700">⏳ In Progress</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">TDP:</span>
                          <span className="font-medium text-gray-700">⏸ Pending</span>
                        </div>
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <h4 className="font-semibold text-gray-900 mb-3">Quick Actions</h4>
                      <div className="space-y-2">
                        <Button variant="outline" className="w-full justify-start bg-white text-gray-700">
                          <Download className="w-4 h-4 mr-2" />
                          Download Documents
                        </Button>
                        <Button variant="outline" className="w-full justify-start bg-white text-gray-700">
                          <Upload className="w-4 h-4 mr-2" />
                          Upload Documents
                        </Button>
                        <Button variant="outline" className="w-full justify-start bg-white text-gray-700">
                          <Eye className="w-4 h-4 mr-2" />
                          View Timeline
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="workflow" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Registration Workflow</h2>
                <Button className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                  <Send className="w-4 h-4 mr-2" />
                  Submit Next Step
                </Button>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Registration Process Timeline</CardTitle>
                  <CardDescription>Step-by-step progress of NCMO legal entity registration</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {workflowSteps.map((step, index) => (
                      <div key={step.id} className="relative">
                        {/* Timeline line */}
                        {index < workflowSteps.length - 1 && (
                          <div className="absolute left-6 top-12 w-0.5 h-16 bg-gray-200"></div>
                        )}

                        <div className="flex items-start space-x-4">
                          {/* Status indicator */}
                          <div
                            className={`w-12 h-12 rounded-full flex items-center justify-center text-white ${getStatusColor(step.status)}`}
                          >
                            {getStatusIcon(step.status)}
                          </div>

                          {/* Step content */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between mb-2">
                              <h3 className="text-lg font-semibold text-gray-900">{step.stepName}</h3>
                              <Badge
                                variant={
                                  step.status === "completed"
                                    ? "default"
                                    : step.status === "in_progress"
                                      ? "secondary"
                                      : "outline"
                                }
                              >
                                {step.status.replace("_", " ").toUpperCase()}
                              </Badge>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-3">
                              <div>
                                <p className="text-sm text-gray-600">Authority</p>
                                <p className="font-medium text-gray-900">{step.authority}</p>
                              </div>
                              <div>
                                <p className="text-sm text-gray-600">Estimated Duration</p>
                                <p className="font-medium text-gray-900">{step.estimatedDays} days</p>
                              </div>
                              <div>
                                <p className="text-sm text-gray-600">Actual Duration</p>
                                <p className="font-medium text-gray-900">
                                  {step.actualDays ? `${step.actualDays} days` : "In progress"}
                                </p>
                              </div>
                              <div>
                                <p className="text-sm text-gray-600">Completion Date</p>
                                <p className="font-medium text-gray-900">
                                  {step.completedDate || step.startedDate || "Not started"}
                                </p>
                              </div>
                            </div>

                            <div className="space-y-2">
                              <p className="text-sm text-gray-600">Required Documents:</p>
                              <div className="flex flex-wrap gap-2">
                                {step.documents.map((doc, docIndex) => (
                                  <Badge key={docIndex} variant="outline" className="text-xs">
                                    {doc}
                                  </Badge>
                                ))}
                              </div>
                            </div>

                            {step.status === "in_progress" && (
                              <div className="mt-3 p-3 bg-blue-50 rounded-lg">
                                <p className="text-sm text-blue-800">
                                  <Clock className="w-4 h-4 inline mr-1" />
                                  Currently in progress. Started on {step.startedDate}
                                </p>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="documents" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Registration Documents</h2>
                <Button className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                  <Upload className="w-4 h-4 mr-2" />
                  Upload Document
                </Button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Completed Documents</CardTitle>
                    <CardDescription>Documents yang telah selesai dan disetujui</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        {
                          name: "Akta Pendirian Yayasan",
                          number: "No. 123 Tanggal 15 Januari 2024",
                          authority: "Notaris Budi Santoso, S.H.",
                          status: "Approved",
                          date: "2024-01-15",
                        },
                        {
                          name: "SK Pengesahan Kemenkumham",
                          number: "AHU-0001234.AH.01.04.2024",
                          authority: "Kementerian Hukum dan HAM",
                          status: "Approved",
                          date: "2024-01-25",
                        },
                        {
                          name: "NPWP Yayasan",
                          number: "01.234.567.8-901.000",
                          authority: "Direktorat Jenderal Pajak",
                          status: "Approved",
                          date: "2024-01-30",
                        },
                        {
                          name: "Surat Keterangan Domisili",
                          number: "SKD/001/2024",
                          authority: "Kelurahan Kebayoran Baru",
                          status: "Approved",
                          date: "2024-01-25",
                        },
                      ].map((doc, index) => (
                        <div key={index} className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="font-semibold text-gray-900">{doc.name}</h3>
                            <Badge className="bg-green-600 text-white">
                              <CheckCircle className="w-3 h-3 mr-1" />
                              {doc.status}
                            </Badge>
                          </div>
                          <div className="space-y-1 text-sm text-gray-600">
                            <p>
                              <strong>Number:</strong> {doc.number}
                            </p>
                            <p>
                              <strong>Authority:</strong> {doc.authority}
                            </p>
                            <p>
                              <strong>Date:</strong> {doc.date}
                            </p>
                          </div>
                          <div className="flex items-center space-x-2 mt-3">
                            <Button variant="outline" size="sm">
                              <Eye className="w-4 h-4 mr-1" />
                              View
                            </Button>
                            <Button variant="outline" size="sm">
                              <Download className="w-4 h-4 mr-1" />
                              Download
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Pending Documents</CardTitle>
                    <CardDescription>Documents yang sedang dalam proses</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        {
                          name: "SIUP (Surat Izin Usaha Perdagangan)",
                          number: "Application #510/1.824.1/2024",
                          authority: "OSS (Online Single Submission)",
                          status: "In Progress",
                          expectedDate: "2024-02-10",
                          progress: 60,
                        },
                        {
                          name: "TDP (Tanda Daftar Perusahaan)",
                          number: "Application #09.05.1.72.12345",
                          authority: "OSS (Online Single Submission)",
                          status: "Pending",
                          expectedDate: "2024-02-15",
                          progress: 0,
                        },
                        {
                          name: "Izin Usaha Musik",
                          number: "Application Submitted",
                          authority: "Kementerian Pariwisata dan Ekonomi Kreatif",
                          status: "Under Review",
                          expectedDate: "2024-03-01",
                          progress: 25,
                        },
                        {
                          name: "Corporate Bank Account",
                          number: "Account Opening Process",
                          authority: "Bank Mandiri",
                          status: "Pending",
                          expectedDate: "2024-02-20",
                          progress: 0,
                        },
                      ].map((doc, index) => (
                        <div key={index} className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="font-semibold text-gray-900">{doc.name}</h3>
                            <Badge variant={doc.status === "In Progress" ? "secondary" : "outline"}>
                              <Clock className="w-3 h-3 mr-1" />
                              {doc.status}
                            </Badge>
                          </div>
                          <div className="space-y-2">
                            <div className="space-y-1 text-sm text-gray-600">
                              <p>
                                <strong>Application:</strong> {doc.number}
                              </p>
                              <p>
                                <strong>Authority:</strong> {doc.authority}
                              </p>
                              <p>
                                <strong>Expected:</strong> {doc.expectedDate}
                              </p>
                            </div>
                            <div className="space-y-1">
                              <div className="flex items-center justify-between text-sm">
                                <span className="text-gray-600">Progress</span>
                                <span className="font-medium">{doc.progress}%</span>
                              </div>
                              <Progress value={doc.progress} className="h-2" />
                            </div>
                          </div>
                          <div className="flex items-center space-x-2 mt-3">
                            <Button variant="outline" size="sm">
                              <Eye className="w-4 h-4 mr-1" />
                              Track
                            </Button>
                            <Button variant="outline" size="sm">
                              <Edit className="w-4 h-4 mr-1" />
                              Update
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="compliance" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Legal Compliance Checklist</h2>
                <Badge className="bg-gradient-to-r from-green-600 to-blue-600 text-white">
                  <Shield className="w-3 h-3 mr-1" />
                  75% Complete
                </Badge>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {complianceChecklist.map((area, areaIndex) => (
                  <Card key={areaIndex}>
                    <CardHeader>
                      <CardTitle>{area.area}</CardTitle>
                      <CardDescription>
                        {area.items.filter((item) => item.status).length} of {area.items.length} requirements completed
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {area.items.map((item, itemIndex) => (
                          <div key={itemIndex} className="flex items-center justify-between p-3 border rounded-lg">
                            <div className="flex items-center space-x-3">
                              <div
                                className={`w-5 h-5 rounded-full flex items-center justify-center ${
                                  item.status ? "bg-green-600" : "bg-gray-300"
                                }`}
                              >
                                {item.status && <CheckCircle className="w-3 h-3 text-white" />}
                              </div>
                              <div>
                                <p className="font-medium text-gray-900">{item.name}</p>
                                <p className="text-sm text-gray-600">Due: {item.dueDate}</p>
                              </div>
                            </div>
                            <Badge variant={item.status ? "default" : "outline"}>
                              {item.status ? "Complete" : "Pending"}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="authorities" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Government Authorities</h2>
                <Button className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                  <Phone className="w-4 h-4 mr-2" />
                  Contact Authority
                </Button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {[
                  {
                    name: "Kementerian Hukum dan HAM",
                    type: "National Authority",
                    contact: "Budi Santoso",
                    phone: "+62-21-3441-5555",
                    email: "info@kemenkumham.go.id",
                    address: "Jl. HR Rasuna Said Kav. 6-7, Jakarta Selatan",
                    services: ["SK Pengesahan Badan Hukum", "Perubahan Anggaran Dasar"],
                    processingTime: "14 days",
                    fees: "IDR 500,000",
                  },
                  {
                    name: "OSS (Online Single Submission)",
                    type: "Digital Platform",
                    contact: "Customer Service",
                    phone: "+62-21-1500-175",
                    email: "cs@oss.go.id",
                    address: "Online Platform",
                    services: ["SIUP", "TDP", "NIB"],
                    processingTime: "7 days",
                    fees: "IDR 300,000",
                  },
                  {
                    name: "Direktorat Jenderal Pajak",
                    type: "Tax Authority",
                    contact: "Tax Office Jakarta Selatan",
                    phone: "+62-21-7394-4000",
                    email: "kpp.jaksel@pajak.go.id",
                    address: "Jl. Prapatan Raya No. 142, Jakarta Selatan",
                    services: ["NPWP", "PKP", "Tax Reporting"],
                    processingTime: "3 days",
                    fees: "Free",
                  },
                  {
                    name: "Kementerian Pariwisata dan Ekonomi Kreatif",
                    type: "Sectoral Authority",
                    contact: "Direktorat Musik",
                    phone: "+62-21-3838-4899",
                    email: "musik@kemenparekraf.go.id",
                    address: "Jl. Medan Merdeka Barat No. 17, Jakarta Pusat",
                    services: ["Izin Usaha Musik", "Sertifikasi Industri Musik"],
                    processingTime: "21 days",
                    fees: "IDR 1,000,000",
                  },
                ].map((authority, index) => (
                  <Card key={index}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">{authority.name}</CardTitle>
                        <Badge variant="outline">{authority.type}</Badge>
                      </div>
                      <CardDescription>
                        Processing time: {authority.processingTime} • Fees: {authority.fees}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Users className="w-4 h-4 text-gray-500" />
                            <span className="text-sm text-gray-600">Contact Person</span>
                          </div>
                          <p className="font-medium text-gray-900">{authority.contact}</p>
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Phone className="w-4 h-4 text-gray-500" />
                            <span className="text-sm text-gray-600">Phone</span>
                          </div>
                          <p className="font-medium text-gray-900">{authority.phone}</p>
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <Mail className="w-4 h-4 text-gray-500" />
                            <span className="text-sm text-gray-600">Email</span>
                          </div>
                          <p className="font-medium text-gray-900">{authority.email}</p>
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <MapPin className="w-4 h-4 text-gray-500" />
                            <span className="text-sm text-gray-600">Address</span>
                          </div>
                          <p className="font-medium text-gray-900 text-sm">{authority.address}</p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <h4 className="font-semibold text-gray-900">Services Provided</h4>
                        <div className="flex flex-wrap gap-2">
                          {authority.services.map((service, serviceIndex) => (
                            <Badge key={serviceIndex} variant="outline" className="text-xs">
                              {service}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Phone className="w-4 h-4 mr-1" />
                          Call
                        </Button>
                        <Button variant="outline" size="sm" className="flex-1">
                          <Mail className="w-4 h-4 mr-1" />
                          Email
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="status" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Registration Status Summary</h2>
                <Button className="bg-gradient-to-r from-green-600 to-blue-600 text-white">
                  <Download className="w-4 h-4 mr-2" />
                  Export Report
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Overall Progress</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">{registrationProgress}%</div>
                    <p className="text-sm text-green-600">5 of 8 steps completed</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Days Elapsed</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">45</div>
                    <p className="text-sm text-blue-600">Since registration start</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Estimated Completion</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">30</div>
                    <p className="text-sm text-orange-600">Days remaining</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Total Investment</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">IDR 15M</div>
                    <p className="text-sm text-purple-600">Registration costs</p>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Complete Registration Status</CardTitle>
                  <CardDescription>Detailed status of all registration requirements</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-4">Completed Registrations</h3>
                        <div className="space-y-3">
                          {[
                            { name: "Akta Pendirian", number: "No. 123/2024", date: "2024-01-15" },
                            { name: "SK Kemenkumham", number: "AHU-0001234", date: "2024-01-25" },
                            { name: "NPWP", number: "01.234.567.8-901.000", date: "2024-01-30" },
                            { name: "Domicile Letter", number: "SKD/001/2024", date: "2024-01-25" },
                            { name: "Board Resolution", number: "BR/001/2024", date: "2024-01-20" },
                          ].map((item, index) => (
                            <div key={index} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                              <div>
                                <p className="font-medium text-gray-900">{item.name}</p>
                                <p className="text-sm text-gray-600">{item.number}</p>
                              </div>
                              <div className="text-right">
                                <Badge className="bg-green-600 text-white mb-1">
                                  <CheckCircle className="w-3 h-3 mr-1" />
                                  Complete
                                </Badge>
                                <p className="text-xs text-gray-600">{item.date}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h3 className="font-semibold text-gray-900 mb-4">Pending Registrations</h3>
                        <div className="space-y-3">
                          {[
                            { name: "SIUP", status: "In Progress", expected: "2024-02-10", progress: 60 },
                            { name: "TDP", status: "Pending", expected: "2024-02-15", progress: 0 },
                            { name: "Izin Usaha Musik", status: "Under Review", expected: "2024-03-01", progress: 25 },
                            { name: "Corporate Bank Account", status: "Pending", expected: "2024-02-20", progress: 0 },
                          ].map((item, index) => (
                            <div key={index} className="p-3 border rounded-lg">
                              <div className="flex items-center justify-between mb-2">
                                <p className="font-medium text-gray-900">{item.name}</p>
                                <Badge variant={item.status === "In Progress" ? "secondary" : "outline"}>
                                  {item.status}
                                </Badge>
                              </div>
                              <div className="space-y-2">
                                <p className="text-sm text-gray-600">Expected: {item.expected}</p>
                                <div className="space-y-1">
                                  <div className="flex items-center justify-between text-sm">
                                    <span className="text-gray-600">Progress</span>
                                    <span className="font-medium">{item.progress}%</span>
                                  </div>
                                  <Progress value={item.progress} className="h-2" />
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="border-t pt-6">
                      <h3 className="font-semibold text-gray-900 mb-4">Next Steps & Action Items</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="p-4 bg-blue-50 rounded-lg">
                          <h4 className="font-semibold text-blue-900 mb-2">Immediate Actions (This Week)</h4>
                          <ul className="space-y-1 text-sm text-blue-800">
                            <li>• Follow up on SIUP application status</li>
                            <li>• Prepare TDP application documents</li>
                            <li>• Schedule bank account opening appointment</li>
                          </ul>
                        </div>
                        <div className="p-4 bg-orange-50 rounded-lg">
                          <h4 className="font-semibold text-orange-900 mb-2">Upcoming Actions (Next 2 Weeks)</h4>
                          <ul className="space-y-1 text-sm text-orange-800">
                            <li>• Submit Izin Usaha Musik application</li>
                            <li>• Complete PKP registration</li>
                            <li>• Finalize corporate banking setup</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </AuthGuard>
  )
}
