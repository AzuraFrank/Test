"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Scale,
  FileText,
  Brain,
  Shield,
  CheckCircle,
  Users,
  Gavel,
  BookOpen,
  Download,
  Eye,
  Edit,
  Send,
  User,
} from "lucide-react"
import { AuthGuard } from "@/components/auth-guard"

export default function AILegalAssistantPage() {
  const [activeTab, setActiveTab] = useState("assistant")
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: "assistant",
      content: `Selamat datang di NABILA Legal AI Assistant! 

Saya adalah asisten AI hukum canggih yang dapat membantu Anda dengan:

🏛️ **Manajemen Kontrak & Kemitraan**
- Review dan analisis kontrak partnership
- Penyusunan syarat dan ketentuan
- Negosiasi terms dengan platform streaming
- Compliance check terhadap regulasi musik

⚖️ **Lembaga Kolektif Musik**
- Struktur organisasi yang sah
- Registrasi dan lisensi
- Kepatuhan regulasi internasional
- Manajemen hak cipta kolektif

📋 **Legal Compliance**
- Copyright dan intellectual property
- Data protection (GDPR, CCPA)
- International music licensing
- Tax compliance multi-jurisdiksi

Bagaimana saya dapat membantu Anda hari ini?`,
      timestamp: new Date(),
      confidence: 0.98,
      legalAccuracy: 0.96,
    },
  ])
  const [inputMessage, setInputMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [selectedContractType, setSelectedContractType] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const [legalMetrics, setLegalMetrics] = useState({
    activeContracts: 47,
    pendingReviews: 8,
    complianceScore: 96.8,
    legalRisk: "Low",
    contractsThisMonth: 12,
    avgReviewTime: "2.3 days",
  })

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return

    const userMessage = {
      id: messages.length + 1,
      type: "user",
      content: inputMessage,
      timestamp: new Date(),
      confidence: 0.95,
      legalAccuracy: 0.94,
    }

    setMessages((prev) => [...prev, userMessage])
    setInputMessage("")
    setIsLoading(true)

    // Simulate AI legal processing
    setTimeout(() => {
      const aiResponse = {
        id: messages.length + 2,
        type: "assistant",
        content: generateLegalAIResponse(inputMessage),
        timestamp: new Date(),
        confidence: Math.random() * 0.1 + 0.9,
        legalAccuracy: Math.random() * 0.1 + 0.9,
      }
      setMessages((prev) => [...prev, aiResponse])
      setIsLoading(false)
    }, 2000)
  }

  const generateLegalAIResponse = (message: string) => {
    const lowerMessage = message.toLowerCase()

    if (lowerMessage.includes("kontrak") || lowerMessage.includes("contract")) {
      return `📋 **Analisis Kontrak Partnership**

Berdasarkan query Anda tentang kontrak, berikut analisis dan rekomendasi saya:

**🔍 Elemen Kontrak Penting:**
1. **Pihak-pihak Kontrak**
   - NABILA Distribution (sebagai distributor)
   - Platform Partner (Spotify, Apple Music, dll)
   - Definisi hak dan kewajiban masing-pihak

2. **Terms Finansial**
   - Revenue sharing: 70% untuk artist, 30% untuk platform
   - Minimum payout threshold: $50
   - Payment schedule: Monthly
   - Currency dan exchange rate handling

3. **Intellectual Property Rights**
   - Hak cipta tetap pada artist/label
   - License non-eksklusif untuk distribusi
   - Territory coverage dan durasi lisensi
   - Takedown procedures

**⚖️ Klausul Penting yang Harus Ada:**
- **Force Majeure**: Perlindungan dari kejadian luar biasa
- **Termination**: Prosedur pembatalan kontrak (30 hari notice)
- **Dispute Resolution**: Arbitrase di Jakarta, Indonesia
- **Data Protection**: Compliance dengan GDPR dan UU PDP
- **Liability Limitation**: Batasan tanggung jawab maksimal

**🛡️ Risk Assessment:**
- Legal Risk: **LOW** (dengan klausul yang tepat)
- Financial Risk: **MEDIUM** (tergantung payment terms)
- Operational Risk: **LOW** (dengan SLA yang jelas)

**📝 Next Steps:**
1. Review template kontrak yang ada
2. Customize untuk setiap platform partner
3. Legal review oleh tim hukum internal
4. Negotiation dengan counterpart

Apakah Anda ingin saya generate draft kontrak untuk platform tertentu?`
    } else if (lowerMessage.includes("syarat") || lowerMessage.includes("ketentuan") || lowerMessage.includes("terms")) {
      return `📜 **Syarat dan Ketentuan Komprehensif**

Saya akan membantu menyusun Syarat dan Ketentuan yang mendetail untuk NABILA Distribution:

**🏢 1. DEFINISI DAN INTERPRETASI**
- Platform: NABILA Distribution Music Marketplace
- Pengguna: Artist, Label, Listener, Partner
- Layanan: Distribusi musik, marketplace, streaming
- Konten: Audio, video, metadata, artwork

**👥 2. ELIGIBILITAS DAN REGISTRASI**
- Minimum usia 18 tahun atau persetujuan wali
- Verifikasi identitas dan dokumen legal
- Kepemilikan hak cipta yang sah
- Compliance dengan hukum lokal dan internasional

**🎵 3. HAK DAN KEWAJIBAN PENGGUNA**
**Hak Artist/Label:**
- Retain full copyright ownership
- Set pricing dan distribution terms
- Access ke analytics dan reporting
- Withdraw content dengan notice period

**Kewajiban Artist/Label:**
- Provide accurate metadata
- Ensure content originality
- Comply dengan content guidelines
- Pay applicable fees dan taxes

**💰 4. FINANCIAL TERMS**
- Revenue sharing: Transparent calculation
- Payment schedule: Monthly (minimum $50)
- Tax obligations: User responsibility
- Refund policy: 30-day window

**🔒 5. INTELLECTUAL PROPERTY**
- User retains all rights to original content
- Platform receives non-exclusive distribution license
- DMCA compliance procedures
- Copyright infringement reporting

**⚖️ 6. LEGAL COMPLIANCE**
- Governing law: Indonesia
- Dispute resolution: Jakarta arbitration
- Data protection: GDPR, UU PDP compliance
- International licensing agreements

**🚫 7. PROHIBITED CONTENT**
- Copyrighted material without permission
- Hate speech atau discriminatory content
- Adult content (explicit labeling required)
- Illegal atau harmful content

**📊 8. PLATFORM POLICIES**
- Content moderation procedures
- Account suspension/termination
- Appeal process
- Community guidelines

Apakah Anda ingin saya elaborate bagian tertentu atau generate dokumen lengkap?`
    } else if (lowerMessage.includes("lembaga") || lowerMessage.includes("kolektif") || lowerMessage.includes("collective")) {
      return `🏛️ **Pembentukan Lembaga Kolektif Musik NABILA**

Saya akan membantu membentuk struktur Lembaga Kolektif Musik yang sah dan diakui:

**📋 1. STRUKTUR ORGANISASI**

**🏢 NABILA Collective Music Organization (NCMO)**
- **Status Hukum**: Yayasan/Perkumpulan terdaftar
- **Nomor Registrasi**: [Akan diperoleh dari Kemenkumham]
- **NPWP**: [Registrasi pajak organisasi]
- **Domisili**: Jakarta, Indonesia

**👥 2. STRUKTUR KEPENGURUSAN**

**Dewan Pengawas (Board of Directors):**
- Ketua Dewan: [Tokoh musik senior]
- Wakil Ketua: [Praktisi industri musik]
- Anggota: [Representasi stakeholder]

**Manajemen Eksekutif:**
- CEO: Strategic leadership
- COO: Operational management  
- CFO: Financial oversight
- CLO: Legal compliance
- CTO: Technology development

**Divisi Operasional:**
- Rights Management Division
- Distribution Services Division
- Legal & Compliance Division
- Technology & Innovation Division
- Member Relations Division

**⚖️ 3. LEGITIMASI HUKUM**

**Registrasi dan Lisensi:**
- **Akta Pendirian**: Notaris terdaftar
- **SK Kemenkumham**: Pengesahan badan hukum
- **SIUP**: Surat Izin Usaha Perdagangan
- **TDP**: Tanda Daftar Perusahaan
- **Izin Usaha Musik**: Kementerian Pariwisata

**Compliance Internasional:**
- **CISAC Membership**: Confederation of Societies of Authors and Composers
- **IFPI Affiliation**: International Federation of Phonographic Industry
- **WIPO Registration**: World Intellectual Property Organization

**🎯 4. FUNGSI DAN LAYANAN**

**Collective Rights Management:**
- Mechanical rights collection
- Performance rights licensing
- Digital rights management
- International royalty collection

**Member Services:**
- Rights registration
- Royalty distribution
- Legal protection
- Industry advocacy

**🌍 5. KEMITRAAN STRATEGIS**

**Domestic Partners:**
- WAMI (Wahana Musik Indonesia)
- ASIRI (Asosiasi Industri Rekaman Indonesia)
- KCI (Karya Cipta Indonesia)

**International Partners:**
- ASCAP (USA)
- BMI (USA)
- PRS (UK)
- GEMA (Germany)
- JASRAC (Japan)

**📊 6. GOVERNANCE FRAMEWORK**

**Transparency Measures:**
- Annual financial reports
- Member voting rights
- Public accountability
- Regular audits

**Quality Assurance:**
- ISO certification process
- Industry best practices
- Continuous improvement
- Member satisfaction surveys

**💼 7. BUSINESS MODEL**

**Revenue Streams:**
- Membership fees (tiered structure)
- Commission on royalty collection (8-12%)
- Licensing fees
- Technology services

**Cost Structure:**
- Operational expenses
- Technology infrastructure
- Legal compliance
- International partnerships

Apakah Anda ingin saya detail lebih lanjut aspek tertentu atau mulai proses registrasi?`
    } else if (lowerMessage.includes("compliance") || lowerMessage.includes("regulasi")) {
      return `🛡️ **Legal Compliance Framework**

Berikut framework compliance yang komprehensif untuk NABILA Distribution:

**📋 1. COPYRIGHT & INTELLECTUAL PROPERTY**

**Domestic Compliance:**
- **UU No. 28/2014**: Hak Cipta Indonesia
- **PP No. 56/2021**: Pengelolaan Royalti Hak Cipta
- **Permen No. 29/2014**: Lembaga Manajemen Kolektif

**International Compliance:**
- **Berne Convention**: International copyright protection
- **TRIPS Agreement**: Trade-related IP rights
- **WIPO Treaties**: Digital copyright framework

**🔒 2. DATA PROTECTION**

**GDPR Compliance (EU):**
- Data processing lawful basis
- User consent mechanisms
- Right to be forgotten
- Data portability rights
- Privacy by design

**UU PDP Indonesia:**
- Personal data protection
- Consent requirements
- Data breach notification
- Cross-border data transfer

**💰 3. FINANCIAL REGULATIONS**

**Tax Compliance:**
- **PPh Pasal 23**: Withholding tax on royalties
- **PPN**: VAT on digital services
- **International Tax Treaties**: Avoid double taxation

**Anti-Money Laundering:**
- Customer Due Diligence (CDD)
- Suspicious transaction reporting
- Record keeping requirements

**🌍 4. INTERNATIONAL LICENSING**

**Territory-Specific Requirements:**
- **USA**: ASCAP, BMI, SESAC licensing
- **Europe**: PRS, GEMA, SACEM agreements
- **Asia-Pacific**: JASRAC, KOMCA partnerships

**Platform Compliance:**
- Spotify licensing requirements
- Apple Music content policies
- YouTube Content ID system
- TikTok commercial music library

**⚖️ 5. LABOR & EMPLOYMENT**

**Indonesian Labor Law:**
- **UU No. 13/2003**: Ketenagakerjaan
- Employment contracts
- Social security (BPJS)
- Occupational safety

**International Standards:**
- ILO conventions
- Fair labor practices
- Remote work policies

**🏛️ 6. CORPORATE GOVERNANCE**

**Good Corporate Governance:**
- Board independence
- Risk management
- Internal audit
- Stakeholder engagement

**ESG Compliance:**
- Environmental responsibility
- Social impact measurement
- Governance transparency

**📊 7. COMPLIANCE MONITORING**

**Automated Compliance Checks:**
- Real-time monitoring dashboard
- Regulatory change alerts
- Compliance scoring system
- Risk assessment matrix

**Audit Schedule:**
- Monthly: Financial compliance
- Quarterly: Data protection audit
- Semi-annual: Copyright compliance
- Annual: Full regulatory review

**🚨 8. RISK MITIGATION**

**High-Risk Areas:**
- Copyright infringement claims
- Data breach incidents
- Tax audit exposure
- International sanctions

**Mitigation Strategies:**
- Comprehensive insurance coverage
- Legal reserve fund
- Crisis management protocols
- Regular legal training

Current Compliance Score: **96.8%** ✅
Risk Level: **LOW** 🟢

Apakah ada area compliance spesifik yang ingin Anda dalami?`
    } else {
      return `⚖️ **NABILA Legal AI Assistant**

Saya siap membantu Anda dengan berbagai aspek legal untuk NABILA Distribution:

**🔍 Layanan yang Tersedia:**

**1. Contract Management**
- Partnership agreements review
- Distribution contracts drafting
- Terms negotiation support
- Legal risk assessment

**2. Compliance Monitoring**
- Regulatory compliance check
- International law alignment
- Industry standards verification
- Risk mitigation strategies

**3. Intellectual Property**
- Copyright protection guidance
- Trademark registration support
- Licensing agreement review
- IP infringement handling

**4. Corporate Structure**
- Collective organization setup
- Legal entity formation
- Governance framework design
- Regulatory registration

**📋 Quick Actions:**
- "Review kontrak Spotify partnership"
- "Generate terms of service"
- "Check GDPR compliance"
- "Setup lembaga kolektif musik"
- "Analyze copyright risks"

**🎯 Specialized Expertise:**
- Music industry law
- Digital distribution regulations
- International licensing
- Collective rights management

Silakan berikan pertanyaan spesifik atau pilih area yang ingin Anda konsultasikan!`
    }
  }

  return (
    <AuthGuard>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <Scale className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">NABILA Legal AI Assistant</h1>
                <p className="text-gray-600">Advanced AI untuk manajemen legal, kontrak, dan compliance</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge className="bg-gradient-to-r from-green-600 to-blue-600 text-white">
                <Brain className="w-3 h-3 mr-1" />
                AI Legal Active
              </Badge>
              <Badge variant="outline" className="text-green-700 border-green-500">
                <Shield className="w-3 h-3 mr-1" />
                Compliance: {legalMetrics.complianceScore}%
              </Badge>
            </div>
          </div>
        </header>

        <div className="p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-6 bg-white">
              <TabsTrigger value="assistant">AI Assistant</TabsTrigger>
              <TabsTrigger value="contracts">Contract Management</TabsTrigger>
              <TabsTrigger value="terms">Terms & Conditions</TabsTrigger>
              <TabsTrigger value="collective">Lembaga Kolektif</TabsTrigger>
              <TabsTrigger value="compliance">Legal Compliance</TabsTrigger>
              <TabsTrigger value="documents">Document Library</TabsTrigger>
            </TabsList>

            <TabsContent value="assistant" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                {/* AI Chat Interface */}
                <Card className="lg:col-span-3">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Scale className="w-5 h-5 text-purple-600" />
                        <CardTitle>Legal AI Assistant</CardTitle>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="text-green-700">
                          Legal Accuracy: 96.8%
                        </Badge>
                        <Badge variant="outline" className="text-blue-700">
                          Response Time: 1.2s
                        </Badge>
                      </div>
                    </div>
                    <CardDescription>
                      AI-powered legal assistant dengan expertise dalam hukum musik, kontrak, dan compliance
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {/* Messages */}
                    <div className="bg-gray-50 rounded-lg p-4 mb-4 h-96 overflow-y-auto">
                      <div className="space-y-4">
                        {messages.map((message) => (
                          <div
                            key={message.id}
                            className={`flex items-start space-x-3 ${
                              message.type === "user" ? "flex-row-reverse space-x-reverse" : ""
                            }`}
                          >
                            <div
                              className={`w-8 h-8 rounded-full flex items-center justify-center ${
                                message.type === "assistant"
                                  ? "bg-gradient-to-r from-purple-600 to-blue-600"
                                  : "bg-gray-600"
                              }`}
                            >
                              {message.type === "assistant" ? (
                                <Scale className="w-4 h-4 text-white" />
                              ) : (
                                <User className="w-4 h-4 text-white" />
                              )}
                            </div>
                            <div
                              className={`max-w-xs lg:max-w-md p-3 rounded-lg shadow-sm ${
                                message.type === "assistant" ? "bg-white" : "bg-blue-600 text-white"
                              }`}
                            >
                              <div className="whitespace-pre-wrap text-sm">{message.content}</div>
                              <div className="flex items-center justify-between mt-2">
                                <p
                                  className={`text-xs ${
                                    message.type === "assistant" ? "text-gray-500" : "text-blue-100"
                                  }`}
                                >
                                  {message.timestamp.toLocaleTimeString()}
                                </p>
                                {message.type === "assistant" && (
                                  <div className="flex items-center space-x-2">
                                    <Badge variant="outline" className="text-xs border-green-500 text-green-700">
                                      {Math.round(message.confidence * 100)}% confidence
                                    </Badge>
                                    <Badge variant="outline" className="text-xs border-blue-500 text-blue-700">
                                      {Math.round(message.legalAccuracy * 100)}% accuracy
                                    </Badge>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                        {isLoading && (
                          <div className="flex items-start space-x-3">
                            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center">
                              <Scale className="w-4 h-4 text-white" />
                            </div>
                            <div className="bg-white p-3 rounded-lg shadow-sm">
                              <div className="flex space-x-1">
                                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                                <div
                                  className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                                  style={{ animationDelay: "0.1s" }}
                                ></div>
                                <div
                                  className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                                  style={{ animationDelay: "0.2s" }}
                                ></div>
                              </div>
                              <p className="text-xs text-gray-500 mt-1">AI analyzing legal query...</p>
                            </div>
                          </div>
                        )}
                        <div ref={messagesEndRef} />
                      </div>
                    </div>

                    {/* Input */}
                    <div className="flex space-x-2">
                      <Input
                        placeholder="Tanyakan tentang kontrak, compliance, atau legal matters..."
                        value={inputMessage}
                        onChange={(e) => setInputMessage(e.target.value)}
                        onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                        className="flex-1"
                      />
                      <Button
                        onClick={handleSendMessage}
                        disabled={isLoading || !inputMessage.trim()}
                        className="bg-gradient-to-r from-purple-600 to-blue-600 text-white"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Legal Metrics Sidebar */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Legal Metrics</CardTitle>
                    <CardDescription>Status legal dan compliance</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Active Contracts</span>
                        <Badge variant="outline" className="text-blue-700">
                          {legalMetrics.activeContracts}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Pending Reviews</span>
                        <Badge variant="outline" className="text-orange-700">
                          {legalMetrics.pendingReviews}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Compliance Score</span>
                        <Badge variant="outline" className="text-green-700">
                          {legalMetrics.complianceScore}%
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Legal Risk</span>
                        <Badge variant="outline" className="text-green-700">
                          {legalMetrics.legalRisk}
                        </Badge>
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <h4 className="font-semibold text-gray-900 mb-3">Quick Legal Actions</h4>
                      <div className="space-y-2">
                        <Button
                          variant="outline"
                          className="w-full justify-start bg-white text-gray-700"
                          onClick={() => setInputMessage("Review kontrak partnership Spotify")}
                        >
                          <FileText className="w-4 h-4 mr-2" />
                          Review Contract
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full justify-start bg-white text-gray-700"
                          onClick={() => setInputMessage("Generate terms of service")}
                        >
                          <BookOpen className="w-4 h-4 mr-2" />
                          Generate Terms
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full justify-start bg-white text-gray-700"
                          onClick={() => setInputMessage("Check GDPR compliance status")}
                        >
                          <Shield className="w-4 h-4 mr-2" />
                          Compliance Check
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full justify-start bg-white text-gray-700"
                          onClick={() => setInputMessage("Setup lembaga kolektif musik")}
                        >
                          <Gavel className="w-4 h-4 mr-2" />
                          Setup Collective
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="contracts" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Contract Management</h2>
                <div className="flex items-center space-x-3">
                  <Select>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Contract Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="partnership">Partnership</SelectItem>
                      <SelectItem value="distribution">Distribution</SelectItem>
                      <SelectItem value="licensing">Licensing</SelectItem>
                      <SelectItem value="service">Service</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                    <FileText className="w-4 h-4 mr-2" />
                    New Contract
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Active Contracts</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">{legalMetrics.activeContracts}</div>
                    <p className="text-sm text-green-600">+{legalMetrics.contractsThisMonth} this month</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Pending Reviews</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">{legalMetrics.pendingReviews}</div>
                    <p className="text-sm text-orange-600">Awaiting approval</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Avg Review Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">{legalMetrics.avgReviewTime}</div>
                    <p className="text-sm text-blue-600">Processing time</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Compliance Score</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">{legalMetrics.complianceScore}%</div>
                    <p className="text-sm text-green-600">Legal compliance</p>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Contracts</CardTitle>
                  <CardDescription>Kontrak terbaru dan status review</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      {
                        id: "CNT-2024-001",
                        title: "Spotify Distribution Partnership",
                        type: "Partnership",
                        status: "Active",
                        party: "Spotify Technology S.A.",
                        value: "$2.5M",
                        startDate: "2024-01-15",
                        endDate: "2026-01-15",
                      },
                      {
                        id: "CNT-2024-002",
                        title: "Apple Music Content Agreement",
                        type: "Distribution",
                        status: "Review",
                        party: "Apple Inc.",
                        value: "$1.8M",
                        startDate: "2024-02-01",
                        endDate: "2025-02-01",
                      },
                      {
                        id: "CNT-2024-003",
                        title: "YouTube Music Licensing",
                        type: "Licensing",
                        status: "Negotiation",
                        party: "Google LLC",
                        value: "$3.2M",
                        startDate: "2024-03-01",
                        endDate: "2027-03-01",
                      },
                      {
                        id: "CNT-2024-004",
                        title: "Amazon Music Distribution",
                        type: "Distribution",
                        status: "Draft",
                        party: "Amazon.com Inc.",
                        value: "$1.5M",
                        startDate: "2024-04-01",
                        endDate: "2025-04-01",
                      },
                    ].map((contract, index) => (
                      <div key={index} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <h3 className="font-semibold text-gray-900">{contract.title}</h3>
                            <p className="text-sm text-gray-600">
                              {contract.id} • {contract.party}
                            </p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge
                              variant={
                                contract.status === "Active"
                                  ? "default"
                                  : contract.status === "Review"
                                    ? "secondary"
                                    : contract.status === "Negotiation"
                                      ? "outline"
                                      : "secondary"
                              }
                            >
                              {contract.status}
                            </Badge>
                            <Button variant="outline" size="sm">
                              <Eye className="w-4 h-4 mr-1" />
                              View
                            </Button>
                          </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <p className="text-gray-600">Type</p>
                            <p className="font-medium">{contract.type}</p>
                          </div>
                          <div>
                            <p className="text-gray-600">Value</p>
                            <p className="font-medium">{contract.value}</p>
                          </div>
                          <div>
                            <p className="text-gray-600">Start Date</p>
                            <p className="font-medium">{contract.startDate}</p>
                          </div>
                          <div>
                            <p className="text-gray-600">End Date</p>
                            <p className="font-medium">{contract.endDate}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="terms" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Terms & Conditions</h2>
                <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                  <Edit className="w-4 h-4 mr-2" />
                  Edit Terms
                </Button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle>SYARAT DAN KETENTUAN NABILA DISTRIBUTION</CardTitle>
                    <CardDescription>Versi 2.1 • Berlaku efektif: 1 Januari 2024</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="prose max-w-none">
                      <h3 className="text-lg font-semibold text-gray-900">1. DEFINISI DAN INTERPRETASI</h3>
                      <div className="bg-gray-50 p-4 rounded-lg text-sm">
                        <p>
                          <strong>"Platform"</strong> berarti NABILA Distribution Music Marketplace dan semua layanan
                          terkait yang disediakan oleh PT NABILA MUSIK INDONESIA.
                        </p>
                        <p>
                          <strong>"Pengguna"</strong> berarti setiap individu atau entitas yang menggunakan Platform,
                          termasuk Artist, Label, Listener, dan Partner.
                        </p>
                        <p>
                          <strong>"Konten"</strong> berarti semua materi audio, video, teks, gambar, metadata, dan
                          artwork yang diunggah ke Platform.
                        </p>
                      </div>

                      <h3 className="text-lg font-semibold text-gray-900">2. ELIGIBILITAS DAN REGISTRASI</h3>
                      <ul className="list-disc pl-6 space-y-2 text-sm">
                        <li>Pengguna harus berusia minimal 18 tahun atau memiliki persetujuan wali yang sah</li>
                        <li>Verifikasi identitas dan dokumen legal diperlukan untuk akun bisnis</li>
                        <li>Pengguna harus memiliki hak cipta yang sah atas konten yang diunggah</li>
                        <li>Compliance dengan hukum lokal dan internasional yang berlaku</li>
                      </ul>

                      <h3 className="text-lg font-semibold text-gray-900">3. HAK DAN KEWAJIBAN</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-green-50 p-4 rounded-lg">
                          <h4 className="font-semibold text-green-800 mb-2">HAK PENGGUNA</h4>
                          <ul className="text-sm text-green-700 space-y-1">
                            <li>• Mempertahankan kepemilikan hak cipta penuh</li>
                            <li>• Mengatur pricing dan terms distribusi</li>
                            <li>• Akses ke analytics dan reporting</li>
                            <li>• Menarik konten dengan notice period</li>
                          </ul>
                        </div>
                        <div className="bg-blue-50 p-4 rounded-lg">
                          <h4 className="font-semibold text-blue-800 mb-2">KEWAJIBAN PENGGUNA</h4>
                          <ul className="text-sm text-blue-700 space-y-1">
                            <li>• Menyediakan metadata yang akurat</li>
                            <li>• Memastikan originalitas konten</li>
                            <li>• Mematuhi content guidelines</li>
                            <li>• Membayar fees dan pajak yang berlaku</li>
                          </ul>
                        </div>
                      </div>

                      <h3 className="text-lg font-semibold text-gray-900">4. KETENTUAN FINANSIAL</h3>
                      <div className="bg-yellow-50 p-4 rounded-lg text-sm">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <p>
                              <strong>Revenue Sharing:</strong> Perhitungan transparan berdasarkan platform dan jenis
                              layanan
                            </p>
                            <p>
                              <strong>Payment Schedule:</strong> Bulanan dengan minimum payout $50
                            </p>
                          </div>
                          <div>
                            <p>
                              <strong>Tax Obligations:</strong> Tanggung jawab pengguna sesuai jurisdiksi
                            </p>
                            <p>
                              <strong>Refund Policy:</strong> 30 hari untuk dispute resolution
                            </p>
                          </div>
                        </div>
                      </div>

                      <h3 className="text-lg font-semibold text-gray-900">5. INTELLECTUAL PROPERTY</h3>
                      <div className="bg-purple-50 p-4 rounded-lg text-sm">
                        <ul className="space-y-2">
                          <li>• Pengguna mempertahankan semua hak atas konten original</li>
                          <li>• Platform menerima lisensi non-eksklusif untuk distribusi</li>
                          <li>• Prosedur DMCA compliance untuk pelaporan pelanggaran</li>
                          <li>• Copyright infringement reporting system</li>
                        </ul>
                      </div>

                      <h3 className="text-lg font-semibold text-gray-900">6. KEPATUHAN HUKUM</h3>
                      <div className="bg-red-50 p-4 rounded-lg text-sm">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <p>
                              <strong>Governing Law:</strong> Hukum Republik Indonesia
                            </p>
                          </div>
                          <div>
                            <p>
                              <strong>Dispute Resolution:</strong> Arbitrase di Jakarta
                            </p>
                          </div>
                          <div>
                            <p>
                              <strong>Data Protection:</strong> GDPR dan UU PDP compliance
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Document Status</CardTitle>
                    <CardDescription>Status dan versi dokumen legal</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      {
                        document: "Terms of Service",
                        version: "2.1",
                        status: "Active",
                        lastUpdated: "2024-01-01",
                        nextReview: "2024-07-01",
                      },
                      {
                        document: "Privacy Policy",
                        version: "1.8",
                        status: "Active",
                        lastUpdated: "2024-01-15",
                        nextReview: "2024-07-15",
                      },
                      {
                        document: "User Agreement",
                        version: "3.0",
                        status: "Draft",
                        lastUpdated: "2024-02-01",
                        nextReview: "2024-03-01",
                      },
                      {
                        document: "Cookie Policy",
                        version: "1.2",
                        status: "Active",
                        lastUpdated: "2024-01-10",
                        nextReview: "2024-07-10",
                      },
                    ].map((doc, index) => (
                      <div key={index} className="border rounded-lg p-3">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium text-gray-900">{doc.document}</h4>
                          <Badge variant={doc.status === "Active" ? "default" : "secondary"}>{doc.status}</Badge>
                        </div>
                        <div className="text-sm text-gray-600 space-y-1">
                          <p>Version: {doc.version}</p>
                          <p>Updated: {doc.lastUpdated}</p>
                          <p>Review: {doc.nextReview}</p>
                        </div>
                      </div>
                    ))}

                    <div className="border-t pt-4">
                      <h4 className="font-semibold text-gray-900 mb-3">Quick Actions</h4>
                      <div className="space-y-2">
                        <Button variant="outline" className="w-full justify-start bg-white text-gray-700">
                          <Download className="w-4 h-4 mr-2" />
                          Download PDF
                        </Button>
                        <Button variant="outline" className="w-full justify-start bg-white text-gray-700">
                          <Edit className="w-4 h-4 mr-2" />
                          Edit Document
                        </Button>
                        <Button variant="outline" className="w-full justify-start bg-white text-gray-700">
                          <Eye className="w-4 h-4 mr-2" />
                          Version History
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="collective" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">NABILA Collective Music Organization</h2>
                <Badge className="bg-gradient-to-r from-green-600 to-blue-600 text-white">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Legally Established
                </Badge>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Organizational Structure</CardTitle>
                    <CardDescription>Struktur organisasi lembaga kolektif musik</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="bg-gradient-to-r from-purple-50 to-blue-50 p-4 rounded-lg">
                      <h3 className="font-semibold text-gray-900 mb-3">NABILA Collective Music Organization (NCMO)</h3>
                      <div className="space-y-2 text-sm">
                        <p>
                          <strong>Status Hukum:</strong> Yayasan terdaftar
                        </p>
                        <p>
                          <strong>Nomor Registrasi:</strong> AHU-0001234.AH.01.04.2024
                        </p>
                        <p>
                          <strong>NPWP:</strong> 01.234.567.8-901.000
                        </p>
                        <p>
                          <strong>Domisili:</strong> Jakarta Selatan, Indonesia
                        </p>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Dewan Pengawas</h4>
                      <div className="space-y-3">
                        {[
                          { position: "Ketua Dewan", name: "Prof. Dr. Slamet Sjukur", background: "Komponis Senior" },
                          {
                            position: "Wakil Ketua",
                            name: "Melly Goeslaw",
                            background: "Pencipta Lagu & Produser",
                          },
                          { position: "Anggota", name: "Glenn Fredly", background: "Musisi & Aktivis Musik" },
                        ].map((member, index) => (
                          <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                            <div className="w-10 h-10 bg-gradient-to-r from-purple-400 to-blue-400 rounded-full flex items-center justify-center">
                              <Users className="w-5 h-5 text-white" />
                            </div>
                            <div>
                              <p className="font-medium text-gray-900">{member.name}</p>
                              <p className="text-sm text-gray-600">
                                {member.position} • {member.background}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Manajemen Eksekutif</h4>
                      <div className="space-y-3">
                        {[
                          { position: "CEO", name: "Nabila Razali", department: "Strategic Leadership" },
                          { position: "COO", name: "Ahmad Dhani", department: "Operational Management" },
                          { position: "CFO", name: "Rossa Roslaina", department: "Financial Oversight" },
                          { position: "CLO", name: "Hotman Paris", department: "Legal Compliance" },
                        ].map((exec, index) => (
                          <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                            <div>
                              <p className="font-medium text-gray-900">{exec.name}</p>
                              <p className="text-sm text-gray-600">{exec.department}</p>
                            </div>
                            <Badge variant="outline">{exec.position}</Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Legal Registration & Compliance</CardTitle>
                    <CardDescription>Status registrasi dan kepatuhan hukum</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Registrasi Domestik</h4>
                      <div className="space-y-3">
                        {[
                          {
                            document: "Akta Pendirian",
                            status: "Complete",
                            number: "No. 123/2024",
                            date: "15 Jan 2024",
                          },
                          {
                            document: "SK Kemenkumham",
                            status: "Complete",
                            number: "AHU-0001234",
                            date: "20 Jan 2024",
                          },
                          {
                            document: "SIUP",
                            status: "Complete",
                            number: "510/1.824.1/2024",
                            date: "25 Jan 2024",
                          },
                          {
                            document: "TDP",
                            status: "Complete",
                            number: "09.05.1.72.12345",
                            date: "30 Jan 2024",
                          },
                        ].map((reg, index) => (
                          <div key={index} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                            <div>
                              <p className="font-medium text-gray-900">{reg.document}</p>
                              <p className="text-sm text-gray-600">
                                {reg.number} • {reg.date}
                              </p>
                            </div>
                            <Badge className="bg-green-600 text-white">{reg.status}</Badge>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">International Affiliations</h4>
                      <div className="space-y-3">
                        {[
                          { org: "CISAC", status: "Member", type: "Global Rights Society" },
                          { org: "IFPI", status: "Affiliated", type: "Recording Industry" },
                          { org: "WIPO", status: "Registered", type: "IP Organization" },
                          { org: "ASCAP", status: "Partner", type: "US Rights Society" },
                        ].map((affiliation, index) => (
                          <div key={index} className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                            <div>
                              <p className="font-medium text-gray-900">{affiliation.org}</p>
                              <p className="text-sm text-gray-600">{affiliation.type}</p>
                            </div>
                            <Badge variant="outline" className="text-blue-700 border-blue-500">
                              {affiliation.status}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Services Offered</h4>
                      <div className="grid grid-cols-2 gap-2">
                        {[
                          "Collective Rights Management",
                          "Mechanical Rights Collection",
                          "Performance Rights Licensing",
                          "Digital Rights Management",
                          "International Royalty Collection",
                          "Legal Protection Services",
                          "Industry Advocacy",
                          "Member Education",
                        ].map((service, index) => (
                          <div key={index} className="p-2 bg-gray-50 rounded text-sm text-center">
                            {service}
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Governance Framework</CardTitle>
                  <CardDescription>Framework tata kelola dan transparansi organisasi</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="space-y-4">
                      <h4 className="font-semibold text-gray-900">Transparency Measures</h4>
                      <ul className="space-y-2 text-sm">
                        <li className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Annual financial reports</span>
                        </li>
                        <li className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Member voting rights</span>
                        </li>
                        <li className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Public accountability</span>
                        </li>
                        <li className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Regular audits</span>
                        </li>
                      </ul>
                    </div>

                    <div className="space-y-4">
                      <h4 className="font-semibold text-gray-900">Quality Assurance</h4>
                      <ul className="space-y-2 text-sm">
                        <li className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-blue-600" />
                          <span>ISO 9001:2015 certification</span>
                        </li>
                        <li className="flex items-center space-x-2">
                          <CheckCircle className="w-4 h-4 text-blue-600" />
                          <span>Industry best practices</span>
                        </li>
                        <li className="flex items-center space-x-2">\
                          <CheckCircle className
