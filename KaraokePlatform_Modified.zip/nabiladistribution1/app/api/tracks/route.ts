import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase"

export async function GET(request: NextRequest) {
  try {
    const supabase = createServerClient()

    // Get user from session
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Fetch tracks for the user
    const { data: tracks, error } = await supabase
      .from("tracks")
      .select(`
        *,
        streaming_analytics(*),
        platform_distributions(*)
      `)
      .eq("artist_id", user.id)
      .order("created_at", { ascending: false })

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ tracks })
  } catch (error) {
    console.error("Error fetching tracks:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = createServerClient()

    // Get user from session
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { title, artist_name, album_title, genre, release_date, duration, audio_file_url, artwork_url } = body

    // Insert new track
    const { data: track, error } = await supabase
      .from("tracks")
      .insert({
        artist_id: user.id,
        title,
        artist_name,
        album_title,
        genre,
        release_date,
        duration,
        audio_file_url,
        artwork_url,
        status: "draft",
      })
      .select()
      .single()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ track })
  } catch (error) {
    console.error("Error creating track:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
