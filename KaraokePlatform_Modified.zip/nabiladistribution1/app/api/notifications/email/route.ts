import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase"

// Email notification system
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { type, recipient, data } = body

    const supabase = createClient()

    // Get email template based on notification type
    const emailTemplate = await getEmailTemplate(type, data)

    // Send email using preferred email service
    const emailResult = await sendEmail({
      to: recipient.email,
      subject: emailTemplate.subject,
      html: emailTemplate.html,
      attachments: emailTemplate.attachments,
    })

    // Log notification
    await supabase.from("notifications").insert({
      recipient_id: recipient.id,
      notification_type: type,
      channel: "email",
      subject: emailTemplate.subject,
      content: emailTemplate.html,
      status: emailResult.success ? "sent" : "failed",
      sent_at: new Date().toISOString(),
      metadata: { emailId: emailResult.messageId },
    })

    return NextResponse.json({
      success: emailResult.success,
      messageId: emailResult.messageId,
    })
  } catch (error) {
    console.error("Email notification error:", error)
    return NextResponse.json({ error: "Failed to send email" }, { status: 500 })
  }
}

async function getEmailTemplate(type: string, data: any) {
  const templates = {
    royalty_payment: {
      subject: `Royalty Payment Processed - ${data.amount} ${data.currency}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center;">
            <h1 style="color: white; margin: 0;">NABILA Music Distribution</h1>
            <p style="color: white; margin: 10px 0 0 0;">Royalty Payment Notification</p>
          </div>
          
          <div style="padding: 30px; background: white;">
            <h2 style="color: #333;">Payment Processed Successfully</h2>
            <p>Dear ${data.artistName},</p>
            <p>We're pleased to inform you that your royalty payment has been processed.</p>
            
            <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3 style="margin-top: 0; color: #667eea;">Payment Details</h3>
              <table style="width: 100%; border-collapse: collapse;">
                <tr>
                  <td style="padding: 8px 0; border-bottom: 1px solid #eee;"><strong>Amount:</strong></td>
                  <td style="padding: 8px 0; border-bottom: 1px solid #eee;">${data.amount} ${data.currency}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; border-bottom: 1px solid #eee;"><strong>Period:</strong></td>
                  <td style="padding: 8px 0; border-bottom: 1px solid #eee;">${data.period}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; border-bottom: 1px solid #eee;"><strong>Payment Method:</strong></td>
                  <td style="padding: 8px 0; border-bottom: 1px solid #eee;">${data.paymentMethod}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0;"><strong>Reference:</strong></td>
                  <td style="padding: 8px 0;">${data.reference}</td>
                </tr>
              </table>
            </div>
            
            <p>The payment should reflect in your account within 1-3 business days.</p>
            <p>You can view detailed reports and analytics in your dashboard.</p>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="${data.dashboardUrl}" style="background: #667eea; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">View Dashboard</a>
            </div>
          </div>
          
          <div style="background: #f8f9fa; padding: 20px; text-align: center; color: #666;">
            <p>© 2024 NABILA Collective Music Organization. All rights reserved.</p>
          </div>
        </div>
      `,
    },

    contract_signed: {
      subject: `Contract Signed - ${data.contractTitle}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); padding: 30px; text-align: center;">
            <h1 style="color: white; margin: 0;">NABILA Legal Services</h1>
            <p style="color: white; margin: 10px 0 0 0;">Contract Execution Notification</p>
          </div>
          
          <div style="padding: 30px; background: white;">
            <h2 style="color: #333;">Contract Successfully Signed</h2>
            <p>Dear ${data.clientName},</p>
            <p>Your contract has been successfully signed and is now legally binding.</p>
            
            <div style="background: #f0fff4; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #38ef7d;">
              <h3 style="margin-top: 0; color: #11998e;">Contract Information</h3>
              <p><strong>Title:</strong> ${data.contractTitle}</p>
              <p><strong>Type:</strong> ${data.contractType}</p>
              <p><strong>Effective Date:</strong> ${data.effectiveDate}</p>
              <p><strong>Duration:</strong> ${data.duration}</p>
              <p><strong>Contract ID:</strong> ${data.contractId}</p>
            </div>
            
            <p>All parties have signed the contract. You can download the executed copy from your dashboard.</p>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="${data.downloadUrl}" style="background: #11998e; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; margin-right: 10px;">Download Contract</a>
              <a href="${data.dashboardUrl}" style="background: #38ef7d; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">View Dashboard</a>
            </div>
          </div>
        </div>
      `,
    },

    registration_complete: {
      subject: "NCMO Legal Entity Registration Complete",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center;">
            <h1 style="color: white; margin: 0;">🎉 Registration Complete!</h1>
            <p style="color: white; margin: 10px 0 0 0;">NABILA Collective Music Organization</p>
          </div>
          
          <div style="padding: 30px; background: white;">
            <h2 style="color: #333;">Legal Entity Successfully Registered</h2>
            <p>Congratulations! NABILA Collective Music Organization (NCMO) has been successfully registered as a legal entity.</p>
            
            <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3 style="margin-top: 0; color: #667eea;">Registration Details</h3>
              <p><strong>Entity Name:</strong> NABILA Collective Music Organization</p>
              <p><strong>Entity Type:</strong> Yayasan (Foundation)</p>
              <p><strong>Registration Date:</strong> ${data.completionDate}</p>
              <p><strong>SK Kemenkumham:</strong> ${data.skNumber}</p>
              <p><strong>NPWP:</strong> ${data.npwpNumber}</p>
            </div>
            
            <div style="background: #e8f5e8; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3 style="margin-top: 0; color: #2d5a2d;">What's Next?</h3>
              <ul style="margin: 0; padding-left: 20px;">
                <li>International affiliations with CISAC, IFPI</li>
                <li>Banking setup and financial operations</li>
                <li>Platform integrations and API connections</li>
                <li>Artist onboarding and catalog management</li>
              </ul>
            </div>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="${data.certificateUrl}" style="background: #667eea; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">Download Certificate</a>
            </div>
          </div>
        </div>
      `,
    },
  }

  return (
    templates[type as keyof typeof templates] || {
      subject: "Notification from NABILA Music",
      html: "<p>You have a new notification.</p>",
    }
  )
}

async function sendEmail({ to, subject, html, attachments }: any) {
  // In production, integrate with email service like SendGrid, AWS SES, or similar
  // For now, simulate email sending

  console.log("Sending email:", { to, subject })

  // Simulate email sending delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return {
    success: true,
    messageId: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
  }
}
