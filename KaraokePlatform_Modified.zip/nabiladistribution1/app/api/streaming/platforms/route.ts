import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase"

// Streaming platform API integrations
const PLATFORM_APIS = {
  spotify: {
    baseUrl: "https://api.spotify.com/v1",
    authUrl: "https://accounts.spotify.com/api/token",
  },
  apple_music: {
    baseUrl: "https://api.music.apple.com/v1",
    authUrl: "https://appleid.apple.com/auth/token",
  },
  youtube_music: {
    baseUrl: "https://www.googleapis.com/youtube/v3",
    authUrl: "https://oauth2.googleapis.com/token",
  },
  deezer: {
    baseUrl: "https://api.deezer.com",
    authUrl: "https://connect.deezer.com/oauth/access_token.php",
  },
  tidal: {
    baseUrl: "https://api.tidalhifi.com/v1",
    authUrl: "https://auth.tidal.com/v1/oauth2/token",
  },
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const action = searchParams.get("action")
    const platform = searchParams.get("platform")

    const supabase = createClient()

    switch (action) {
      case "sync_catalog":
        // Sync music catalog with streaming platforms
        const { data: songs } = await supabase.from("songs").select("*, artists(*)").eq("status", "published")

        const syncResults = await Promise.all(
          songs?.map(async (song) => {
            try {
              // Simulate API call to streaming platform
              const platformData = await syncToStreamingPlatform(platform, song)

              // Update song with platform-specific data
              await supabase.from("streaming_platform_tracks").upsert({
                song_id: song.id,
                platform_name: platform,
                platform_track_id: platformData.trackId,
                platform_url: platformData.url,
                sync_status: "synced",
                last_sync_date: new Date().toISOString(),
              })

              return { songId: song.id, status: "success", platformData }
            } catch (error) {
              return { songId: song.id, status: "error", error: error.message }
            }
          }) || [],
        )

        return NextResponse.json({
          success: true,
          platform,
          syncedCount: syncResults.filter((r) => r.status === "success").length,
          errorCount: syncResults.filter((r) => r.status === "error").length,
          results: syncResults,
        })

      case "get_analytics":
        // Get streaming analytics from platforms
        const { data: platformTracks } = await supabase
          .from("streaming_platform_tracks")
          .select("*, songs(*)")
          .eq("platform_name", platform)

        const analyticsData = await Promise.all(
          platformTracks?.map(async (track) => {
            try {
              const analytics = await getStreamingAnalytics(platform, track.platform_track_id)

              // Store analytics data
              await supabase.from("streaming_analytics").upsert({
                track_id: track.id,
                platform_name: platform,
                streams: analytics.streams,
                listeners: analytics.listeners,
                revenue: analytics.revenue,
                territories: analytics.territories,
                demographics: analytics.demographics,
                date_recorded: new Date().toISOString(),
              })

              return { trackId: track.id, analytics }
            } catch (error) {
              return { trackId: track.id, error: error.message }
            }
          }) || [],
        )

        return NextResponse.json({
          success: true,
          platform,
          analyticsData,
        })

      case "calculate_royalties":
        // Calculate royalties from streaming data
        const { data: analytics } = await supabase
          .from("streaming_analytics")
          .select("*, streaming_platform_tracks(*, songs(*, artists(*)))")
          .eq("platform_name", platform)
          .gte("date_recorded", searchParams.get("from_date"))
          .lte("date_recorded", searchParams.get("to_date"))

        const royaltyCalculations = analytics?.map((data) => {
          const streamingRate = getStreamingRate(platform, data.streams)
          const grossRoyalty = data.streams * streamingRate
          const platformFee = grossRoyalty * 0.3 // 30% platform fee
          const ncmoCommission = (grossRoyalty - platformFee) * 0.15 // 15% NCMO commission
          const netRoyalty = grossRoyalty - platformFee - ncmoCommission

          return {
            trackId: data.track_id,
            songTitle: data.streaming_platform_tracks.songs.title,
            artistName: data.streaming_platform_tracks.songs.artists.name,
            streams: data.streams,
            streamingRate,
            grossRoyalty,
            platformFee,
            ncmoCommission,
            netRoyalty,
            currency: "USD",
          }
        })

        return NextResponse.json({
          success: true,
          platform,
          period: `${searchParams.get("from_date")} to ${searchParams.get("to_date")}`,
          totalRoyalties: royaltyCalculations?.reduce((sum, calc) => sum + calc.netRoyalty, 0),
          calculations: royaltyCalculations,
        })

      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }
  } catch (error) {
    console.error("Streaming API Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, platform, data } = body

    const supabase = createClient()

    switch (action) {
      case "submit_content":
        // Submit new content to streaming platform
        const submissionResult = await submitToStreamingPlatform(platform, data)

        // Store submission record
        await supabase.from("platform_submissions").insert({
          song_id: data.songId,
          platform_name: platform,
          submission_status: "submitted",
          submission_reference: submissionResult.referenceId,
          submitted_at: new Date().toISOString(),
        })

        return NextResponse.json({
          success: true,
          message: "Content submitted successfully",
          referenceId: submissionResult.referenceId,
        })

      case "update_metadata":
        // Update track metadata on streaming platform
        const updateResult = await updateStreamingMetadata(platform, data)

        return NextResponse.json({
          success: true,
          message: "Metadata updated successfully",
          updateResult,
        })

      case "request_takedown":
        // Request content takedown from streaming platform
        const takedownResult = await requestContentTakedown(platform, data)

        await supabase.from("takedown_requests").insert({
          song_id: data.songId,
          platform_name: platform,
          reason: data.reason,
          request_status: "submitted",
          request_reference: takedownResult.referenceId,
          requested_at: new Date().toISOString(),
        })

        return NextResponse.json({
          success: true,
          message: "Takedown request submitted",
          referenceId: takedownResult.referenceId,
        })

      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }
  } catch (error) {
    console.error("Streaming API Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// Helper functions for streaming platform integrations
async function syncToStreamingPlatform(platform: string, song: any) {
  // Simulate API call to streaming platform
  const platformConfig = PLATFORM_APIS[platform as keyof typeof PLATFORM_APIS]

  if (!platformConfig) {
    throw new Error(`Unsupported platform: ${platform}`)
  }

  // In real implementation, this would make actual API calls
  return {
    trackId: `${platform}_${song.id}_${Date.now()}`,
    url: `https://${platform}.com/track/${song.id}`,
    status: "active",
    syncedAt: new Date().toISOString(),
  }
}

async function getStreamingAnalytics(platform: string, trackId: string) {
  // Simulate fetching analytics from streaming platform
  return {
    streams: Math.floor(Math.random() * 1000000),
    listeners: Math.floor(Math.random() * 100000),
    revenue: Math.random() * 1000,
    territories: ["ID", "MY", "SG", "TH", "PH"],
    demographics: {
      age_groups: { "18-24": 30, "25-34": 40, "35-44": 20, "45+": 10 },
      gender: { male: 55, female: 45 },
    },
  }
}

async function submitToStreamingPlatform(platform: string, data: any) {
  // Simulate content submission to streaming platform
  return {
    referenceId: `${platform}_sub_${Date.now()}`,
    status: "submitted",
    estimatedProcessingTime: "3-5 business days",
  }
}

async function updateStreamingMetadata(platform: string, data: any) {
  // Simulate metadata update on streaming platform
  return {
    status: "updated",
    updatedFields: Object.keys(data.metadata),
    updatedAt: new Date().toISOString(),
  }
}

async function requestContentTakedown(platform: string, data: any) {
  // Simulate takedown request to streaming platform
  return {
    referenceId: `${platform}_takedown_${Date.now()}`,
    status: "submitted",
    estimatedProcessingTime: "1-3 business days",
  }
}

function getStreamingRate(platform: string, streams: number) {
  // Streaming rates per platform (in USD per stream)
  const rates = {
    spotify: 0.003,
    apple_music: 0.007,
    youtube_music: 0.002,
    deezer: 0.006,
    tidal: 0.012,
  }

  return rates[platform as keyof typeof rates] || 0.003
}
