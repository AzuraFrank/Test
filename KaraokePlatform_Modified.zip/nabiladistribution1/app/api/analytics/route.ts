import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase"

export async function GET(request: NextRequest) {
  try {
    const supabase = createServerClient()

    // Get user from session
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const period = searchParams.get("period") || "30d"
    const trackId = searchParams.get("track_id")

    let query = supabase.from("streaming_analytics").select(`
        *,
        tracks!inner(title, artist_name)
      `)

    // Filter by user's tracks
    query = query.eq("tracks.artist_id", user.id)

    // Filter by track if specified
    if (trackId) {
      query = query.eq("track_id", trackId)
    }

    // Filter by period
    const now = new Date()
    const startDate = new Date()

    switch (period) {
      case "7d":
        startDate.setDate(now.getDate() - 7)
        break
      case "30d":
        startDate.setDate(now.getDate() - 30)
        break
      case "90d":
        startDate.setDate(now.getDate() - 90)
        break
      case "1y":
        startDate.setFullYear(now.getFullYear() - 1)
        break
    }

    query = query.gte("date", startDate.toISOString().split("T")[0])

    const { data: analytics, error } = await query.order("date", { ascending: false })

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    // Calculate summary statistics
    const totalStreams = analytics?.reduce((sum, record) => sum + (record.streams || 0), 0) || 0
    const totalListeners = analytics?.reduce((sum, record) => sum + (record.listeners || 0), 0) || 0
    const totalRevenue = analytics?.reduce((sum, record) => sum + (Number.parseFloat(record.revenue) || 0), 0) || 0

    // Group by platform
    const platformStats =
      analytics?.reduce(
        (acc, record) => {
          if (!acc[record.platform]) {
            acc[record.platform] = { streams: 0, listeners: 0, revenue: 0 }
          }
          acc[record.platform].streams += record.streams || 0
          acc[record.platform].listeners += record.listeners || 0
          acc[record.platform].revenue += Number.parseFloat(record.revenue) || 0
          return acc
        },
        {} as Record<string, any>,
      ) || {}

    // Group by country
    const countryStats =
      analytics?.reduce(
        (acc, record) => {
          const country = record.country || "Unknown"
          if (!acc[country]) {
            acc[country] = { streams: 0, listeners: 0, revenue: 0 }
          }
          acc[country].streams += record.streams || 0
          acc[country].listeners += record.listeners || 0
          acc[country].revenue += Number.parseFloat(record.revenue) || 0
          return acc
        },
        {} as Record<string, any>,
      ) || {}

    return NextResponse.json({
      analytics,
      summary: {
        totalStreams,
        totalListeners,
        totalRevenue,
        period,
      },
      platformStats,
      countryStats,
    })
  } catch (error) {
    console.error("Error fetching analytics:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
