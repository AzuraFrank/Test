import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase"

export async function GET(request: NextRequest) {
  try {
    const supabase = createClient()

    // Get registration data with related documents and workflow
    const { data: registration, error: regError } = await supabase
      .from("legal_entity_registration")
      .select(`
        *,
        registration_documents(*),
        registration_workflow(*),
        compliance_checklist(*)
      `)
      .eq("entity_name", "NABILA Collective Music Organization")
      .single()

    if (regError) {
      return NextResponse.json({ error: regError.message }, { status: 500 })
    }

    // Calculate progress
    const totalSteps = registration.registration_workflow?.length || 0
    const completedSteps =
      registration.registration_workflow?.filter((step: any) => step.step_status === "completed").length || 0
    const progress = totalSteps > 0 ? Math.round((completedSteps / totalSteps) * 100) : 0

    // Get compliance statistics
    const totalCompliance = registration.compliance_checklist?.length || 0
    const completedCompliance =
      registration.compliance_checklist?.filter((item: any) => item.completion_status === true).length || 0
    const complianceScore = totalCompliance > 0 ? Math.round((completedCompliance / totalCompliance) * 100) : 0

    return NextResponse.json({
      registration,
      statistics: {
        progress,
        totalSteps,
        completedSteps,
        complianceScore,
        totalCompliance,
        completedCompliance,
      },
    })
  } catch (error) {
    console.error("Registration API Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()
    const body = await request.json()

    const { action, data } = body

    switch (action) {
      case "update_workflow_step":
        const { stepId, status, notes } = data
        const { error: updateError } = await supabase
          .from("registration_workflow")
          .update({
            step_status: status,
            notes,
            completed_date: status === "completed" ? new Date().toISOString() : null,
            updated_at: new Date().toISOString(),
          })
          .eq("id", stepId)

        if (updateError) {
          return NextResponse.json({ error: updateError.message }, { status: 500 })
        }

        return NextResponse.json({ success: true, message: "Workflow step updated successfully" })

      case "upload_document":
        const { documentType, documentName, documentNumber, issuingAuthority } = data
        const { error: docError } = await supabase.from("registration_documents").insert({
          registration_id: data.registrationId,
          document_type: documentType,
          document_name: documentName,
          document_number: documentNumber,
          issuing_authority: issuingAuthority,
          document_status: "pending",
          created_at: new Date().toISOString(),
        })

        if (docError) {
          return NextResponse.json({ error: docError.message }, { status: 500 })
        }

        return NextResponse.json({ success: true, message: "Document uploaded successfully" })

      case "update_compliance":
        const { complianceId, completed } = data
        const { error: complianceError } = await supabase
          .from("compliance_checklist")
          .update({
            completion_status: completed,
            completion_date: completed ? new Date().toISOString() : null,
            updated_at: new Date().toISOString(),
          })
          .eq("id", complianceId)

        if (complianceError) {
          return NextResponse.json({ error: complianceError.message }, { status: 500 })
        }

        return NextResponse.json({ success: true, message: "Compliance status updated successfully" })

      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }
  } catch (error) {
    console.error("Registration API Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
