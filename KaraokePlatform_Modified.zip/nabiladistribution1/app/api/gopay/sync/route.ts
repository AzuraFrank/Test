import { type NextRequest, NextResponse } from "next/server"
import { createServerClient } from "@/lib/supabase"
import { gopayClient } from "@/lib/gopay-client"

export async function POST(request: NextRequest) {
  try {
    const supabase = createServerClient()
    const { syncType } = await request.json()

    // Log sync start
    const { data: syncLog } = await supabase
      .from("gopay_sync_logs")
      .insert({
        sync_type: syncType,
        sync_status: "pending",
        sync_start_time: new Date().toISOString(),
      })
      .select()
      .single()

    let recordsProcessed = 0
    let recordsFailed = 0
    let errorMessage = null

    try {
      if (syncType === "balance" || syncType === "all") {
        // Sync balance
        const balance = await gopayClient.getBalance()

        await supabase.from("gopay_balance_history").insert({
          account_id: "G082083595",
          balance_amount: balance.balance,
          available_balance: balance.availableBalance,
          pending_balance: balance.pendingBalance,
          currency_code: balance.currency,
          balance_timestamp: balance.timestamp,
          sync_timestamp: new Date().toISOString(),
        })

        recordsProcessed++

        // Check for low balance alert
        if (balance.availableBalance < 100000) {
          // Alert if balance < 100k IDR
          await supabase.from("gopay_monitoring_alerts").insert({
            alert_type: "low_balance",
            severity: balance.availableBalance < 50000 ? "high" : "medium",
            title: "Low GoPay Balance Alert",
            message: `GoPay balance is running low: Rp ${balance.availableBalance.toLocaleString()}`,
            threshold_value: 100000,
            current_value: balance.availableBalance,
          })
        }
      }

      if (syncType === "transactions" || syncType === "all") {
        // Sync recent transactions
        const endDate = new Date().toISOString()
        const startDate = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString() // Last 24 hours

        const transactions = await gopayClient.getTransactions(startDate, endDate, 100)

        for (const tx of transactions) {
          try {
            await supabase.from("gopay_transactions").upsert(
              {
                transaction_id: tx.transactionId,
                order_id: tx.orderId,
                transaction_type: "payment",
                amount: tx.amount,
                currency: "IDR",
                status: tx.status,
                payment_type: tx.paymentType,
                transaction_time: tx.transactionTime,
                settlement_time: tx.settlementTime,
                merchant_id: "G082083595",
                gross_amount: tx.grossAmount,
                fraud_status: tx.fraudStatus,
                raw_response: tx,
              },
              {
                onConflict: "transaction_id",
              },
            )

            recordsProcessed++
          } catch (error) {
            recordsFailed++
            console.error("Error inserting transaction:", error)
          }
        }
      }

      // Update sync log as successful
      await supabase
        .from("gopay_sync_logs")
        .update({
          sync_status: recordsFailed > 0 ? "partial" : "success",
          records_processed: recordsProcessed,
          records_failed: recordsFailed,
          sync_end_time: new Date().toISOString(),
          next_sync_time: new Date(Date.now() + 5 * 60 * 1000).toISOString(), // Next sync in 5 minutes
        })
        .eq("id", syncLog.id)
    } catch (error) {
      errorMessage = error instanceof Error ? error.message : "Unknown error"

      // Update sync log as failed
      await supabase
        .from("gopay_sync_logs")
        .update({
          sync_status: "failed",
          records_processed: recordsProcessed,
          records_failed: recordsFailed,
          sync_end_time: new Date().toISOString(),
          error_message: errorMessage,
          next_sync_time: new Date(Date.now() + 15 * 60 * 1000).toISOString(), // Retry in 15 minutes
        })
        .eq("id", syncLog.id)

      throw error
    }

    return NextResponse.json({
      success: true,
      recordsProcessed,
      recordsFailed,
      syncType,
    })
  } catch (error) {
    console.error("GoPay sync error:", error)
    return NextResponse.json({ error: "Failed to sync GoPay data" }, { status: 500 })
  }
}

export async function GET() {
  try {
    const supabase = createServerClient()

    // Get latest sync status
    const { data: latestSync } = await supabase
      .from("gopay_sync_logs")
      .select("*")
      .order("sync_start_time", { ascending: false })
      .limit(1)
      .single()

    // Get current balance
    const { data: latestBalance } = await supabase
      .from("gopay_balance_history")
      .select("*")
      .order("balance_timestamp", { ascending: false })
      .limit(1)
      .single()

    // Get unresolved alerts
    const { data: alerts } = await supabase
      .from("gopay_monitoring_alerts")
      .select("*")
      .eq("is_resolved", false)
      .order("created_at", { ascending: false })

    return NextResponse.json({
      latestSync,
      latestBalance,
      alerts: alerts || [],
    })
  } catch (error) {
    console.error("Error fetching GoPay status:", error)
    return NextResponse.json({ error: "Failed to fetch GoPay status" }, { status: 500 })
  }
}
