import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase"

// AI Chat system for NABILA Music
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { message, context, userId, sessionId } = body

    const supabase = createClient()

    // Get user context and history
    const { data: user } = await supabase.from("profiles").select("*, user_preferences").eq("id", userId).single()

    const { data: chatHistory } = await supabase
      .from("ai_chat_sessions")
      .select("messages")
      .eq("session_id", sessionId)
      .order("created_at", { ascending: false })
      .limit(10)

    // Determine chat context and intent
    const chatContext = await determineChatContext(message, context, user)

    // Generate AI response based on context
    const aiResponse = await generateAIResponse(message, chatContext, chatHistory)

    // Store chat interaction
    await supabase.from("ai_chat_sessions").insert({
      session_id: sessionId,
      user_id: userId,
      user_message: message,
      ai_response: aiResponse.content,
      context: chatContext,
      intent: aiResponse.intent,
      confidence_score: aiResponse.confidence,
      created_at: new Date().toISOString(),
    })

    // Execute any actions if needed
    if (aiResponse.actions && aiResponse.actions.length > 0) {
      await executeAIActions(aiResponse.actions, userId, supabase)
    }

    return NextResponse.json({
      success: true,
      response: aiResponse.content,
      intent: aiResponse.intent,
      confidence: aiResponse.confidence,
      actions: aiResponse.actions,
      suggestions: aiResponse.suggestions,
    })
  } catch (error) {
    console.error("AI Chat Error:", error)
    return NextResponse.json({ error: "AI chat service unavailable" }, { status: 500 })
  }
}

async function determineChatContext(message: string, context: any, user: any) {
  const lowerMessage = message.toLowerCase()

  // Determine context based on keywords and user state
  if (lowerMessage.includes("royalty") || lowerMessage.includes("payment") || lowerMessage.includes("earnings")) {
    return "royalty_inquiry"
  } else if (
    lowerMessage.includes("contract") ||
    lowerMessage.includes("agreement") ||
    lowerMessage.includes("legal")
  ) {
    return "legal_assistance"
  } else if (
    lowerMessage.includes("upload") ||
    lowerMessage.includes("distribute") ||
    lowerMessage.includes("release")
  ) {
    return "content_management"
  } else if (
    lowerMessage.includes("analytics") ||
    lowerMessage.includes("stats") ||
    lowerMessage.includes("performance")
  ) {
    return "analytics_inquiry"
  } else if (lowerMessage.includes("support") || lowerMessage.includes("help") || lowerMessage.includes("problem")) {
    return "customer_support"
  } else {
    return "general_inquiry"
  }
}

async function generateAIResponse(message: string, context: string, history: any[]) {
  // AI response generation based on context
  const responses = {
    royalty_inquiry: {
      content: `I can help you with royalty-related questions! Based on your account, here's what I can assist with:

• **Current Earnings**: Check your latest royalty payments and pending amounts
• **Payment Schedule**: View upcoming payment dates and methods
• **Revenue Breakdown**: Analyze earnings by platform, territory, and time period
• **Tax Information**: Get tax documents and withholding details

What specific information about your royalties would you like to know?`,
      intent: "royalty_help",
      confidence: 0.95,
      actions: ["fetch_royalty_summary"],
      suggestions: [
        "Show my current earnings",
        "When is my next payment?",
        "Revenue by platform",
        "Download tax documents",
      ],
    },

    legal_assistance: {
      content: `I'm here to help with legal matters! Our AI Legal Assistant can support you with:

• **Contract Review**: Analyze and explain contract terms
• **Legal Compliance**: Check regulatory requirements and deadlines
• **Document Generation**: Create legal documents from templates
• **Risk Assessment**: Identify potential legal risks in agreements
• **Multi-language Support**: Translate legal documents

What legal assistance do you need today?`,
      intent: "legal_help",
      confidence: 0.92,
      actions: ["load_legal_tools"],
      suggestions: ["Review my contract", "Check compliance status", "Generate agreement", "Legal risk assessment"],
    },

    content_management: {
      content: `I can help you manage your music content! Here's what I can assist with:

• **Upload & Distribution**: Guide you through the upload process
• **Metadata Management**: Optimize your track information
• **Platform Sync**: Distribute to streaming platforms
• **Content Analytics**: Track performance across platforms
• **Rights Management**: Manage copyrights and licensing

What would you like to do with your content?`,
      intent: "content_help",
      confidence: 0.88,
      actions: ["load_content_tools"],
      suggestions: ["Upload new track", "Distribute to platforms", "Update metadata", "View content analytics"],
    },

    analytics_inquiry: {
      content: `I can provide detailed analytics and insights! Available reports include:

• **Streaming Analytics**: Plays, listeners, and engagement metrics
• **Revenue Analytics**: Earnings breakdown and trends
• **Geographic Data**: Performance by country and region
• **Demographic Insights**: Audience age, gender, and preferences
• **Comparative Analysis**: Benchmark against industry standards

Which analytics would you like to explore?`,
      intent: "analytics_help",
      confidence: 0.9,
      actions: ["load_analytics_dashboard"],
      suggestions: ["Show streaming stats", "Revenue trends", "Geographic breakdown", "Audience demographics"],
    },

    customer_support: {
      content: `I'm here to help resolve any issues! I can assist with:

• **Account Issues**: Login problems, profile updates
• **Payment Problems**: Missing payments, payment method issues
• **Technical Support**: Platform errors, upload problems
• **Policy Questions**: Terms of service, copyright policies
• **Escalation**: Connect you with human support when needed

What issue can I help you resolve?`,
      intent: "support_help",
      confidence: 0.85,
      actions: ["load_support_tools"],
      suggestions: ["Account login issue", "Missing payment", "Upload problem", "Contact human support"],
    },

    general_inquiry: {
      content: `Hello! I'm NABILA AI, your music industry assistant. I can help you with:

• **Royalty Management**: Track earnings and payments
• **Legal Services**: Contract review and compliance
• **Content Distribution**: Upload and manage your music
• **Analytics & Insights**: Performance data and trends
• **Customer Support**: Resolve issues and answer questions

How can I assist you today?`,
      intent: "general_help",
      confidence: 0.75,
      actions: [],
      suggestions: ["Check my royalties", "Upload new music", "Review contract", "View analytics"],
    },
  }

  return responses[context as keyof typeof responses] || responses.general_inquiry
}

async function executeAIActions(actions: string[], userId: string, supabase: any) {
  for (const action of actions) {
    try {
      switch (action) {
        case "fetch_royalty_summary":
          // Fetch and cache royalty summary for quick access
          await supabase.rpc("cache_user_royalty_summary", { user_id: userId })
          break

        case "load_legal_tools":
          // Preload legal tools and templates
          await supabase.rpc("preload_legal_templates", { user_id: userId })
          break

        case "load_content_tools":
          // Prepare content management interface
          await supabase.rpc("prepare_content_workspace", { user_id: userId })
          break

        case "load_analytics_dashboard":
          // Cache analytics data for faster loading
          await supabase.rpc("cache_user_analytics", { user_id: userId })
          break

        case "load_support_tools":
          // Initialize support ticket system
          await supabase.rpc("initialize_support_session", { user_id: userId })
          break
      }
    } catch (error) {
      console.error(`Failed to execute action ${action}:`, error)
    }
  }
}
