"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  Building2,
  Globe,
  DollarSign,
  Music,
  Users,
  TrendingUp,
  Shield,
  Zap,
  Award,
  CheckCircle,
  Download,
  Send,
  MessageSquare,
  Bell,
  Settings,
  BarChart3,
  FileText,
  CreditCard,
  Headphones,
} from "lucide-react"
import { AuthGuard } from "@/components/auth-guard"

export default function CompleteDashboardPage() {
  const [activeTab, setActiveTab] = useState("overview")
  const [dashboardData, setDashboardData] = useState({
    registrationProgress: 100,
    totalEarnings: 2450000000, // IDR
    totalStreams: 15750000,
    activeContracts: 127,
    internationalAffiliations: 4,
    pendingPayments: 23,
    aiInteractions: 1250,
    platformIntegrations: 8,
  })

  const [recentActivity, setRecentActivity] = useState([
    {
      id: 1,
      type: "payment",
      title: "Royalty Payment Processed",
      description: "IDR 125,000,000 distributed to 45 artists",
      timestamp: "2 hours ago",
      status: "completed",
    },
    {
      id: 2,
      type: "registration",
      title: "NCMO Registration Complete",
      description: "Legal entity fully registered and operational",
      timestamp: "1 day ago",
      status: "completed",
    },
    {
      id: 3,
      type: "contract",
      title: "New Distribution Agreement",
      description: "Spotify Indonesia partnership contract signed",
      timestamp: "2 days ago",
      status: "completed",
    },
    {
      id: 4,
      type: "international",
      title: "CISAC Membership Approved",
      description: "International affiliation confirmed",
      timestamp: "3 days ago",
      status: "completed",
    },
  ])

  const [platformStats, setPlatformStats] = useState([
    { name: "Spotify", streams: 8500000, revenue: 850000000, growth: 15.2 },
    { name: "Apple Music", streams: 3200000, revenue: 640000000, growth: 12.8 },
    { name: "YouTube Music", streams: 2100000, revenue: 315000000, growth: 18.5 },
    { name: "Deezer", streams: 980000, revenue: 196000000, growth: 8.3 },
    { name: "Tidal", streams: 470000, revenue: 141000000, growth: 22.1 },
    { name: "Amazon Music", streams: 500000, revenue: 125000000, growth: 10.7 },
  ])

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "payment":
        return <CreditCard className="w-4 h-4 text-green-600" />
      case "registration":
        return <Building2 className="w-4 h-4 text-blue-600" />
      case "contract":
        return <FileText className="w-4 h-4 text-purple-600" />
      case "international":
        return <Globe className="w-4 h-4 text-orange-600" />
      default:
        return <Bell className="w-4 h-4 text-gray-600" />
    }
  }

  return (
    <AuthGuard>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                <Music className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">NABILA Music Distribution</h1>
                <p className="text-gray-600">Complete Management Dashboard</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge className="bg-gradient-to-r from-green-600 to-blue-600 text-white">
                <CheckCircle className="w-3 h-3 mr-1" />
                Fully Operational
              </Badge>
              <Button variant="outline">
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </Button>
            </div>
          </div>
        </header>

        <div className="p-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-medium">Registration Status</CardTitle>
                  <Building2 className="w-5 h-5" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">{dashboardData.registrationProgress}%</div>
                <p className="text-blue-100">NCMO Fully Registered</p>
                <div className="mt-3">
                  <Progress value={dashboardData.registrationProgress} className="bg-blue-500" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-green-600 to-green-700 text-white">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-medium">Total Earnings</CardTitle>
                  <DollarSign className="w-5 h-5" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">
                  IDR {(dashboardData.totalEarnings / 1000000000).toFixed(1)}B
                </div>
                <p className="text-green-100">+18.5% from last month</p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="w-4 h-4 mr-1" />
                  <span className="text-sm">Growing steadily</span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-purple-600 to-purple-700 text-white">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-medium">Total Streams</CardTitle>
                  <Headphones className="w-5 h-5" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">{(dashboardData.totalStreams / 1000000).toFixed(1)}M</div>
                <p className="text-purple-100">Across all platforms</p>
                <div className="flex items-center mt-2">
                  <BarChart3 className="w-4 h-4 mr-1" />
                  <span className="text-sm">Multi-platform reach</span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-orange-600 to-orange-700 text-white">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-medium">Global Reach</CardTitle>
                  <Globe className="w-5 h-5" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold mb-2">{dashboardData.internationalAffiliations}</div>
                <p className="text-orange-100">International Affiliations</p>
                <div className="flex items-center mt-2">
                  <Award className="w-4 h-4 mr-1" />
                  <span className="text-sm">CISAC, IFPI, ASCAP</span>
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-6 bg-white">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="streaming">Streaming</TabsTrigger>
              <TabsTrigger value="payments">Payments</TabsTrigger>
              <TabsTrigger value="legal">Legal</TabsTrigger>
              <TabsTrigger value="international">International</TabsTrigger>
              <TabsTrigger value="ai-tools">AI Tools</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* System Status */}
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle>System Status & Health</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-4 bg-green-50 rounded-lg">
                        <Shield className="w-8 h-8 text-green-600 mx-auto mb-2" />
                        <p className="text-sm font-medium text-green-800">Legal Entity</p>
                        <p className="text-xs text-green-600">Fully Registered</p>
                      </div>
                      <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <Zap className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                        <p className="text-sm font-medium text-blue-800">API Status</p>
                        <p className="text-xs text-blue-600">All Systems Go</p>
                      </div>
                      <div className="text-center p-4 bg-purple-50 rounded-lg">
                        <Users className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                        <p className="text-sm font-medium text-purple-800">Active Users</p>
                        <p className="text-xs text-purple-600">2,847 Artists</p>
                      </div>
                      <div className="text-center p-4 bg-orange-50 rounded-lg">
                        <Globe className="w-8 h-8 text-orange-600 mx-auto mb-2" />
                        <p className="text-sm font-medium text-orange-800">Global Reach</p>
                        <p className="text-xs text-orange-600">45 Countries</p>
                      </div>
                    </div>

                    <div className="mt-6 space-y-4">
                      <h4 className="font-semibold text-gray-900">Recent Activity</h4>
                      <div className="space-y-3">
                        {recentActivity.map((activity) => (
                          <div key={activity.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                            {getActivityIcon(activity.type)}
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-gray-900">{activity.title}</p>
                              <p className="text-sm text-gray-600">{activity.description}</p>
                            </div>
                            <div className="text-right">
                              <Badge variant="outline" className="text-green-700 border-green-500">
                                <CheckCircle className="w-3 h-3 mr-1" />
                                {activity.status}
                              </Badge>
                              <p className="text-xs text-gray-500 mt-1">{activity.timestamp}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Quick Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle>Quick Actions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button className="w-full justify-start bg-gradient-to-r from-blue-600 to-purple-600 text-white">
                      <MessageSquare className="w-4 h-4 mr-2" />
                      AI Assistant
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <CreditCard className="w-4 h-4 mr-2" />
                      Process Payments
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <FileText className="w-4 h-4 mr-2" />
                      Generate Reports
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Download className="w-4 h-4 mr-2" />
                      Export Data
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Send className="w-4 h-4 mr-2" />
                      Send Notifications
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="streaming" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Platform Performance</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {platformStats.map((platform, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-gray-900">{platform.name}</span>
                            <Badge variant="outline" className="text-green-700 border-green-500">
                              +{platform.growth}%
                            </Badge>
                          </div>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <p className="text-gray-600">Streams</p>
                              <p className="font-semibold">{(platform.streams / 1000000).toFixed(1)}M</p>
                            </div>
                            <div>
                              <p className="text-gray-600">Revenue</p>
                              <p className="font-semibold">IDR {(platform.revenue / 1000000).toFixed(0)}M</p>
                            </div>
                          </div>
                          <Progress value={(platform.streams / 8500000) * 100} className="h-2" />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Streaming Analytics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div className="text-center">
                        <div className="text-4xl font-bold text-gray-900 mb-2">
                          {(dashboardData.totalStreams / 1000000).toFixed(1)}M
                        </div>
                        <p className="text-gray-600">Total Streams This Month</p>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="text-center p-4 bg-blue-50 rounded-lg">
                          <div className="text-2xl font-bold text-blue-900">2.8M</div>
                          <p className="text-sm text-blue-600">Unique Listeners</p>
                        </div>
                        <div className="text-center p-4 bg-green-50 rounded-lg">
                          <div className="text-2xl font-bold text-green-900">45</div>
                          <p className="text-sm text-green-600">Countries</p>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <h4 className="font-semibold text-gray-900">Top Territories</h4>
                        {[
                          { country: "Indonesia", percentage: 45 },
                          { country: "Malaysia", percentage: 25 },
                          { country: "Singapore", percentage: 15 },
                          { country: "Thailand", percentage: 10 },
                          { country: "Philippines", percentage: 5 },
                        ].map((territory, index) => (
                          <div key={index} className="flex items-center justify-between">
                            <span className="text-sm text-gray-700">{territory.country}</span>
                            <div className="flex items-center space-x-2">
                              <div className="w-20 bg-gray-200 rounded-full h-2">
                                <div
                                  className="bg-blue-600 h-2 rounded-full"
                                  style={{ width: `${territory.percentage}%` }}
                                ></div>
                              </div>
                              <span className="text-sm font-medium text-gray-900">{territory.percentage}%</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="payments" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle>Payment Processing Status</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                      <div className="text-center p-4 bg-green-50 rounded-lg">
                        <div className="text-3xl font-bold text-green-900 mb-1">IDR 2.4B</div>
                        <p className="text-sm text-green-600">Total Distributed</p>
                      </div>
                      <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <div className="text-3xl font-bold text-blue-900 mb-1">1,247</div>
                        <p className="text-sm text-blue-600">Artists Paid</p>
                      </div>
                      <div className="text-center p-4 bg-orange-50 rounded-lg">
                        <div className="text-3xl font-bold text-orange-900 mb-1">23</div>
                        <p className="text-sm text-orange-600">Pending Payments</p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h4 className="font-semibold text-gray-900">Recent Payment Batches</h4>
                      {[
                        {
                          batch: "March 2024 Royalties",
                          amount: "IDR 125,000,000",
                          recipients: 45,
                          status: "completed",
                          date: "2024-03-15",
                        },
                        {
                          batch: "February 2024 Royalties",
                          amount: "IDR 98,500,000",
                          recipients: 38,
                          status: "completed",
                          date: "2024-02-15",
                        },
                        {
                          batch: "January 2024 Royalties",
                          amount: "IDR 87,200,000",
                          recipients: 42,
                          status: "completed",
                          date: "2024-01-15",
                        },
                      ].map((batch, index) => (
                        <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                          <div>
                            <p className="font-medium text-gray-900">{batch.batch}</p>
                            <p className="text-sm text-gray-600">
                              {batch.amount} • {batch.recipients} recipients
                            </p>
                          </div>
                          <div className="text-right">
                            <Badge className="bg-green-600 text-white mb-1">
                              <CheckCircle className="w-3 h-3 mr-1" />
                              {batch.status}
                            </Badge>
                            <p className="text-xs text-gray-500">{batch.date}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Payment Methods</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        { method: "Bank Transfer", percentage: 65, count: 812 },
                        { method: "Digital Wallet", percentage: 25, count: 311 },
                        { method: "International Wire", percentage: 8, count: 99 },
                        { method: "Cryptocurrency", percentage: 2, count: 25 },
                      ].map((method, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium text-gray-900">{method.method}</span>
                            <span className="text-sm text-gray-600">{method.count} users</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-blue-600 h-2 rounded-full"
                              style={{ width: `${method.percentage}%` }}
                            ></div>
                          </div>
                          <div className="text-right">
                            <span className="text-xs text-gray-500">{method.percentage}%</span>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="mt-6 pt-4 border-t">
                      <Button className="w-full bg-gradient-to-r from-green-600 to-blue-600 text-white">
                        <CreditCard className="w-4 h-4 mr-2" />
                        Process New Batch
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="legal" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Legal Entity Status</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200">
                        <div className="flex items-center space-x-3">
                          <CheckCircle className="w-6 h-6 text-green-600" />
                          <div>
                            <p className="font-semibold text-green-800">NCMO Fully Registered</p>
                            <p className="text-sm text-green-600">All legal requirements completed</p>
                          </div>
                        </div>
                        <Badge className="bg-green-600 text-white">Active</Badge>
                      </div>

                      <div className="space-y-3">
                        <h4 className="font-semibold text-gray-900">Registration Documents</h4>
                        {[
                          { name: "Akta Pendirian", number: "No. 123/2024", status: "active" },
                          { name: "SK Kemenkumham", number: "AHU-0001234", status: "active" },
                          { name: "NPWP", number: "01.234.567.8", status: "active" },
                          { name: "SIUP", number: "510/1.824.1/2024", status: "active" },
                          { name: "TDP", number: "09.05.1.72.12345", status: "active" },
                        ].map((doc, index) => (
                          <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                            <div>
                              <p className="font-medium text-gray-900">{doc.name}</p>
                              <p className="text-sm text-gray-600">{doc.number}</p>
                            </div>
                            <Badge className="bg-green-600 text-white">
                              <CheckCircle className="w-3 h-3 mr-1" />
                              {doc.status}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Contract Management</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div className="p-3 bg-blue-50 rounded-lg">
                          <div className="text-2xl font-bold text-blue-900">{dashboardData.activeContracts}</div>
                          <p className="text-sm text-blue-600">Active Contracts</p>
                        </div>
                        <div className="p-3 bg-green-50 rounded-lg">
                          <div className="text-2xl font-bold text-green-900">15</div>
                          <p className="text-sm text-green-600">Pending Review</p>
                        </div>
                        <div className="p-3 bg-orange-50 rounded-lg">
                          <div className="text-2xl font-bold text-orange-900">8</div>
                          <p className="text-sm text-orange-600">Expiring Soon</p>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <h4 className="font-semibold text-gray-900">Recent Contracts</h4>
                        {[
                          {
                            title: "Spotify Distribution Agreement",
                            type: "Platform Partnership",
                            status: "active",
                            expiry: "2025-03-15",
                          },
                          {
                            title: "Artist Management Contract - Nabila",
                            type: "Artist Agreement",
                            status: "active",
                            expiry: "2026-01-20",
                          },
                          {
                            title: "CISAC Membership Agreement",
                            type: "International Affiliation",
                            status: "pending",
                            expiry: "N/A",
                          },
                        ].map((contract, index) => (
                          <div key={index} className="p-3 border rounded-lg">
                            <div className="flex items-center justify-between mb-2">
                              <p className="font-medium text-gray-900">{contract.title}</p>
                              <Badge
                                variant={contract.status === "active" ? "default" : "outline"}
                                className={
                                  contract.status === "active"
                                    ? "bg-green-600 text-white"
                                    : "text-orange-700 border-orange-500"
                                }
                              >
                                {contract.status}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-600">{contract.type}</p>
                            <p className="text-xs text-gray-500">Expires: {contract.expiry}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="international" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>International Affiliations</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        {
                          name: "CISAC",
                          fullName: "International Confederation of Societies of Authors and Composers",
                          status: "approved",
                          territory: "Global",
                          revenue: "IDR 450M",
                        },
                        {
                          name: "IFPI",
                          fullName: "International Federation of the Phonographic Industry",
                          status: "active",
                          territory: "Global",
                          revenue: "IDR 320M",
                        },
                        {
                          name: "ASCAP",
                          fullName: "American Society of Composers, Authors and Publishers",
                          status: "active",
                          territory: "United States",
                          revenue: "IDR 180M",
                        },
                        {
                          name: "JASRAC",
                          fullName: "Japanese Society for Rights of Authors, Composers and Publishers",
                          status: "pending",
                          territory: "Japan",
                          revenue: "IDR 0",
                        },
                      ].map((org, index) => (
                        <div key={index} className="p-4 border rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <div>
                              <p className="font-semibold text-gray-900">{org.name}</p>
                              <p className="text-sm text-gray-600">{org.fullName}</p>
                            </div>
                            <Badge
                              variant={
                                org.status === "active"
                                  ? "default"
                                  : org.status === "approved"
                                    ? "secondary"
                                    : "outline"
                              }
                              className={
                                org.status === "active"
                                  ? "bg-green-600 text-white"
                                  : org.status === "approved"
                                    ? "bg-blue-600 text-white"
                                    : "text-orange-700 border-orange-500"
                              }
                            >
                              {org.status}
                            </Badge>
                          </div>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <p className="text-gray-600">Territory</p>
                              <p className="font-medium">{org.territory}</p>
                            </div>
                            <div>
                              <p className="text-gray-600">Revenue (YTD)</p>
                              <p className="font-medium">{org.revenue}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Global Revenue Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div className="text-center">
                        <div className="text-4xl font-bold text-gray-900 mb-2">IDR 950M</div>
                        <p className="text-gray-600">International Revenue (YTD)</p>
                      </div>

                      <div className="space-y-4">
                        {[
                          { region: "North America", revenue: 380, percentage: 40 },
                          { region: "Europe", revenue: 285, percentage: 30 },
                          { region: "Asia Pacific", revenue: 190, percentage: 20 },
                          { region: "Others", revenue: 95, percentage: 10 },
                        ].map((region, index) => (
                          <div key={index} className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="font-medium text-gray-900">{region.region}</span>
                              <span className="text-sm text-gray-600">IDR {region.revenue}M</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-3">
                              <div
                                className="bg-gradient-to-r from-blue-600 to-purple-600 h-3 rounded-full"
                                style={{ width: `${region.percentage}%` }}
                              ></div>
                            </div>
                            <div className="text-right">
                              <span className="text-xs text-gray-500">{region.percentage}%</span>
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="pt-4 border-t">
                        <Button className="w-full bg-gradient-to-r from-orange-600 to-red-600 text-white">
                          <Globe className="w-4 h-4 mr-2" />
                          Expand to New Markets
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="ai-tools" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>AI Assistant Usage</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="text-center p-6 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
                        <div className="text-4xl font-bold text-gray-900 mb-2">{dashboardData.aiInteractions}</div>
                        <p className="text-gray-600">AI Interactions This Month</p>
                        <div className="flex items-center justify-center mt-2 text-green-600">
                          <TrendingUp className="w-4 h-4 mr-1" />
                          <span className="text-sm">+25% from last month</span>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <h4 className="font-semibold text-gray-900">Popular AI Features</h4>
                        {[
                          { feature: "Royalty Inquiries", usage: 45, count: 563 },
                          { feature: "Contract Analysis", usage: 25, count: 313 },
                          { feature: "Legal Assistance", usage: 15, count: 188 },
                          { feature: "Analytics Insights", usage: 10, count: 125 },
                          { feature: "General Support", usage: 5, count: 61 },
                        ].map((item, index) => (
                          <div key={index} className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-sm font-medium text-gray-900">{item.feature}</span>
                              <span className="text-sm text-gray-600">{item.count} queries</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div
                                className="bg-gradient-to-r from-blue-600 to-purple-600 h-2 rounded-full"
                                style={{ width: `${item.usage}%` }}
                              ></div>
                            </div>
                            <div className="text-right">
                              <span className="text-xs text-gray-500">{item.usage}%</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>AI Tools & Automation</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="text-center p-4 bg-green-50 rounded-lg">
                          <div className="text-2xl font-bold text-green-900">98.5%</div>
                          <p className="text-sm text-green-600">Accuracy Rate</p>
                        </div>
                        <div className="text-center p-4 bg-blue-50 rounded-lg">
                          <div className="text-2xl font-bold text-blue-900">2.3s</div>
                          <p className="text-sm text-blue-600">Avg Response Time</p>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <h4 className="font-semibold text-gray-900">Available AI Tools</h4>
                        {[
                          {
                            name: "Legal Assistant",
                            description: "Contract analysis and legal compliance",
                            status: "active",
                          },
                          {
                            name: "Royalty Calculator",
                            description: "Automated royalty calculations and distributions",
                            status: "active",
                          },
                          {
                            name: "Content Analyzer",
                            description: "Music content analysis and metadata optimization",
                            status: "active",
                          },
                          {
                            name: "Market Predictor",
                            description: "AI-powered market trend analysis",
                            status: "beta",
                          },
                          {
                            name: "Smart Contracts",
                            description: "Automated contract generation and management",
                            status: "coming_soon",
                          },
                        ].map((tool, index) => (
                          <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                            <div>
                              <p className="font-medium text-gray-900">{tool.name}</p>
                              <p className="text-sm text-gray-600">{tool.description}</p>
                            </div>
                            <Badge
                              variant={
                                tool.status === "active" ? "default" : tool.status === "beta" ? "secondary" : "outline"
                              }
                              className={
                                tool.status === "active"
                                  ? "bg-green-600 text-white"
                                  : tool.status === "beta"
                                    ? "bg-orange-600 text-white"
                                    : "text-gray-700 border-gray-500"
                              }
                            >
                              {tool.status.replace("_", " ")}
                            </Badge>
                          </div>
                        ))}
                      </div>

                      <div className="pt-4 border-t">
                        <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white">
                          <MessageSquare className="w-4 h-4 mr-2" />
                          Launch AI Assistant
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </AuthGuard>
  )
}
