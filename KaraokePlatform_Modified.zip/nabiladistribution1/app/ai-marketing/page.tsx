"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Target, Mail, MessageSquare, Zap, Brain, Eye, Settings, Plus } from "lucide-react"
import { AuthGuard } from "@/components/auth-guard"

export default function AIMarketingPage() {
  const [activeTab, setActiveTab] = useState("campaigns")
  const [campaigns, setCampaigns] = useState([
    {
      id: 1,
      name: "Artist Onboarding Sequence",
      type: "Email",
      status: "Active",
      performance: { ctr: 12.5, conversion: 8.7, reach: 15420 },
      audience: "New Artists",
      aiOptimized: true,
    },
    {
      id: 2,
      name: "Social Media Engagement",
      type: "Social",
      status: "Active",
      performance: { ctr: 3.2, conversion: 5.1, reach: 89340 },
      audience: "Music Lovers",
      aiOptimized: true,
    },
    {
      id: 3,
      name: "Marketplace Promotion",
      type: "Ads",
      status: "Active",
      performance: { ctr: 5.8, conversion: 12.3, reach: 34560 },
      audience: "Business Users",
      aiOptimized: true,
    },
  ])

  const [marketingMetrics, setMarketingMetrics] = useState({
    totalReach: "2.4M",
    conversionRate: "8.7%",
    activeCampaigns: 12,
    aiOptimization: "94%",
    revenue: "$45,230",
    roi: "340%",
  })

  return (
    <AuthGuard>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <Target className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">AI Marketing Hub</h1>
                <p className="text-gray-600">Intelligent Marketing Automation & Campaign Management</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge className="bg-gradient-to-r from-green-600 to-blue-600 text-white">
                <Brain className="w-3 h-3 mr-1" />
                AI Optimizing
              </Badge>
              <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                <Plus className="w-4 h-4 mr-2" />
                Create AI Campaign
              </Button>
            </div>
          </div>
        </header>

        <div className="p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-5 bg-white">
              <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
              <TabsTrigger value="automation">AI Automation</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
              <TabsTrigger value="audience">Audience AI</TabsTrigger>
              <TabsTrigger value="content">Content AI</TabsTrigger>
            </TabsList>

            <TabsContent value="campaigns" className="space-y-6">
              {/* Marketing Overview */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6">
                <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Total Reach</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{marketingMetrics.totalReach}</div>
                    <p className="text-xs text-blue-100">Users reached</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{marketingMetrics.conversionRate}</div>
                    <p className="text-xs text-green-100">AI optimized</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Active Campaigns</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{marketingMetrics.activeCampaigns}</div>
                    <p className="text-xs text-purple-100">Running now</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">AI Optimization</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{marketingMetrics.aiOptimization}</div>
                    <p className="text-xs text-orange-100">Automated</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-r from-pink-500 to-pink-600 text-white">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Revenue</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{marketingMetrics.revenue}</div>
                    <p className="text-xs text-pink-100">This month</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-r from-indigo-500 to-indigo-600 text-white">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">ROI</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{marketingMetrics.roi}</div>
                    <p className="text-xs text-indigo-100">Return on investment</p>
                  </CardContent>
                </Card>
              </div>

              {/* Active Campaigns */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>AI Marketing Campaigns</CardTitle>
                      <CardDescription>Intelligent campaigns powered by machine learning</CardDescription>
                    </div>
                    <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                      <Plus className="w-4 h-4 mr-2" />
                      New Campaign
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {campaigns.map((campaign) => (
                      <div key={campaign.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <div className="w-12 h-12 bg-gradient-to-r from-purple-400 to-blue-400 rounded-lg flex items-center justify-center">
                              {campaign.type === "Email" ? (
                                <Mail className="w-6 h-6 text-white" />
                              ) : campaign.type === "Social" ? (
                                <MessageSquare className="w-6 h-6 text-white" />
                              ) : (
                                <Target className="w-6 h-6 text-white" />
                              )}
                            </div>
                            <div>
                              <h3 className="font-semibold text-gray-900 flex items-center">
                                {campaign.name}
                                {campaign.aiOptimized && (
                                  <Badge className="ml-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                                    <Brain className="w-3 h-3 mr-1" />
                                    AI
                                  </Badge>
                                )}
                              </h3>
                              <p className="text-sm text-gray-600">
                                {campaign.type} • {campaign.audience}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-6">
                            <div className="text-center">
                              <p className="text-sm font-semibold text-gray-900">{campaign.performance.ctr}%</p>
                              <p className="text-xs text-gray-600">CTR</p>
                            </div>
                            <div className="text-center">
                              <p className="text-sm font-semibold text-gray-900">{campaign.performance.conversion}%</p>
                              <p className="text-xs text-gray-600">Conversion</p>
                            </div>
                            <div className="text-center">
                              <p className="text-sm font-semibold text-gray-900">
                                {campaign.performance.reach.toLocaleString()}
                              </p>
                              <p className="text-xs text-gray-600">Reach</p>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Badge variant={campaign.status === "Active" ? "default" : "secondary"}>
                                {campaign.status}
                              </Badge>
                              <Button variant="outline" size="sm">
                                <Eye className="w-4 h-4" />
                              </Button>
                              <Button variant="outline" size="sm">
                                <Settings className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="automation" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>AI Automation Rules</CardTitle>
                    <CardDescription>Intelligent automation based on user behavior and performance</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      {
                        name: "Smart Bidding Optimization",
                        description: "Automatically adjust ad bids based on conversion probability",
                        status: "Active",
                        performance: "+23% efficiency",
                      },
                      {
                        name: "Content Personalization",
                        description: "Dynamically customize content based on user preferences",
                        status: "Active",
                        performance: "+18% engagement",
                      },
                      {
                        name: "Audience Segmentation",
                        description: "AI-powered audience clustering and targeting",
                        status: "Active",
                        performance: "+31% conversion",
                      },
                      {
                        name: "Send Time Optimization",
                        description: "Predict optimal send times for each user",
                        status: "Learning",
                        performance: "+12% open rate",
                      },
                    ].map((rule, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gradient-to-r from-purple-400 to-blue-400 rounded-lg flex items-center justify-center">
                            <Zap className="w-4 h-4 text-white" />
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">{rule.name}</p>
                            <p className="text-sm text-gray-600">{rule.description}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge variant={rule.status === "Active" ? "default" : "secondary"} className="mb-1">
                            {rule.status}
                          </Badge>
                          <p className="text-sm text-green-600">{rule.performance}</p>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>AI Learning Progress</CardTitle>
                    <CardDescription>Machine learning model performance and optimization</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { model: "Click Prediction", accuracy: 94.2, improvement: "+2.1%" },
                      { model: "Conversion Forecasting", accuracy: 91.7, improvement: "+3.4%" },
                      { model: "Audience Clustering", accuracy: 96.8, improvement: "+1.8%" },
                      { model: "Content Optimization", accuracy: 89.3, improvement: "+4.2%" },
                    ].map((model, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium text-gray-700">{model.model}</span>
                          <div className="flex items-center space-x-2">
                            <span className="text-gray-600">{model.accuracy}%</span>
                            <span className="text-green-600 text-xs">{model.improvement}</span>
                          </div>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-gradient-to-r from-purple-600 to-blue-600 h-2 rounded-full"
                            style={{ width: `${model.accuracy}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Automated Workflows</CardTitle>
                  <CardDescription>AI-driven marketing automation sequences</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {[
                      {
                        name: "Welcome Series",
                        trigger: "New user registration",
                        steps: 5,
                        conversion: "23.4%",
                        status: "Active",
                      },
                      {
                        name: "Abandoned Cart Recovery",
                        trigger: "Cart abandonment",
                        steps: 3,
                        conversion: "18.7%",
                        status: "Active",
                      },
                      {
                        name: "Re-engagement Campaign",
                        trigger: "30 days inactive",
                        steps: 4,
                        conversion: "12.1%",
                        status: "Active",
                      },
                      {
                        name: "Upsell Sequence",
                        trigger: "Purchase completion",
                        steps: 6,
                        conversion: "31.2%",
                        status: "Active",
                      },
                      {
                        name: "Referral Program",
                        trigger: "High engagement score",
                        steps: 3,
                        conversion: "8.9%",
                        status: "Testing",
                      },
                      {
                        name: "VIP Customer Journey",
                        trigger: "High lifetime value",
                        steps: 7,
                        conversion: "45.6%",
                        status: "Active",
                      },
                    ].map((workflow, index) => (
                      <Card key={index} className="hover:shadow-md transition-shadow">
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-lg">{workflow.name}</CardTitle>
                            <Badge variant={workflow.status === "Active" ? "default" : "secondary"}>
                              {workflow.status}
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            <p className="text-sm text-gray-600">
                              <strong>Trigger:</strong> {workflow.trigger}
                            </p>
                            <p className="text-sm text-gray-600">
                              <strong>Steps:</strong> {workflow.steps}
                            </p>
                            <p className="text-sm text-gray-600">
                              <strong>Conversion:</strong>{" "}
                              <span className="text-green-600 font-semibold">{workflow.conversion}</span>
                            </p>
                          </div>
                          <div className="flex space-x-2 mt-4">
                            <Button variant="outline" size="sm" className="flex-1">
                              <Eye className="w-4 h-4 mr-1" />
                              View
                            </Button>
                            <Button variant="outline" size="sm" className="flex-1">
                              <Settings className="w-4 h-4 mr-1" />
                              Edit
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Campaign Performance</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">+34.2%</div>
                    <p className="text-sm text-green-600">Improvement this month</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">AI Optimization Impact</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">+127%</div>
                    <p className="text-sm text-blue-600">ROI improvement</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Audience Growth</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">+18.7%</div>
                    <p className="text-sm text-purple-600">Monthly growth rate</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Automation Efficiency</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">94.3%</div>
                    <p className="text-sm text-orange-600">Tasks automated</p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Channel Performance</CardTitle>
                    <CardDescription>AI-optimized performance across marketing channels</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { channel: "Email Marketing", performance: 87, revenue: "$18,450", growth: "+23%" },
                      { channel: "Social Media", performance: 92, revenue: "$15,230", growth: "+31%" },
                      { channel: "Paid Advertising", performance: 78, revenue: "$8,940", growth: "+18%" },
                      { channel: "Content Marketing", performance: 85, revenue: "$2,610", growth: "+45%" },
                    ].map((channel, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium text-gray-700">{channel.channel}</span>
                          <div className="flex items-center space-x-4">
                            <span className="text-gray-600">{channel.revenue}</span>
                            <span className="text-green-600">{channel.growth}</span>
                          </div>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-gradient-to-r from-purple-600 to-blue-600 h-2 rounded-full"
                            style={{ width: `${channel.performance}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>AI Insights & Recommendations</CardTitle>
                    <CardDescription>Machine learning-powered marketing insights</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
                      <h4 className="font-semibold text-blue-900 mb-2">Audience Opportunity</h4>
                      <p className="text-sm text-blue-800">
                        AI detected a 34% increase in engagement from the 25-34 age group. Consider increasing budget
                        allocation to this segment.
                      </p>
                    </div>

                    <div className="p-4 bg-green-50 rounded-lg border-l-4 border-green-500">
                      <h4 className="font-semibold text-green-900 mb-2">Content Optimization</h4>
                      <p className="text-sm text-green-800">
                        Video content shows 67% higher engagement. AI recommends increasing video content production by
                        40%.
                      </p>
                    </div>

                    <div className="p-4 bg-purple-50 rounded-lg border-l-4 border-purple-500">
                      <h4 className="font-semibold text-purple-900 mb-2">Timing Optimization</h4>
                      <p className="text-sm text-purple-800">
                        Optimal posting time shifted to 2-4 PM EST. AI will automatically adjust scheduling for 23%
                        better reach.
                      </p>
                    </div>

                    <div className="p-4 bg-orange-50 rounded-lg border-l-4 border-orange-500">
                      <h4 className="font-semibold text-orange-900 mb-2">Budget Reallocation</h4>
                      <p className="text-sm text-orange-800">
                        Social media campaigns outperforming email by 45%. Consider reallocating 20% of email budget to
                        social.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="audience" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>AI Audience Intelligence</CardTitle>
                  <CardDescription>Advanced audience analysis and segmentation powered by machine learning</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-2">
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Smart Audience Segments</h3>
                      <div className="space-y-4">
                        {[
                          {
                            name: "High-Value Artists",
                            size: "2,847 users",
                            characteristics: "High engagement, premium features usage, frequent uploads",
                            value: "$127 LTV",
                            growth: "+23%",
                          },
                          {
                            name: "Emerging Musicians",
                            size: "8,234 users",
                            characteristics: "New to platform, high potential, learning-focused",
                            value: "$45 LTV",
                            growth: "+67%",
                          },
                          {
                            name: "Business Power Users",
                            size: "1,456 users",
                            characteristics: "Marketplace focus, high transaction volume, B2B oriented",
                            value: "$234 LTV",
                            growth: "+12%",
                          },
                          {
                            name: "Casual Listeners",
                            size: "15,678 users",
                            characteristics: "Low engagement, price-sensitive, mobile-first",
                            value: "$18 LTV",
                            growth: "+8%",
                          },
                        ].map((segment, index) => (
                          <div key={index} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                            <div className="flex items-center justify-between mb-3">
                              <h4 className="font-semibold text-gray-900">{segment.name}</h4>
                              <div className="flex items-center space-x-3">
                                <Badge variant="outline">{segment.size}</Badge>
                                <Badge variant="outline" className="text-green-700">
                                  {segment.growth}
                                </Badge>
                              </div>
                            </div>
                            <p className="text-sm text-gray-600 mb-2">{segment.characteristics}</p>
                            <div className="flex items-center justify-between">
                              <span className="text-sm font-medium text-gray-700">Lifetime Value: {segment.value}</span>
                              <Button variant="outline" size="sm">
                                <Target className="w-4 h-4 mr-1" />
                                Target
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">Audience Insights</h3>
                      <div className="space-y-4">
                        <Card>
                          <CardHeader className="pb-3">
                            <CardTitle className="text-sm">Demographics</CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-3">
                            <div className="flex justify-between text-sm">
                              <span>18-24</span>
                              <span>23%</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>25-34</span>
                              <span>45%</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>35-44</span>
                              <span>22%</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>45+</span>
                              <span>10%</span>
                            </div>
                          </CardContent>
                        </Card>

                        <Card>
                          <CardHeader className="pb-3">
                            <CardTitle className="text-sm">Geographic Distribution</CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-3">
                            <div className="flex justify-between text-sm">
                              <span>United States</span>
                              <span>34%</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Indonesia</span>
                              <span>18%</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>United Kingdom</span>
                              <span>12%</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Germany</span>
                              <span>8%</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Others</span>
                              <span>28%</span>
                            </div>
                          </CardContent>
                        </Card>

                        <Card>
                          <CardHeader className="pb-3">
                            <CardTitle className="text-sm">Behavior Patterns</CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-3">
                            <div className="flex justify-between text-sm">
                              <span>Peak Hours</span>
                              <span>7-9 PM</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Avg Session</span>
                              <span>12 min</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Mobile Usage</span>
                              <span>78%</span>
                            </div>
                            <div className="flex justify-between text-sm">
                              <span>Return Rate</span>
                              <span>67%</span>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="content" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>AI Content Generator</CardTitle>
                    <CardDescription>Create marketing content with artificial intelligence</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div>
                        <label className="text-sm font-medium text-gray-700">Content Type</label>
                        <Select defaultValue="email">
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="email">Email Campaign</SelectItem>
                            <SelectItem value="social">Social Media Post</SelectItem>
                            <SelectItem value="ad">Advertisement Copy</SelectItem>
                            <SelectItem value="blog">Blog Article</SelectItem>
                            <SelectItem value="landing">Landing Page</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-sm font-medium text-gray-700">Target Audience</label>
                        <Select defaultValue="artists">
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="artists">New Artists</SelectItem>
                            <SelectItem value="business">Business Users</SelectItem>
                            <SelectItem value="listeners">Music Listeners</SelectItem>
                            <SelectItem value="premium">Premium Users</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-sm font-medium text-gray-700">Tone</label>
                        <Select defaultValue="professional">
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="professional">Professional</SelectItem>
                            <SelectItem value="friendly">Friendly</SelectItem>
                            <SelectItem value="exciting">Exciting</SelectItem>
                            <SelectItem value="informative">Informative</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-sm font-medium text-gray-700">Topic/Keywords</label>
                        <Input
                          placeholder="Enter topic or keywords..."
                          className="mt-1"
                          defaultValue="music distribution, streaming platforms"
                        />
                      </div>

                      <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                        <Brain className="w-4 h-4 mr-2" />
                        Generate Content
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Generated Content</CardTitle>
                    <CardDescription>AI-generated marketing content ready for use</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-gray-50 rounded-lg p-4 mb-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Subject: Unlock Your Music's Potential</h4>
                      <div className="text-sm text-gray-700 space-y-2">
                        <p>Hi [First Name]</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Generated Content</CardTitle>
                    <CardDescription>AI-generated marketing content ready for use</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="bg-gray-50 rounded-lg p-4 mb-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Subject: Unlock Your Music's Potential</h4>
                      <div className="text-sm text-gray-700 space-y-2">\
                        <p>Hi [First Name
