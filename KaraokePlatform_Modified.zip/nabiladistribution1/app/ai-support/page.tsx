"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Bot,
  User,
  Send,
  MessageSquare,
  Zap,
  Brain,
  TrendingUp,
  CheckCircle,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  BarChart3,
} from "lucide-react"
import { AuthGuard } from "@/components/auth-guard"

export default function AISupportPage() {
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: "assistant",
      content:
        "Hello! I'm NABILA AI, your advanced customer support assistant. I can help you with music distribution, marketplace issues, payments, and technical support. I'm powered by advanced AI with real-time learning capabilities. How can I assist you today?",
      timestamp: new Date(),
      sentiment: "positive",
      intent: "greeting",
      confidence: 0.98,
    },
  ])
  const [inputMessage, setInputMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [activeTab, setActiveTab] = useState("chat")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const [aiMetrics, setAiMetrics] = useState({
    responseTime: "0.8s",
    accuracy: "96.8%",
    satisfaction: "4.9/5",
    resolutionRate: "87%",
    activeChats: 23,
    totalResolved: 1247,
  })

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return

    const userMessage = {
      id: messages.length + 1,
      type: "user",
      content: inputMessage,
      timestamp: new Date(),
      sentiment: "neutral",
      intent: "query",
      confidence: 0.95,
    }

    setMessages((prev) => [...prev, userMessage])
    setInputMessage("")
    setIsLoading(true)

    // Simulate AI processing with advanced features
    setTimeout(() => {
      const aiResponse = {
        id: messages.length + 2,
        type: "assistant",
        content: generateAdvancedAIResponse(inputMessage),
        timestamp: new Date(),
        sentiment: analyzeSentiment(inputMessage),
        intent: classifyIntent(inputMessage),
        confidence: Math.random() * 0.1 + 0.9, // 90-100% confidence
      }
      setMessages((prev) => [...prev, aiResponse])
      setIsLoading(false)

      // Auto-speak response if enabled
      if (isSpeaking) {
        speakText(aiResponse.content)
      }
    }, 1500)
  }

  const generateAdvancedAIResponse = (message: string) => {
    const lowerMessage = message.toLowerCase()

    if (lowerMessage.includes("payment") || lowerMessage.includes("gopay")) {
      return `I can help you with payment issues! I've analyzed your account and see you're using GoPay (0895340205302). Here's what I found:

✅ **Payment Status**: All recent transactions are successful
💰 **Available Methods**: GoPay, Bank Transfer, International Cards
🔄 **Processing Time**: Instant for GoPay, 1-3 days for bank transfers

**AI Recommendation**: Based on your location and transaction history, GoPay offers the fastest processing. Would you like me to:
1. Check a specific payment status
2. Set up automatic payments
3. Troubleshoot a failed transaction
4. Connect you with our payment specialist

I can also predict optimal payment timing based on your usage patterns.`
    } else if (lowerMessage.includes("upload") || lowerMessage.includes("music")) {
      return `I'll help you with music distribution! My AI analysis shows:

🎵 **Upload Status**: Your account supports unlimited uploads
📊 **Platform Reach**: Connected to 150+ streaming platforms
⚡ **Processing Time**: 24-48 hours for full distribution

**Smart Upload Tips** (AI-generated based on your genre):
- Optimal upload time: Tuesday-Thursday, 10 AM EST
- Recommended metadata: I can auto-generate based on audio analysis
- Cover art optimization: AI can enhance your artwork for better engagement

**Current Distribution Status**:
✅ Spotify, Apple Music, YouTube Music - Active
⏳ Amazon Music - Processing
🔄 TikTok, Instagram - Pending approval

Would you like me to:
1. Analyze your track for optimal metadata
2. Predict streaming performance
3. Suggest promotional strategies
4. Check distribution status`
    } else if (lowerMessage.includes("analytics") || lowerMessage.includes("performance")) {
      return `Great question about analytics! My AI has processed your data:

📈 **Performance Insights**:
- Your music shows 23% above-average engagement
- Peak listening hours: 7-9 PM in your target markets
- Trending in: United States, Germany, Brazil

🎯 **AI Predictions**:
- Expected growth: +15% next month
- Optimal release timing: Friday, 12 AM EST
- Recommended genres for expansion: Lo-fi, Ambient

**Smart Recommendations**:
1. **Content Strategy**: Release singles every 3-4 weeks
2. **Marketing Focus**: Target 18-34 age group on Spotify
3. **Collaboration Opportunities**: 3 artists in your network show high compatibility

**Real-time Metrics**:
- Current streams: 2.4M total
- Revenue this month: $3,247
- Growth rate: +18.7%

Would you like me to generate a detailed performance report or set up automated insights?`
    } else if (lowerMessage.includes("marketplace") || lowerMessage.includes("sell")) {
      return `I'll help optimize your marketplace presence! AI analysis complete:

🛍️ **Marketplace Performance**:
- Your products have 4.8/5 average rating
- Conversion rate: 8.7% (above platform average)
- Best-selling category: Music Equipment

🤖 **AI Optimization Suggestions**:
1. **Pricing Strategy**: Adjust prices by 5-8% for optimal sales
2. **Product Descriptions**: I can enhance with SEO keywords
3. **Image Optimization**: AI can improve product photos
4. **Inventory Management**: Predictive restocking alerts

**Market Trends** (AI-detected):
- Rising demand: Vintage audio equipment (+34%)
- Seasonal opportunity: Holiday music gear (+67% in Dec)
- Competitor analysis: You're priced competitively in 89% of categories

**Smart Actions Available**:
- Auto-generate product descriptions
- Optimize pricing in real-time
- Predict inventory needs
- Create targeted promotions

Would you like me to implement any of these optimizations or analyze specific products?`
    } else {
      return `I understand you need assistance! My advanced AI has analyzed your query and I'm ready to help.

🧠 **AI Analysis Complete**:
- Intent Classification: General Support
- Sentiment: Positive
- Complexity Level: Standard
- Estimated Resolution Time: 2-3 minutes

**I can assist with**:
🎵 Music distribution and streaming
💰 Payments and royalties
🛍️ Marketplace management
📊 Analytics and insights
🔧 Technical support
🤝 Account management

**Advanced Features Available**:
- Voice interaction (click mic icon)
- Screen sharing for technical issues
- Real-time collaboration
- Predictive problem solving
- Multi-language support

**Quick Actions**:
1. Check account status
2. Review recent activity
3. Generate performance report
4. Schedule callback with human agent

Please let me know specifically what you'd like help with, and I'll provide detailed, personalized assistance!`
    }
  }

  const analyzeSentiment = (message: string) => {
    const positiveWords = ["good", "great", "excellent", "love", "amazing", "perfect"]
    const negativeWords = ["bad", "terrible", "awful", "hate", "problem", "issue", "error"]

    const words = message.toLowerCase().split(" ")
    const positiveCount = words.filter((word) => positiveWords.includes(word)).length
    const negativeCount = words.filter((word) => negativeWords.includes(word)).length

    if (positiveCount > negativeCount) return "positive"
    if (negativeCount > positiveCount) return "negative"
    return "neutral"
  }

  const classifyIntent = (message: string) => {
    const lowerMessage = message.toLowerCase()
    if (lowerMessage.includes("payment") || lowerMessage.includes("money")) return "payment"
    if (lowerMessage.includes("upload") || lowerMessage.includes("music")) return "music_distribution"
    if (lowerMessage.includes("analytics") || lowerMessage.includes("performance")) return "analytics"
    if (lowerMessage.includes("marketplace") || lowerMessage.includes("sell")) return "marketplace"
    if (lowerMessage.includes("help") || lowerMessage.includes("support")) return "general_support"
    return "general_inquiry"
  }

  const speakText = (text: string) => {
    if ("speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.rate = 0.9
      utterance.pitch = 1
      utterance.volume = 0.8
      speechSynthesis.speak(utterance)
    }
  }

  const startListening = () => {
    if ("webkitSpeechRecognition" in window) {
      const recognition = new (window as any).webkitSpeechRecognition()
      recognition.continuous = false
      recognition.interimResults = false
      recognition.lang = "en-US"

      recognition.onstart = () => setIsListening(true)
      recognition.onend = () => setIsListening(false)
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript
        setInputMessage(transcript)
      }

      recognition.start()
    }
  }

  return (
    <AuthGuard>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <Bot className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">NABILA AI Support</h1>
                <p className="text-gray-600">Advanced AI Customer Service System</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge className="bg-gradient-to-r from-green-600 to-blue-600 text-white">
                <Brain className="w-3 h-3 mr-1" />
                AI Active
              </Badge>
              <Badge variant="outline" className="text-green-700 border-green-500">
                <CheckCircle className="w-3 h-3 mr-1" />
                {aiMetrics.activeChats} Active Chats
              </Badge>
            </div>
          </div>
        </header>

        <div className="p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 bg-white">
              <TabsTrigger value="chat">AI Chat</TabsTrigger>
              <TabsTrigger value="analytics">AI Analytics</TabsTrigger>
              <TabsTrigger value="settings">AI Settings</TabsTrigger>
              <TabsTrigger value="training">AI Training</TabsTrigger>
            </TabsList>

            <TabsContent value="chat" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                {/* Main Chat Interface */}
                <Card className="lg:col-span-3">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Bot className="w-5 h-5 text-purple-600" />
                        <CardTitle>Advanced AI Assistant</CardTitle>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="text-green-700">
                          Response Time: {aiMetrics.responseTime}
                        </Badge>
                        <Badge variant="outline" className="text-blue-700">
                          Accuracy: {aiMetrics.accuracy}
                        </Badge>
                      </div>
                    </div>
                    <CardDescription>
                      AI-powered support with sentiment analysis, intent classification, and predictive assistance
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {/* Messages */}
                    <div className="bg-gray-50 rounded-lg p-4 mb-4 h-96 overflow-y-auto">
                      <div className="space-y-4">
                        {messages.map((message) => (
                          <div
                            key={message.id}
                            className={`flex items-start space-x-3 ${
                              message.type === "user" ? "flex-row-reverse space-x-reverse" : ""
                            }`}
                          >
                            <div
                              className={`w-8 h-8 rounded-full flex items-center justify-center ${
                                message.type === "assistant"
                                  ? "bg-gradient-to-r from-purple-600 to-blue-600"
                                  : "bg-gray-600"
                              }`}
                            >
                              {message.type === "assistant" ? (
                                <Bot className="w-4 h-4 text-white" />
                              ) : (
                                <User className="w-4 h-4 text-white" />
                              )}
                            </div>
                            <div
                              className={`max-w-xs lg:max-w-md p-3 rounded-lg shadow-sm ${
                                message.type === "assistant" ? "bg-white" : "bg-blue-600 text-white"
                              }`}
                            >
                              <div className="whitespace-pre-wrap text-sm">{message.content}</div>
                              <div className="flex items-center justify-between mt-2">
                                <p
                                  className={`text-xs ${
                                    message.type === "assistant" ? "text-gray-500" : "text-blue-100"
                                  }`}
                                >
                                  {message.timestamp.toLocaleTimeString()}
                                </p>
                                {message.type === "assistant" && (
                                  <div className="flex items-center space-x-2">
                                    <Badge
                                      variant="outline"
                                      className={`text-xs ${
                                        message.sentiment === "positive"
                                          ? "border-green-500 text-green-700"
                                          : message.sentiment === "negative"
                                            ? "border-red-500 text-red-700"
                                            : "border-gray-500 text-gray-700"
                                      }`}
                                    >
                                      {message.sentiment}
                                    </Badge>
                                    <Badge variant="outline" className="text-xs border-blue-500 text-blue-700">
                                      {Math.round(message.confidence * 100)}%
                                    </Badge>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                        {isLoading && (
                          <div className="flex items-start space-x-3">
                            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center">
                              <Bot className="w-4 h-4 text-white" />
                            </div>
                            <div className="bg-white p-3 rounded-lg shadow-sm">
                              <div className="flex space-x-1">
                                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                                <div
                                  className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                                  style={{ animationDelay: "0.1s" }}
                                ></div>
                                <div
                                  className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                                  style={{ animationDelay: "0.2s" }}
                                ></div>
                              </div>
                              <p className="text-xs text-gray-500 mt-1">AI analyzing and generating response...</p>
                            </div>
                          </div>
                        )}
                        <div ref={messagesEndRef} />
                      </div>
                    </div>

                    {/* Input */}
                    <div className="flex space-x-2">
                      <div className="flex-1 relative">
                        <Input
                          placeholder="Ask me anything about your music business..."
                          value={inputMessage}
                          onChange={(e) => setInputMessage(e.target.value)}
                          onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                          className="pr-20"
                        />
                        <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex space-x-1">
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={startListening}
                            disabled={isLoading}
                            className={`p-1 ${isListening ? "text-red-600" : "text-gray-400"}`}
                          >
                            {isListening ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
                          </Button>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => setIsSpeaking(!isSpeaking)}
                            className={`p-1 ${isSpeaking ? "text-blue-600" : "text-gray-400"}`}
                          >
                            {isSpeaking ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                          </Button>
                        </div>
                      </div>
                      <Button
                        onClick={handleSendMessage}
                        disabled={isLoading || !inputMessage.trim()}
                        className="bg-gradient-to-r from-purple-600 to-blue-600 text-white"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* AI Metrics Sidebar */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">AI Performance</CardTitle>
                    <CardDescription>Real-time AI metrics</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Response Time</span>
                        <Badge variant="outline" className="text-green-700">
                          {aiMetrics.responseTime}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Accuracy</span>
                        <Badge variant="outline" className="text-blue-700">
                          {aiMetrics.accuracy}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Satisfaction</span>
                        <Badge variant="outline" className="text-purple-700">
                          {aiMetrics.satisfaction}
                        </Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-gray-600">Resolution Rate</span>
                        <Badge variant="outline" className="text-orange-700">
                          {aiMetrics.resolutionRate}
                        </Badge>
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <h4 className="font-semibold text-gray-900 mb-3">Quick Actions</h4>
                      <div className="space-y-2">
                        <Button
                          variant="outline"
                          className="w-full justify-start bg-white text-gray-700"
                          onClick={() => setInputMessage("Check my account status")}
                        >
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Account Status
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full justify-start bg-white text-gray-700"
                          onClick={() => setInputMessage("Show my recent payments")}
                        >
                          <TrendingUp className="w-4 h-4 mr-2" />
                          Payment History
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full justify-start bg-white text-gray-700"
                          onClick={() => setInputMessage("Analyze my music performance")}
                        >
                          <BarChart3 className="w-4 h-4 mr-2" />
                          Performance Report
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full justify-start bg-white text-gray-700"
                          onClick={() => setInputMessage("Help me upload new music")}
                        >
                          <MessageSquare className="w-4 h-4 mr-2" />
                          Upload Assistance
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Total Interactions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">{aiMetrics.totalResolved}</div>
                    <p className="text-sm text-green-600">+23% this month</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Resolution Rate</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">{aiMetrics.resolutionRate}</div>
                    <p className="text-sm text-blue-600">AI-powered solutions</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Avg Response Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">{aiMetrics.responseTime}</div>
                    <p className="text-sm text-purple-600">Real-time processing</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Customer Satisfaction</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">{aiMetrics.satisfaction}</div>
                    <p className="text-sm text-orange-600">Based on feedback</p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Intent Classification</CardTitle>
                    <CardDescription>AI understanding of customer queries</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { intent: "Payment Issues", percentage: 35, count: 437 },
                      { intent: "Music Distribution", percentage: 28, count: 349 },
                      { intent: "Technical Support", percentage: 18, count: 224 },
                      { intent: "Account Management", percentage: 12, count: 149 },
                      { intent: "General Inquiry", percentage: 7, count: 87 },
                    ].map((item, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium text-gray-700">{item.intent}</span>
                          <span className="text-gray-600">{item.count} queries</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-gradient-to-r from-purple-600 to-blue-600 h-2 rounded-full"
                            style={{ width: `${item.percentage}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Sentiment Analysis</CardTitle>
                    <CardDescription>Customer emotion tracking</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { sentiment: "Positive", percentage: 68, color: "green" },
                      { sentiment: "Neutral", percentage: 24, color: "gray" },
                      { sentiment: "Negative", percentage: 8, color: "red" },
                    ].map((item, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium text-gray-700">{item.sentiment}</span>
                          <span className="text-gray-600">{item.percentage}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full ${
                              item.color === "green"
                                ? "bg-green-500"
                                : item.color === "red"
                                  ? "bg-red-500"
                                  : "bg-gray-500"
                            }`}
                            style={{ width: `${item.percentage}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="settings" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>AI Configuration</CardTitle>
                  <CardDescription>Customize AI behavior and responses</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium text-gray-700">AI Model</label>
                        <Select defaultValue="gpt-4-advanced">
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="gpt-4-advanced">GPT-4 Advanced</SelectItem>
                            <SelectItem value="gpt-4-standard">GPT-4 Standard</SelectItem>
                            <SelectItem value="claude-3">Claude 3</SelectItem>
                            <SelectItem value="custom-model">Custom Model</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-sm font-medium text-gray-700">Response Style</label>
                        <Select defaultValue="professional">
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="professional">Professional</SelectItem>
                            <SelectItem value="friendly">Friendly</SelectItem>
                            <SelectItem value="technical">Technical</SelectItem>
                            <SelectItem value="casual">Casual</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-sm font-medium text-gray-700">Language</label>
                        <Select defaultValue="en">
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="en">English</SelectItem>
                            <SelectItem value="id">Indonesian</SelectItem>
                            <SelectItem value="es">Spanish</SelectItem>
                            <SelectItem value="fr">French</SelectItem>
                            <SelectItem value="de">German</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium text-gray-700">Auto-escalation Threshold</label>
                        <Select defaultValue="medium">
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="low">Low (90% confidence)</SelectItem>
                            <SelectItem value="medium">Medium (70% confidence)</SelectItem>
                            <SelectItem value="high">High (50% confidence)</SelectItem>
                            <SelectItem value="never">Never escalate</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-sm font-medium text-gray-700">Learning Mode</label>
                        <Select defaultValue="active">
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="active">Active Learning</SelectItem>
                            <SelectItem value="passive">Passive Learning</SelectItem>
                            <SelectItem value="manual">Manual Training</SelectItem>
                            <SelectItem value="disabled">Disabled</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <label className="text-sm font-medium text-gray-700">Data Retention</label>
                        <Select defaultValue="30days">
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="7days">7 Days</SelectItem>
                            <SelectItem value="30days">30 Days</SelectItem>
                            <SelectItem value="90days">90 Days</SelectItem>
                            <SelectItem value="1year">1 Year</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>

                  <div className="border-t pt-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Advanced Features</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">Voice Recognition</p>
                          <p className="text-sm text-gray-600">Enable speech-to-text input</p>
                        </div>
                        <Button variant="outline" size="sm">
                          Enabled
                        </Button>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">Text-to-Speech</p>
                          <p className="text-sm text-gray-600">AI voice responses</p>
                        </div>
                        <Button variant="outline" size="sm">
                          Enabled
                        </Button>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">Predictive Assistance</p>
                          <p className="text-sm text-gray-600">Proactive problem detection</p>
                        </div>
                        <Button variant="outline" size="sm">
                          Enabled
                        </Button>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">Multi-language Support</p>
                          <p className="text-sm text-gray-600">Automatic language detection</p>
                        </div>
                        <Button variant="outline" size="sm">
                          Enabled
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="training" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>AI Training & Improvement</CardTitle>
                  <CardDescription>Continuous learning and model optimization</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Training Sessions</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold text-gray-900">247</div>
                        <p className="text-sm text-green-600">This month</p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Model Accuracy</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold text-gray-900">96.8%</div>
                        <p className="text-sm text-blue-600">+2.3% improvement</p>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg">Learning Rate</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-3xl font-bold text-gray-900">0.001</div>
                        <p className="text-sm text-purple-600">Optimized</p>
                      </CardContent>
                    </Card>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>Recent Training Data</CardTitle>
                        <CardDescription>Latest conversations used for training</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {[
                          { topic: "Payment Processing", conversations: 45, accuracy: "98.2%" },
                          { topic: "Music Upload Issues", conversations: 32, accuracy: "96.7%" },
                          { topic: "Account Management", conversations: 28, accuracy: "94.1%" },
                          { topic: "Technical Support", conversations: 19, accuracy: "92.8%" },
                        ].map((item, index) => (
                          <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div>
                              <p className="font-medium text-gray-900">{item.topic}</p>
                              <p className="text-sm text-gray-600">{item.conversations} conversations</p>
                            </div>
                            <Badge variant="outline" className="text-green-700">
                              {item.accuracy}
                            </Badge>
                          </div>
                        ))}
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle>Model Performance</CardTitle>
                        <CardDescription>AI learning progress over time</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {[
                          { metric: "Response Accuracy", current: "96.8%", previous: "94.5%" },
                          { metric: "Intent Classification", current: "98.1%", previous: "96.3%" },
                          { metric: "Sentiment Analysis", current: "94.7%", previous: "92.1%" },
                          { metric: "Resolution Rate", current: "87.3%", previous: "84.9%" },
                        ].map((item, index) => (
                          <div key={index} className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span className="font-medium text-gray-700">{item.metric}</span>
                              <div className="flex items-center space-x-2">
                                <span className="text-gray-600">{item.previous}</span>
                                <span className="text-gray-400">→</span>
                                <span className="text-green-600 font-semibold">{item.current}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </CardContent>
                    </Card>
                  </div>

                  <div className="border-t pt-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-gray-900">Training Actions</h3>
                      <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                        <Brain className="w-4 h-4 mr-2" />
                        Start Training Session
                      </Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Button variant="outline" className="justify-start bg-white text-gray-700">
                        <Zap className="w-4 h-4 mr-2" />
                        Optimize Model Parameters
                      </Button>
                      <Button variant="outline" className="justify-start bg-white text-gray-700">
                        <TrendingUp className="w-4 h-4 mr-2" />
                        Analyze Performance Metrics
                      </Button>
                      <Button variant="outline" className="justify-start bg-white text-gray-700">
                        <MessageSquare className="w-4 h-4 mr-2" />
                        Review Training Data
                      </Button>
                      <Button variant="outline" className="justify-start bg-white text-gray-700">
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Validate Model Accuracy
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </AuthGuard>
  )
}
