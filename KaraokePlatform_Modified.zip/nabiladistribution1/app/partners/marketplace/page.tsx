"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Store, Globe, Star, MapPin, ExternalLink, Plus, Search } from "lucide-react"
import { AuthGuard } from "@/components/auth-context"

export default function PartnerMarketplacePage() {
  const [activeTab, setActiveTab] = useState("streaming")
  const [searchTerm, setSearchTerm] = useState("")
  const [filterRegion, setFilterRegion] = useState("all")

  const streamingPartners = [
    {
      name: "Spotify",
      type: "Global Streaming",
      region: "Global",
      countries: 180,
      monthlyUsers: "456M",
      revenueShare: "70%",
      payoutThreshold: "$10",
      contactEmail: "partner-support@spotify.com",
      website: "https://artists.spotify.com",
      status: "Active",
      rating: 4.8,
      features: ["Playlist Placement", "Artist Analytics", "Fan Insights", "Podcast Support"],
    },
    {
      name: "Apple Music",
      type: "Global Streaming",
      region: "Global",
      countries: 175,
      monthlyUsers: "88M",
      revenueShare: "70%",
      payoutThreshold: "$25",
      contactEmail: "music-partners@apple.com",
      website: "https://artists.apple.com",
      status: "Active",
      rating: 4.7,
      features: ["Spatial Audio", "Lossless Quality", "Radio Shows", "Music Videos"],
    },
    {
      name: "YouTube Music",
      type: "Video & Streaming",
      region: "Global",
      countries: 195,
      monthlyUsers: "80M",
      revenueShare: "55%",
      payoutThreshold: "$10",
      contactEmail: "music-support@youtube.com",
      website: "https://artists.youtube.com",
      status: "Active",
      rating: 4.5,
      features: ["Music Videos", "YouTube Integration", "Live Streaming", "Shorts"],
    },
    {
      name: "Amazon Music",
      type: "Global Streaming",
      region: "Global",
      countries: 50,
      monthlyUsers: "55M",
      revenueShare: "65%",
      payoutThreshold: "$10",
      contactEmail: "music-partners@amazon.com",
      website: "https://music.amazon.com/artists",
      status: "Active",
      rating: 4.4,
      features: ["Alexa Integration", "HD Audio", "Prime Benefits", "Voice Commands"],
    },
    {
      name: "Deezer",
      type: "Global Streaming",
      region: "Europe/Global",
      countries: 180,
      monthlyUsers: "16M",
      revenueShare: "65%",
      payoutThreshold: "$10",
      contactEmail: "artists@deezer.com",
      website: "https://artists.deezer.com",
      status: "Active",
      rating: 4.3,
      features: ["HiFi Quality", "Flow Algorithm", "Lyrics", "Podcast"],
    },
    {
      name: "Tidal",
      type: "HiFi Streaming",
      region: "Global",
      countries: 61,
      monthlyUsers: "4M",
      revenueShare: "75%",
      payoutThreshold: "$10",
      contactEmail: "artists@tidal.com",
      website: "https://artists.tidal.com",
      status: "Active",
      rating: 4.6,
      features: ["Master Quality", "Artist Ownership", "Exclusive Content", "Live Events"],
    },
  ]

  const socialPartners = [
    {
      name: "TikTok",
      type: "Social Media",
      region: "Global",
      countries: 150,
      monthlyUsers: "1B",
      revenueShare: "50%",
      payoutThreshold: "$20",
      contactEmail: "music@tiktok.com",
      website: "https://www.tiktok.com/business",
      status: "Active",
      rating: 4.7,
      features: ["Viral Potential", "Short Form Content", "Creator Fund", "Sound Trends"],
    },
    {
      name: "Instagram",
      type: "Social Media",
      region: "Global",
      countries: 195,
      monthlyUsers: "2B",
      revenueShare: "45%",
      payoutThreshold: "$100",
      contactEmail: "music@instagram.com",
      website: "https://business.instagram.com",
      status: "Active",
      rating: 4.5,
      features: ["Stories Music", "Reels", "IGTV", "Live Streaming"],
    },
    {
      name: "Facebook",
      type: "Social Media",
      region: "Global",
      countries: 195,
      monthlyUsers: "2.9B",
      revenueShare: "45%",
      payoutThreshold: "$100",
      contactEmail: "music@facebook.com",
      website: "https://business.facebook.com",
      status: "Active",
      rating: 4.2,
      features: ["Video Content", "Live Streaming", "Creator Bonus", "Fan Subscriptions"],
    },
    {
      name: "Snapchat",
      type: "Social Media",
      region: "Global",
      countries: 100,
      monthlyUsers: "750M",
      revenueShare: "50%",
      payoutThreshold: "$50",
      contactEmail: "music@snap.com",
      website: "https://business.snapchat.com",
      status: "Testing",
      rating: 4.1,
      features: ["AR Filters", "Snap Originals", "Spotlight", "Music Lenses"],
    },
  ]

  const regionalPartners = [
    {
      name: "JioSaavn",
      type: "Regional Streaming",
      region: "India/South Asia",
      countries: 5,
      monthlyUsers: "100M",
      revenueShare: "60%",
      payoutThreshold: "$5",
      contactEmail: "artists@jiosaavn.com",
      website: "https://artists.jiosaavn.com",
      status: "Active",
      rating: 4.4,
      features: ["Local Language Support", "Bollywood Focus", "Regional Music", "Podcast"],
    },
    {
      name: "Anghami",
      type: "Regional Streaming",
      region: "Middle East/North Africa",
      countries: 18,
      monthlyUsers: "70M",
      revenueShare: "65%",
      payoutThreshold: "$10",
      contactEmail: "artists@anghami.com",
      website: "https://artists.anghami.com",
      status: "Active",
      rating: 4.3,
      features: ["Arabic Music", "Local Artists", "Live Radio", "Offline Mode"],
    },
    {
      name: "NetEase Cloud Music",
      type: "Regional Streaming",
      region: "China",
      countries: 4,
      monthlyUsers: "180M",
      revenueShare: "70%",
      payoutThreshold: "$20",
      contactEmail: "music@163.com",
      website: "https://music.163.com",
      status: "Pending",
      rating: 4.6,
      features: ["Social Features", "User Comments", "Live Streaming", "K-Song"],
    },
    {
      name: "QQ Music",
      type: "Regional Streaming",
      region: "China",
      countries: 4,
      monthlyUsers: "200M",
      revenueShare: "70%",
      payoutThreshold: "$20",
      contactEmail: "music@qq.com",
      website: "https://y.qq.com",
      status: "Pending",
      rating: 4.5,
      features: ["Tencent Ecosystem", "WeChat Integration", "Live Concerts", "Karaoke"],
    },
    {
      name: "Joox",
      type: "Regional Streaming",
      region: "Southeast Asia",
      countries: 6,
      monthlyUsers: "30M",
      revenueShare: "65%",
      payoutThreshold: "$10",
      contactEmail: "artists@joox.com",
      website: "https://www.joox.com",
      status: "Active",
      rating: 4.2,
      features: ["Karaoke Mode", "Local Charts", "Live Streaming", "Social Features"],
    },
    {
      name: "Langit Musik",
      type: "Regional Streaming",
      region: "Indonesia",
      countries: 1,
      monthlyUsers: "5M",
      revenueShare: "70%",
      payoutThreshold: "$5",
      contactEmail: "artists@langitmusik.co.id",
      website: "https://www.langitmusik.co.id",
      status: "Active",
      rating: 4.0,
      features: ["Indonesian Music", "Local Artists", "Dangdut Genre", "Regional Content"],
    },
  ]

  const merchantPartners = [
    {
      name: "Bandcamp",
      type: "Music Marketplace",
      region: "Global",
      countries: 195,
      monthlyUsers: "5M",
      revenueShare: "90%",
      payoutThreshold: "$5",
      contactEmail: "artists@bandcamp.com",
      website: "https://bandcamp.com",
      status: "Active",
      rating: 4.8,
      features: ["Direct Sales", "Fan Funding", "Merchandise", "High Revenue Share"],
    },
    {
      name: "Beatport",
      type: "Electronic Music Store",
      region: "Global",
      countries: 100,
      monthlyUsers: "2M",
      revenueShare: "85%",
      payoutThreshold: "$20",
      contactEmail: "artists@beatport.com",
      website: "https://www.beatport.com",
      status: "Active",
      rating: 4.6,
      features: ["DJ Focus", "Electronic Music", "Charts", "Professional Tools"],
    },
    {
      name: "7digital",
      type: "Digital Music Store",
      region: "Global",
      countries: 50,
      monthlyUsers: "1M",
      revenueShare: "80%",
      payoutThreshold: "$25",
      contactEmail: "content@7digital.com",
      website: "https://www.7digital.com",
      status: "Active",
      rating: 4.3,
      features: ["High Quality Downloads", "B2B Services", "White Label", "API Access"],
    },
    {
      name: "Qobuz",
      type: "HiFi Music Store",
      region: "Europe/US",
      countries: 25,
      monthlyUsers: "500K",
      revenueShare: "75%",
      payoutThreshold: "$15",
      contactEmail: "artists@qobuz.com",
      website: "https://www.qobuz.com",
      status: "Active",
      rating: 4.7,
      features: ["Hi-Res Audio", "Editorial Content", "Album Reviews", "Audiophile Focus"],
    },
  ]

  const getAllPartners = () => {
    switch (activeTab) {
      case "streaming":
        return streamingPartners
      case "social":
        return socialPartners
      case "regional":
        return regionalPartners
      case "merchants":
        return merchantPartners
      default:
        return [...streamingPartners, ...socialPartners, ...regionalPartners, ...merchantPartners]
    }
  }

  const filteredPartners = getAllPartners().filter((partner) => {
    const matchesSearch =
      partner.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      partner.type.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesRegion = filterRegion === "all" || partner.region.toLowerCase().includes(filterRegion.toLowerCase())
    return matchesSearch && matchesRegion
  })

  return (
    <AuthGuard>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <Store className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Partner Marketplace</h1>
                <p className="text-gray-600">Jelajahi semua platform streaming dan merchant partner</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge className="bg-gradient-to-r from-green-600 to-blue-600 text-white">
                <Globe className="w-3 h-3 mr-1" />
                {filteredPartners.length} Partners Available
              </Badge>
              <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                <Plus className="w-4 h-4 mr-2" />
                Request New Partner
              </Button>
            </div>
          </div>
        </header>

        <div className="p-6">
          {/* Search and Filters */}
          <div className="flex items-center space-x-4 mb-6">
            <div className="flex-1 relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Cari platform atau merchant..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterRegion} onValueChange={setFilterRegion}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by region" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Region</SelectItem>
                <SelectItem value="global">Global</SelectItem>
                <SelectItem value="asia">Asia</SelectItem>
                <SelectItem value="europe">Europe</SelectItem>
                <SelectItem value="america">America</SelectItem>
                <SelectItem value="middle east">Middle East</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-5 bg-white">
              <TabsTrigger value="streaming">Streaming Platforms</TabsTrigger>
              <TabsTrigger value="social">Social Media</TabsTrigger>
              <TabsTrigger value="regional">Regional Partners</TabsTrigger>
              <TabsTrigger value="merchants">Music Merchants</TabsTrigger>
              <TabsTrigger value="all">All Partners</TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredPartners.map((partner, index) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-lg">{partner.name}</CardTitle>
                          <CardDescription>{partner.type}</CardDescription>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className="flex items-center space-x-1">
                            <Star className="w-4 h-4 text-yellow-500 fill-current" />
                            <span className="text-sm font-medium">{partner.rating}</span>
                          </div>
                          <Badge variant={partner.status === "Active" ? "default" : "secondary"}>
                            {partner.status}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {/* Key Metrics */}
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <p className="text-gray-600">Region</p>
                            <p className="font-medium flex items-center">
                              <MapPin className="w-3 h-3 mr-1" />
                              {partner.region}
                            </p>
                          </div>
                          <div>
                            <p className="text-gray-600">Countries</p>
                            <p className="font-medium">{partner.countries}</p>
                          </div>
                          <div>
                            <p className="text-gray-600">Monthly Users</p>
                            <p className="font-medium">{partner.monthlyUsers}</p>
                          </div>
                          <div>
                            <p className="text-gray-600">Revenue Share</p>
                            <p className="font-medium text-green-600">{partner.revenueShare}</p>
                          </div>
                        </div>

                        {/* Features */}
                        <div>
                          <p className="text-sm font-medium text-gray-700 mb-2">Key Features</p>
                          <div className="flex flex-wrap gap-1">
                            {partner.features.slice(0, 3).map((feature, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                {feature}
                              </Badge>
                            ))}
                            {partner.features.length > 3 && (
                              <Badge variant="outline" className="text-xs">
                                +{partner.features.length - 3} more
                              </Badge>
                            )}
                          </div>
                        </div>

                        {/* Contact Info */}
                        <div className="text-sm">
                          <p className="text-gray-600">
                            Payout Threshold: <span className="font-medium">{partner.payoutThreshold}</span>
                          </p>
                          <p className="text-gray-600">
                            Contact Email:{" "}
                            <a href={`mailto:${partner.contactEmail}`} className="text-blue-500 hover:underline">
                              {partner.contactEmail}
                            </a>
                          </p>
                          <p className="text-gray-600">
                            Website:{" "}
                            <a
                              href={partner.website}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-500 hover:underline flex items-center"
                            >
                              Visit Website
                              <ExternalLink className="w-4 h-4 ml-1" />
                            </a>
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </AuthGuard>
  )
}
