"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  CheckCircle,
  AlertTriangle,
  Info,
  FileText,
  Globe,
  DollarSign,
  Clock,
  Shield,
  Zap,
  Music,
  ImageIcon,
  Users,
} from "lucide-react"
import { AuthGuard } from "@/components/auth-guard"

export default function PlatformRequirementsPage() {
  const [activeTab, setActiveTab] = useState("technical")

  const platformRequirements = {
    Spotify: {
      technical: {
        audioFormats: ["MP3 (320kbps)", "FLAC (up to 24-bit/96kHz)"],
        maxFileSize: "200MB",
        minDuration: "30 seconds",
        maxDuration: "No limit",
        sampleRates: ["44.1kHz", "48kHz", "88.2kHz", "96kHz"],
        bitDepth: ["16-bit", "24-bit"],
        channels: ["Mono", "Stereo"],
        apiVersion: "Web API v1",
        authentication: "OAuth 2.0",
        rateLimit: "1000 requests/hour",
        webhooks: "Supported",
      },
      metadata: {
        required: ["Track Title", "Artist Name", "Album Title", "Genre", "Release Date", "ISRC"],
        optional: ["Composer", "Producer", "Label", "Copyright", "Lyrics", "Explicit Content Flag"],
        languages: ["Multiple languages supported"],
        characterLimits: {
          trackTitle: "100 characters",
          artistName: "100 characters",
          albumTitle: "100 characters",
        },
      },
      artwork: {
        format: "JPEG or PNG",
        minResolution: "640x640 pixels",
        maxResolution: "3000x3000 pixels",
        aspectRatio: "1:1 (Square)",
        maxFileSize: "10MB",
        colorSpace: "RGB",
        requirements: ["High quality", "No text overlay", "Clear and visible"],
      },
      distribution: {
        processingTime: "24-48 hours",
        territories: "Global (180+ countries)",
        releaseScheduling: "Up to 4 weeks in advance",
        takedownTime: "24-48 hours",
        updateTime: "24-48 hours",
      },
      revenue: {
        payoutThreshold: "$10 USD",
        payoutFrequency: "Monthly",
        revenueShare: "70% to rights holders",
        reportingDelay: "2-3 months",
        currencies: ["USD", "EUR", "GBP", "CAD", "AUD", "JPY"],
      },
      compliance: {
        contentPolicy: "No explicit content without proper flagging",
        copyrightPolicy: "Must own or have rights to all content",
        qualityStandards: "Professional audio quality required",
        restrictions: ["No AI-generated vocals without disclosure", "No hate speech", "No copyright infringement"],
      },
    },
    "Apple Music": {
      technical: {
        audioFormats: ["AAC (256kbps)", "ALAC (Apple Lossless)", "MP3 (320kbps)"],
        maxFileSize: "200MB",
        minDuration: "30 seconds",
        maxDuration: "No limit",
        sampleRates: ["44.1kHz", "48kHz", "88.2kHz", "96kHz", "176.4kHz", "192kHz"],
        bitDepth: ["16-bit", "24-bit"],
        channels: ["Mono", "Stereo", "Spatial Audio"],
        apiVersion: "Apple Music API v1",
        authentication: "JWT Token",
        rateLimit: "1000 requests/hour",
        webhooks: "Limited support",
      },
      metadata: {
        required: ["Track Title", "Artist Name", "Album Title", "Genre", "Release Date", "UPC/EAN", "ISRC"],
        optional: [
          "Composer",
          "Producer",
          "Label",
          "Copyright",
          "Lyrics",
          "Explicit Content Flag",
          "Spatial Audio Flag",
        ],
        languages: ["Multiple languages with proper encoding"],
        characterLimits: {
          trackTitle: "255 characters",
          artistName: "255 characters",
          albumTitle: "255 characters",
        },
      },
      artwork: {
        format: "JPEG or PNG",
        minResolution: "1400x1400 pixels",
        maxResolution: "4000x4000 pixels",
        aspectRatio: "1:1 (Square)",
        maxFileSize: "20MB",
        colorSpace: "RGB",
        requirements: ["High resolution", "No text overlay", "Professional quality"],
      },
      distribution: {
        processingTime: "24-72 hours",
        territories: "Global (175+ countries)",
        releaseScheduling: "Up to 8 weeks in advance",
        takedownTime: "24-48 hours",
        updateTime: "24-48 hours",
      },
      revenue: {
        payoutThreshold: "$25 USD",
        payoutFrequency: "Monthly",
        revenueShare: "70% to rights holders",
        reportingDelay: "45-60 days",
        currencies: ["USD", "EUR", "GBP", "CAD", "AUD", "JPY", "CNY"],
      },
      compliance: {
        contentPolicy: "Strict content guidelines",
        copyrightPolicy: "Must own or have rights to all content",
        qualityStandards: "High-quality audio required",
        restrictions: ["No explicit content without proper flagging", "No hate speech", "No copyright infringement"],
      },
    },
    "YouTube Music": {
      technical: {
        audioFormats: ["MP3 (320kbps)", "WAV", "FLAC", "AAC"],
        maxFileSize: "128MB",
        minDuration: "33 seconds",
        maxDuration: "12 hours",
        sampleRates: ["22.05kHz", "44.1kHz", "48kHz"],
        bitDepth: ["16-bit", "24-bit"],
        channels: ["Mono", "Stereo"],
        apiVersion: "YouTube Data API v3",
        authentication: "OAuth 2.0",
        rateLimit: "10,000 units/day",
        webhooks: "Supported via Pub/Sub",
      },
      metadata: {
        required: ["Track Title", "Artist Name", "Genre", "Release Date"],
        optional: ["Album Title", "Composer", "Producer", "Label", "Copyright", "Lyrics", "Language"],
        languages: ["100+ languages supported"],
        characterLimits: {
          trackTitle: "100 characters",
          artistName: "50 characters",
          description: "5000 characters",
        },
      },
      artwork: {
        format: "JPEG, PNG, GIF, BMP",
        minResolution: "640x640 pixels",
        maxResolution: "2560x2560 pixels",
        aspectRatio: "1:1 (Square)",
        maxFileSize: "2MB",
        colorSpace: "RGB",
        requirements: ["Clear and visible", "No misleading thumbnails"],
      },
      distribution: {
        processingTime: "1-24 hours",
        territories: "Global (195+ countries)",
        releaseScheduling: "Immediate or scheduled",
        takedownTime: "Immediate",
        updateTime: "1-24 hours",
      },
      revenue: {
        payoutThreshold: "$10 USD",
        payoutFrequency: "Monthly",
        revenueShare: "55% to rights holders",
        reportingDelay: "2 months",
        currencies: ["USD", "EUR", "GBP", "CAD", "AUD", "JPY", "INR", "BRL"],
      },
      compliance: {
        contentPolicy: "Community Guidelines compliance",
        copyrightPolicy: "Content ID system for copyright protection",
        qualityStandards: "Good audio quality recommended",
        restrictions: ["No hate speech", "No spam", "No misleading content"],
      },
    },
    TikTok: {
      technical: {
        audioFormats: ["MP3 (128-320kbps)", "AAC"],
        maxFileSize: "50MB",
        minDuration: "15 seconds",
        maxDuration: "3 minutes",
        sampleRates: ["44.1kHz", "48kHz"],
        bitDepth: ["16-bit"],
        channels: ["Mono", "Stereo"],
        apiVersion: "TikTok for Developers v1",
        authentication: "OAuth 2.0",
        rateLimit: "100 requests/hour",
        webhooks: "Limited support",
      },
      metadata: {
        required: ["Track Title", "Artist Name", "Genre"],
        optional: ["Album Title", "Release Date", "Label", "Explicit Content Flag"],
        languages: ["Multiple languages supported"],
        characterLimits: {
          trackTitle: "50 characters",
          artistName: "30 characters",
        },
      },
      artwork: {
        format: "JPEG or PNG",
        minResolution: "300x300 pixels",
        maxResolution: "1080x1080 pixels",
        aspectRatio: "1:1 (Square)",
        maxFileSize: "5MB",
        colorSpace: "RGB",
        requirements: ["Eye-catching", "Mobile-optimized"],
      },
      distribution: {
        processingTime: "1-7 days",
        territories: "Global (150+ countries)",
        releaseScheduling: "Up to 2 weeks in advance",
        takedownTime: "24-48 hours",
        updateTime: "24-48 hours",
      },
      revenue: {
        payoutThreshold: "$20 USD",
        payoutFrequency: "Monthly",
        revenueShare: "50% to rights holders",
        reportingDelay: "60-90 days",
        currencies: ["USD", "EUR", "GBP"],
      },
      compliance: {
        contentPolicy: "Community Guidelines and Music Guidelines",
        copyrightPolicy: "Must own or have rights to all content",
        qualityStandards: "Good audio quality",
        restrictions: ["No explicit content", "No hate speech", "No copyright infringement"],
      },
    },
  }

  const getRequirementIcon = (type: string) => {
    switch (type) {
      case "technical":
        return <Zap className="w-5 h-5" />
      case "metadata":
        return <FileText className="w-5 h-5" />
      case "artwork":
        return <ImageIcon className="w-5 h-5" />
      case "distribution":
        return <Globe className="w-5 h-5" />
      case "revenue":
        return <DollarSign className="w-5 h-5" />
      case "compliance":
        return <Shield className="w-5 h-5" />
      default:
        return <Info className="w-5 h-5" />
    }
  }

  return (
    <AuthGuard>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <FileText className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Platform Requirements</h1>
                <p className="text-gray-600">Persyaratan teknis dan integritas untuk setiap platform streaming</p>
              </div>
            </div>
            <Badge className="bg-gradient-to-r from-green-600 to-blue-600 text-white">
              <CheckCircle className="w-3 h-3 mr-1" />
              22 Platform Terintegrasi
            </Badge>
          </div>
        </header>

        <div className="p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-6 bg-white">
              <TabsTrigger value="technical">Technical</TabsTrigger>
              <TabsTrigger value="metadata">Metadata</TabsTrigger>
              <TabsTrigger value="artwork">Artwork</TabsTrigger>
              <TabsTrigger value="distribution">Distribution</TabsTrigger>
              <TabsTrigger value="revenue">Revenue</TabsTrigger>
              <TabsTrigger value="compliance">Compliance</TabsTrigger>
            </TabsList>

            {Object.entries(platformRequirements).map(([platform, requirements]) => (
              <TabsContent key={platform} value={activeTab} className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                  {Object.entries(platformRequirements).map(([platformName, platformReqs]) => (
                    <Card key={platformName} className="hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-gradient-to-r from-purple-400 to-blue-400 rounded-lg flex items-center justify-center">
                              {getRequirementIcon(activeTab)}
                            </div>
                            <div>
                              <CardTitle className="text-lg">{platformName}</CardTitle>
                              <CardDescription className="capitalize">{activeTab} Requirements</CardDescription>
                            </div>
                          </div>
                          <Badge variant="outline" className="text-green-700">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Active
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        {activeTab === "technical" && (
                          <div className="space-y-3">
                            <div>
                              <p className="text-sm font-medium text-gray-700">Audio Formats</p>
                              <div className="flex flex-wrap gap-1 mt-1">
                                {platformReqs.technical.audioFormats.map((format, index) => (
                                  <Badge key={index} variant="outline" className="text-xs">
                                    {format}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            <div className="grid grid-cols-2 gap-3 text-sm">
                              <div>
                                <p className="text-gray-600">Max File Size</p>
                                <p className="font-medium">{platformReqs.technical.maxFileSize}</p>
                              </div>
                              <div>
                                <p className="text-gray-600">Min Duration</p>
                                <p className="font-medium">{platformReqs.technical.minDuration}</p>
                              </div>
                              <div>
                                <p className="text-gray-600">API Version</p>
                                <p className="font-medium">{platformReqs.technical.apiVersion}</p>
                              </div>
                              <div>
                                <p className="text-gray-600">Rate Limit</p>
                                <p className="font-medium">{platformReqs.technical.rateLimit}</p>
                              </div>
                            </div>
                          </div>
                        )}

                        {activeTab === "metadata" && (
                          <div className="space-y-3">
                            <div>
                              <p className="text-sm font-medium text-gray-700">Required Fields</p>
                              <div className="flex flex-wrap gap-1 mt-1">
                                {platformReqs.metadata.required.map((field, index) => (
                                  <Badge key={index} variant="default" className="text-xs">
                                    {field}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            <div>
                              <p className="text-sm font-medium text-gray-700">Optional Fields</p>
                              <div className="flex flex-wrap gap-1 mt-1">
                                {platformReqs.metadata.optional.slice(0, 4).map((field, index) => (
                                  <Badge key={index} variant="outline" className="text-xs">
                                    {field}
                                  </Badge>
                                ))}
                                {platformReqs.metadata.optional.length > 4 && (
                                  <Badge variant="outline" className="text-xs">
                                    +{platformReqs.metadata.optional.length - 4} more
                                  </Badge>
                                )}
                              </div>
                            </div>
                            <div className="text-sm">
                              <p className="text-gray-600">Character Limits</p>
                              <div className="mt-1 space-y-1">
                                {Object.entries(platformReqs.metadata.characterLimits).map(([field, limit]) => (
                                  <div key={field} className="flex justify-between">
                                    <span className="capitalize">{field.replace(/([A-Z])/g, " $1")}</span>
                                    <span className="font-medium">{limit}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        )}

                        {activeTab === "artwork" && (
                          <div className="space-y-3">
                            <div className="grid grid-cols-2 gap-3 text-sm">
                              <div>
                                <p className="text-gray-600">Format</p>
                                <p className="font-medium">{platformReqs.artwork.format}</p>
                              </div>
                              <div>
                                <p className="text-gray-600">Aspect Ratio</p>
                                <p className="font-medium">{platformReqs.artwork.aspectRatio}</p>
                              </div>
                              <div>
                                <p className="text-gray-600">Min Resolution</p>
                                <p className="font-medium">{platformReqs.artwork.minResolution}</p>
                              </div>
                              <div>
                                <p className="text-gray-600">Max Resolution</p>
                                <p className="font-medium">{platformReqs.artwork.maxResolution}</p>
                              </div>
                              <div>
                                <p className="text-gray-600">Max File Size</p>
                                <p className="font-medium">{platformReqs.artwork.maxFileSize}</p>
                              </div>
                              <div>
                                <p className="text-gray-600">Color Space</p>
                                <p className="font-medium">{platformReqs.artwork.colorSpace}</p>
                              </div>
                            </div>
                            <div>
                              <p className="text-sm font-medium text-gray-700">Requirements</p>
                              <ul className="mt-1 space-y-1">
                                {platformReqs.artwork.requirements.map((req, index) => (
                                  <li key={index} className="text-xs text-gray-600 flex items-center">
                                    <CheckCircle className="w-3 h-3 text-green-600 mr-1" />
                                    {req}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        )}

                        {activeTab === "distribution" && (
                          <div className="space-y-3">
                            <div className="grid grid-cols-1 gap-3 text-sm">
                              <div className="flex justify-between">
                                <span className="text-gray-600">Processing Time</span>
                                <span className="font-medium">{platformReqs.distribution.processingTime}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-gray-600">Territories</span>
                                <span className="font-medium">{platformReqs.distribution.territories}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-gray-600">Release Scheduling</span>
                                <span className="font-medium">{platformReqs.distribution.releaseScheduling}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-gray-600">Takedown Time</span>
                                <span className="font-medium">{platformReqs.distribution.takedownTime}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-gray-600">Update Time</span>
                                <span className="font-medium">{platformReqs.distribution.updateTime}</span>
                              </div>
                            </div>
                          </div>
                        )}

                        {activeTab === "revenue" && (
                          <div className="space-y-3">
                            <div className="grid grid-cols-1 gap-3 text-sm">
                              <div className="flex justify-between">
                                <span className="text-gray-600">Payout Threshold</span>
                                <span className="font-medium">{platformReqs.revenue.payoutThreshold}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-gray-600">Payout Frequency</span>
                                <span className="font-medium">{platformReqs.revenue.payoutFrequency}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-gray-600">Revenue Share</span>
                                <span className="font-medium text-green-600">{platformReqs.revenue.revenueShare}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-gray-600">Reporting Delay</span>
                                <span className="font-medium">{platformReqs.revenue.reportingDelay}</span>
                              </div>
                            </div>
                            <div>
                              <p className="text-sm font-medium text-gray-700">Supported Currencies</p>
                              <div className="flex flex-wrap gap-1 mt-1">
                                {platformReqs.revenue.currencies.map((currency, index) => (
                                  <Badge key={index} variant="outline" className="text-xs">
                                    {currency}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                        )}

                        {activeTab === "compliance" && (
                          <div className="space-y-3">
                            <div>
                              <p className="text-sm font-medium text-gray-700">Content Policy</p>
                              <p className="text-xs text-gray-600 mt-1">{platformReqs.compliance.contentPolicy}</p>
                            </div>
                            <div>
                              <p className="text-sm font-medium text-gray-700">Copyright Policy</p>
                              <p className="text-xs text-gray-600 mt-1">{platformReqs.compliance.copyrightPolicy}</p>
                            </div>
                            <div>
                              <p className="text-sm font-medium text-gray-700">Quality Standards</p>
                              <p className="text-xs text-gray-600 mt-1">{platformReqs.compliance.qualityStandards}</p>
                            </div>
                            <div>
                              <p className="text-sm font-medium text-gray-700">Restrictions</p>
                              <ul className="mt-1 space-y-1">
                                {platformReqs.compliance.restrictions.map((restriction, index) => (
                                  <li key={index} className="text-xs text-gray-600 flex items-center">
                                    <AlertTriangle className="w-3 h-3 text-orange-600 mr-1" />
                                    {restriction}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>

          {/* Integration Summary */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Platform Integration Summary</CardTitle>
              <CardDescription>Ringkasan lengkap integrasi dengan semua platform streaming</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Globe className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900">Global Reach</h3>
                  <p className="text-sm text-gray-600 mt-1">195+ countries covered</p>
                  <p className="text-xs text-gray-500">Worldwide distribution</p>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Music className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900">Audio Quality</h3>
                  <p className="text-sm text-gray-600 mt-1">Up to 24-bit/192kHz</p>
                  <p className="text-xs text-gray-500">Lossless audio support</p>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Clock className="w-8 h-8 text-purple-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900">Fast Processing</h3>
                  <p className="text-sm text-gray-600 mt-1">1-48 hours average</p>
                  <p className="text-xs text-gray-500">Quick distribution</p>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <DollarSign className="w-8 h-8 text-orange-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900">Revenue Share</h3>
                  <p className="text-sm text-gray-600 mt-1">50-75% to artists</p>
                  <p className="text-xs text-gray-500">Competitive rates</p>
                </div>
              </div>

              <div className="mt-8 p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
                <div className="flex items-start space-x-3">
                  <Info className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-blue-900">Tim Partner Platform Tersedia</h4>
                    <p className="text-sm text-blue-800 mt-1">
                      Tim khusus kami siap membantu integrasi dengan platform streaming baru dan mengelola hubungan
                      dengan partner yang sudah ada. Hubungi tim partner relations untuk dukungan teknis dan negosiasi
                      kontrak.
                    </p>
                    <div className="mt-3 flex space-x-3">
                      <Button size="sm" className="bg-blue-600 text-white">
                        <Users className="w-4 h-4 mr-1" />
                        Hubungi Tim Partner
                      </Button>
                      <Button size="sm" variant="outline" className="bg-white text-blue-700">
                        <FileText className="w-4 h-4 mr-1" />
                        Download Requirements
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AuthGuard>
  )
}
