"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Globe,
  Zap,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Clock,
  Users,
  Settings,
  Plus,
  Eye,
  RefreshCw,
  Wifi,
  WifiOff,
  Music,
  Radio,
  Headphones,
  Smartphone,
} from "lucide-react"
import { AuthGuard } from "@/components/auth-guard"
import { supabase } from "@/lib/supabase"

export default function PartnersPage() {
  const [activeTab, setActiveTab] = useState("overview")
  const [partners, setPartners] = useState([])
  const [integrations, setIntegrations] = useState([])
  const [revenues, setRevenues] = useState([])
  const [alerts, setAlerts] = useState([])

  const [partnerMetrics, setPartnerMetrics] = useState({
    totalPartners: 0,
    activeIntegrations: 0,
    totalRevenue: 0,
    avgResponseTime: 0,
    successRate: 0,
    pendingDistributions: 0,
  })

  useEffect(() => {
    fetchPartnerData()
  }, [])

  const fetchPartnerData = async () => {
    try {
      // Fetch streaming partners
      const { data: partnersData } = await supabase
        .from("streaming_partners")
        .select(`
          *,
          partner_team_assignments(
            team_members(
              profiles(full_name)
            )
          )
        `)
        .order("platform_name")

      // Fetch integrations
      const { data: integrationsData } = await supabase
        .from("partner_integrations")
        .select("*")
        .order("last_request", { ascending: false })

      // Fetch recent revenues
      const { data: revenuesData } = await supabase
        .from("platform_revenues")
        .select(`
          *,
          streaming_partners(platform_name),
          tracks(title)
        `)
        .order("created_at", { ascending: false })
        .limit(50)

      // Fetch alerts
      const { data: alertsData } = await supabase
        .from("partner_alerts")
        .select(`
          *,
          streaming_partners(platform_name)
        `)
        .eq("is_resolved", false)
        .order("created_at", { ascending: false })

      setPartners(partnersData || [])
      setIntegrations(integrationsData || [])
      setRevenues(revenuesData || [])
      setAlerts(alertsData || [])

      // Calculate metrics
      const totalRevenue = revenuesData?.reduce((sum, rev) => sum + Number.parseFloat(rev.net_revenue || 0), 0) || 0
      const activeIntegrations = partnersData?.filter((p) => p.integration_status === "active").length || 0

      setPartnerMetrics({
        totalPartners: partnersData?.length || 0,
        activeIntegrations,
        totalRevenue,
        avgResponseTime: 145, // ms
        successRate: 98.7, // %
        pendingDistributions: 23,
      })
    } catch (error) {
      console.error("Error fetching partner data:", error)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "active":
      case "connected":
        return <CheckCircle className="w-4 h-4 text-green-600" />
      case "pending":
      case "testing":
        return <Clock className="w-4 h-4 text-yellow-600" />
      case "maintenance":
        return <Settings className="w-4 h-4 text-blue-600" />
      case "suspended":
      case "disconnected":
      case "error":
        return <AlertTriangle className="w-4 h-4 text-red-600" />
      default:
        return <Clock className="w-4 h-4 text-gray-600" />
    }
  }

  const getPlatformIcon = (type: string) => {
    switch (type) {
      case "streaming":
        return <Music className="w-5 h-5" />
      case "social":
        return <Smartphone className="w-5 h-5" />
      case "radio":
        return <Radio className="w-5 h-5" />
      case "podcast":
        return <Headphones className="w-5 h-5" />
      default:
        return <Globe className="w-5 h-5" />
    }
  }

  return (
    <AuthGuard>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <Globe className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Partner Platform Management</h1>
                <p className="text-gray-600">Kelola integrasi dengan platform streaming & distribusi musik</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge className="bg-gradient-to-r from-green-600 to-blue-600 text-white">
                <Wifi className="w-3 h-3 mr-1" />
                {partnerMetrics.activeIntegrations} Platform Aktif
              </Badge>
              <Button onClick={fetchPartnerData} variant="outline" className="bg-white text-gray-700">
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
              <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                <Plus className="w-4 h-4 mr-2" />
                Tambah Partner
              </Button>
            </div>
          </div>
        </header>

        <div className="p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-6 bg-white">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="platforms">Platform Partners</TabsTrigger>
              <TabsTrigger value="integrations">API Integrations</TabsTrigger>
              <TabsTrigger value="revenue">Revenue Tracking</TabsTrigger>
              <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
              <TabsTrigger value="team">Team Management</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              {/* Key Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6">
                <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Total Partners</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{partnerMetrics.totalPartners}</div>
                    <p className="text-xs text-blue-100">Platform streaming</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Active Integrations</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{partnerMetrics.activeIntegrations}</div>
                    <p className="text-xs text-green-100">Terhubung aktif</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">${partnerMetrics.totalRevenue.toFixed(0)}</div>
                    <p className="text-xs text-purple-100">Bulan ini</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Avg Response</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{partnerMetrics.avgResponseTime}ms</div>
                    <p className="text-xs text-orange-100">API response time</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-r from-pink-500 to-pink-600 text-white">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{partnerMetrics.successRate}%</div>
                    <p className="text-xs text-pink-100">API success rate</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-r from-indigo-500 to-indigo-600 text-white">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Pending</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{partnerMetrics.pendingDistributions}</div>
                    <p className="text-xs text-indigo-100">Distribusi pending</p>
                  </CardContent>
                </Card>
              </div>

              {/* Platform Status Overview */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Platform Status Overview</CardTitle>
                    <CardDescription>Status integrasi platform streaming utama</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {partners.slice(0, 8).map((partner, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gradient-to-r from-purple-400 to-blue-400 rounded-lg flex items-center justify-center">
                            {getPlatformIcon(partner.platform_type)}
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">{partner.platform_name}</p>
                            <p className="text-sm text-gray-600 capitalize">{partner.platform_type}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className="text-right">
                            <p className="text-sm font-medium text-gray-900">{partner.revenue_share_percentage}%</p>
                            <p className="text-xs text-gray-600">Revenue share</p>
                          </div>
                          <div className="flex items-center space-x-2">
                            {getStatusIcon(partner.integration_status)}
                            <Badge
                              variant={partner.integration_status === "active" ? "default" : "secondary"}
                              className="text-xs"
                            >
                              {partner.integration_status}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Recent Alerts</CardTitle>
                    <CardDescription>Notifikasi dan peringatan sistem</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {alerts.slice(0, 6).map((alert, index) => (
                      <div key={index} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                        <div
                          className={`w-2 h-2 rounded-full mt-2 ${
                            alert.severity === "critical"
                              ? "bg-red-500"
                              : alert.severity === "high"
                                ? "bg-orange-500"
                                : alert.severity === "medium"
                                  ? "bg-yellow-500"
                                  : "bg-blue-500"
                          }`}
                        ></div>
                        <div className="flex-1">
                          <p className="font-medium text-gray-900">{alert.title}</p>
                          <p className="text-sm text-gray-600">{alert.description}</p>
                          <p className="text-xs text-gray-500 mt-1">
                            {alert.streaming_partners?.platform_name} • {new Date(alert.created_at).toLocaleString()}
                          </p>
                        </div>
                        <Badge
                          variant={alert.severity === "critical" ? "destructive" : "secondary"}
                          className="text-xs"
                        >
                          {alert.severity}
                        </Badge>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>

              {/* Global Distribution Map */}
              <Card>
                <CardHeader>
                  <CardTitle>Global Distribution Coverage</CardTitle>
                  <CardDescription>Jangkauan distribusi musik ke seluruh dunia</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-blue-600">195</div>
                      <p className="text-sm text-gray-600">Negara Terjangkau</p>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-green-600">150+</div>
                      <p className="text-sm text-gray-600">Platform Streaming</p>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-purple-600">50+</div>
                      <p className="text-sm text-gray-600">Platform Regional</p>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-orange-600">24/7</div>
                      <p className="text-sm text-gray-600">Monitoring Aktif</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="platforms" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Platform Partners</h2>
                <div className="flex items-center space-x-3">
                  <Select defaultValue="all">
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Filter by type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua Platform</SelectItem>
                      <SelectItem value="streaming">Streaming</SelectItem>
                      <SelectItem value="social">Social Media</SelectItem>
                      <SelectItem value="radio">Radio</SelectItem>
                      <SelectItem value="podcast">Podcast</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                    <Plus className="w-4 h-4 mr-2" />
                    Tambah Platform
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {partners.map((partner, index) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-12 h-12 bg-gradient-to-r from-purple-400 to-blue-400 rounded-lg flex items-center justify-center">
                            {getPlatformIcon(partner.platform_type)}
                          </div>
                          <div>
                            <h3 className="font-semibold text-gray-900">{partner.platform_name}</h3>
                            <p className="text-sm text-gray-600 capitalize">{partner.platform_type}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          {getStatusIcon(partner.integration_status)}
                          <Badge variant={partner.integration_status === "active" ? "default" : "secondary"}>
                            {partner.integration_status}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Revenue Share:</span>
                          <span className="font-medium">{partner.revenue_share_percentage}%</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Payout:</span>
                          <span className="font-medium capitalize">{partner.payout_frequency}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Countries:</span>
                          <span className="font-medium">{partner.supported_countries?.length || 0}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Formats:</span>
                          <span className="font-medium">{partner.supported_formats?.join(", ")}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Max Size:</span>
                          <span className="font-medium">{partner.max_file_size_mb}MB</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Last Sync:</span>
                          <span className="font-medium">
                            {partner.last_sync ? new Date(partner.last_sync).toLocaleDateString() : "Never"}
                          </span>
                        </div>
                        <div className="flex space-x-2 mt-4">
                          <Button variant="outline" size="sm" className="flex-1">
                            <Eye className="w-4 h-4 mr-1" />
                            View
                          </Button>
                          <Button variant="outline" size="sm" className="flex-1">
                            <Settings className="w-4 h-4 mr-1" />
                            Configure
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="integrations" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">API Integrations</h2>
                <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                  <Zap className="w-4 h-4 mr-2" />
                  Test All APIs
                </Button>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Integration Status</CardTitle>
                  <CardDescription>Status koneksi API dengan platform partner</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      {
                        platform: "Spotify",
                        status: "connected",
                        lastRequest: "2 minutes ago",
                        usage: "847/1000",
                        responseTime: "120ms",
                      },
                      {
                        platform: "Apple Music",
                        status: "connected",
                        lastRequest: "5 minutes ago",
                        usage: "623/1000",
                        responseTime: "95ms",
                      },
                      {
                        platform: "YouTube Music",
                        status: "connected",
                        lastRequest: "1 minute ago",
                        usage: "1234/2000",
                        responseTime: "180ms",
                      },
                      {
                        platform: "Amazon Music",
                        status: "connected",
                        lastRequest: "8 minutes ago",
                        usage: "456/1000",
                        responseTime: "110ms",
                      },
                      {
                        platform: "TikTok",
                        status: "rate_limited",
                        lastRequest: "15 minutes ago",
                        usage: "500/500",
                        responseTime: "250ms",
                      },
                      {
                        platform: "Deezer",
                        status: "connected",
                        lastRequest: "3 minutes ago",
                        usage: "234/1000",
                        responseTime: "140ms",
                      },
                      {
                        platform: "SoundCloud",
                        status: "error",
                        lastRequest: "1 hour ago",
                        usage: "0/1000",
                        responseTime: "timeout",
                      },
                      {
                        platform: "Tidal",
                        status: "connected",
                        lastRequest: "12 minutes ago",
                        usage: "123/500",
                        responseTime: "85ms",
                      },
                    ].map((integration, index) => (
                      <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-gradient-to-r from-purple-400 to-blue-400 rounded-lg flex items-center justify-center">
                            <Music className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <h3 className="font-medium text-gray-900">{integration.platform}</h3>
                            <p className="text-sm text-gray-600">Last request: {integration.lastRequest}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-6">
                          <div className="text-center">
                            <p className="text-sm font-medium text-gray-900">{integration.usage}</p>
                            <p className="text-xs text-gray-600">API Usage</p>
                          </div>
                          <div className="text-center">
                            <p className="text-sm font-medium text-gray-900">{integration.responseTime}</p>
                            <p className="text-xs text-gray-600">Response Time</p>
                          </div>
                          <div className="flex items-center space-x-2">
                            {integration.status === "connected" ? (
                              <Wifi className="w-4 h-4 text-green-600" />
                            ) : integration.status === "rate_limited" ? (
                              <Clock className="w-4 h-4 text-yellow-600" />
                            ) : (
                              <WifiOff className="w-4 h-4 text-red-600" />
                            )}
                            <Badge
                              variant={
                                integration.status === "connected"
                                  ? "default"
                                  : integration.status === "rate_limited"
                                    ? "secondary"
                                    : "destructive"
                              }
                            >
                              {integration.status}
                            </Badge>
                          </div>
                          <Button variant="outline" size="sm">
                            <RefreshCw className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="revenue" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Revenue Tracking</h2>
                <Button variant="outline" className="bg-white text-gray-700">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Export Report
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Total Revenue</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">
                      ${partnerMetrics.totalRevenue.toLocaleString()}
                    </div>
                    <p className="text-sm text-green-600">+23.5% from last month</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Top Platform</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">Spotify</div>
                    <p className="text-sm text-blue-600">$45,230 this month</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Avg Revenue Share</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">68.5%</div>
                    <p className="text-sm text-purple-600">Artist revenue share</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Pending Payouts</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">$12,847</div>
                    <p className="text-sm text-orange-600">To be processed</p>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Revenue by Platform</CardTitle>
                  <CardDescription>Pendapatan dari setiap platform streaming</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { platform: "Spotify", revenue: 45230, share: 35, growth: "+18%" },
                      { platform: "Apple Music", revenue: 32150, share: 25, growth: "+22%" },
                      { platform: "YouTube Music", revenue: 18940, share: 15, growth: "+31%" },
                      { platform: "Amazon Music", revenue: 12680, share: 10, growth: "+12%" },
                      { platform: "Deezer", revenue: 8450, share: 7, growth: "+8%" },
                      { platform: "Tidal", revenue: 6320, share: 5, growth: "+15%" },
                      { platform: "Others", revenue: 4230, share: 3, growth: "+25%" },
                    ].map((item, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium text-gray-700">{item.platform}</span>
                          <div className="flex items-center space-x-4">
                            <span className="text-gray-600">${item.revenue.toLocaleString()}</span>
                            <span className="text-green-600">{item.growth}</span>
                          </div>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-gradient-to-r from-purple-600 to-blue-600 h-2 rounded-full"
                            style={{ width: `${item.share}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="monitoring" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">System Monitoring</h2>
                <Badge className="bg-gradient-to-r from-green-600 to-blue-600 text-white">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  All Systems Operational
                </Badge>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">API Uptime</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">99.97%</div>
                    <p className="text-sm text-green-600">Last 30 days</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Avg Response Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">145ms</div>
                    <p className="text-sm text-blue-600">Across all platforms</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Error Rate</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">0.03%</div>
                    <p className="text-sm text-purple-600">Very low error rate</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Active Alerts</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">{alerts.length}</div>
                    <p className="text-sm text-orange-600">Requiring attention</p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Platform Health Status</CardTitle>
                    <CardDescription>Real-time status monitoring</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { platform: "Spotify API", status: "operational", uptime: "99.98%", responseTime: "120ms" },
                      { platform: "Apple Music API", status: "operational", uptime: "99.95%", responseTime: "95ms" },
                      { platform: "YouTube Music API", status: "operational", uptime: "99.92%", responseTime: "180ms" },
                      { platform: "Amazon Music API", status: "operational", uptime: "99.89%", responseTime: "110ms" },
                      { platform: "TikTok API", status: "degraded", uptime: "98.45%", responseTime: "350ms" },
                      { platform: "Deezer API", status: "operational", uptime: "99.97%", responseTime: "140ms" },
                    ].map((item, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div
                            className={`w-3 h-3 rounded-full ${
                              item.status === "operational"
                                ? "bg-green-500"
                                : item.status === "degraded"
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                            }`}
                          ></div>
                          <span className="font-medium text-gray-700">{item.platform}</span>
                        </div>
                        <div className="flex items-center space-x-4 text-sm">
                          <span className="text-gray-600">{item.uptime}</span>
                          <span className="text-gray-600">{item.responseTime}</span>
                          <Badge variant={item.status === "operational" ? "default" : "secondary"}>{item.status}</Badge>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Recent API Logs</CardTitle>
                    <CardDescription>Latest API requests and responses</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      {
                        time: "14:23:45",
                        platform: "Spotify",
                        method: "POST",
                        endpoint: "/tracks",
                        status: 200,
                        duration: "120ms",
                      },
                      {
                        time: "14:23:42",
                        platform: "Apple Music",
                        method: "GET",
                        endpoint: "/catalog",
                        status: 200,
                        duration: "95ms",
                      },
                      {
                        time: "14:23:38",
                        platform: "YouTube",
                        method: "POST",
                        endpoint: "/upload",
                        status: 201,
                        duration: "280ms",
                      },
                      {
                        time: "14:23:35",
                        platform: "Amazon",
                        method: "PUT",
                        endpoint: "/metadata",
                        status: 200,
                        duration: "110ms",
                      },
                      {
                        time: "14:23:30",
                        platform: "TikTok",
                        method: "POST",
                        endpoint: "/content",
                        status: 429,
                        duration: "500ms",
                      },
                      {
                        time: "14:23:25",
                        platform: "Deezer",
                        method: "GET",
                        endpoint: "/tracks",
                        status: 200,
                        duration: "140ms",
                      },
                    ].map((log, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-2 text-sm border-l-2 border-gray-200 pl-3"
                      >
                        <div className="flex items-center space-x-3">
                          <span className="text-gray-500 font-mono">{log.time}</span>
                          <span className="font-medium">{log.platform}</span>
                          <Badge variant="outline" className="text-xs">
                            {log.method}
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-gray-600">{log.duration}</span>
                          <Badge
                            variant={log.status < 300 ? "default" : log.status < 400 ? "secondary" : "destructive"}
                          >
                            {log.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="team" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Partner Team Management</h2>
                <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                  <Users className="w-4 h-4 mr-2" />
                  Assign Team Member
                </Button>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Team Assignments</CardTitle>
                  <CardDescription>Tim yang bertanggung jawab untuk setiap platform partner</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      {
                        platform: "Spotify",
                        accountManager: "Sarah Johnson",
                        technicalLead: "Mike Chen",
                        contact: "Emily Rodriguez",
                      },
                      {
                        platform: "Apple Music",
                        accountManager: "David Kim",
                        technicalLead: "Lisa Wang",
                        contact: "Alex Thompson",
                      },
                      {
                        platform: "YouTube Music",
                        accountManager: "Sarah Johnson",
                        technicalLead: "Mike Chen",
                        contact: "Emily Rodriguez",
                      },
                      {
                        platform: "Amazon Music",
                        accountManager: "David Kim",
                        technicalLead: "Lisa Wang",
                        contact: "Alex Thompson",
                      },
                      {
                        platform: "TikTok",
                        accountManager: "Sarah Johnson",
                        technicalLead: "Mike Chen",
                        contact: "Emily Rodriguez",
                      },
                      {
                        platform: "Deezer",
                        accountManager: "David Kim",
                        technicalLead: "Lisa Wang",
                        contact: "Alex Thompson",
                      },
                    ].map((assignment, index) => (
                      <div key={index} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="font-semibold text-gray-900">{assignment.platform}</h3>
                          <Button variant="outline" size="sm">
                            <Settings className="w-4 h-4 mr-1" />
                            Manage
                          </Button>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <p className="text-sm text-gray-600">Account Manager</p>
                            <p className="font-medium text-gray-900">{assignment.accountManager}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-600">Technical Lead</p>
                            <p className="font-medium text-gray-900">{assignment.technicalLead}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-600">Primary Contact</p>
                            <p className="font-medium text-gray-900">{assignment.contact}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Team Performance</CardTitle>
                    <CardDescription>Kinerja tim dalam mengelola partner</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { member: "Sarah Johnson", role: "Account Manager", platforms: 8, performance: 96 },
                      { member: "Mike Chen", role: "Technical Lead", platforms: 12, performance: 94 },
                      { member: "Emily Rodriguez", role: "Primary Contact", platforms: 6, performance: 98 },
                      { member: "David Kim", role: "Account Manager", platforms: 7, performance: 92 },
                      { member: "Lisa Wang", role: "Technical Lead", platforms: 9, performance: 95 },
                    ].map((member, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">{member.member}</p>
                          <p className="text-sm text-gray-600">
                            {member.role} • {member.platforms} platforms
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-green-600">{member.performance}%</p>
                          <p className="text-xs text-gray-600">Performance</p>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Contact Information</CardTitle>
                    <CardDescription>Kontak penting untuk setiap platform</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      {
                        platform: "Spotify",
                        contact: "partner-support@spotify.com",
                        phone: "+1-555-0123",
                        timezone: "EST",
                      },
                      {
                        platform: "Apple Music",
                        contact: "music-partners@apple.com",
                        phone: "+1-555-0124",
                        timezone: "PST",
                      },
                      {
                        platform: "YouTube Music",
                        contact: "music-support@youtube.com",
                        phone: "+1-555-0125",
                        timezone: "PST",
                      },
                      {
                        platform: "Amazon Music",
                        contact: "music-partners@amazon.com",
                        phone: "+1-555-0126",
                        timezone: "EST",
                      },
                    ].map((contact, index) => (
                      <div key={index} className="border-l-4 border-blue-500 pl-3">
                        <p className="font-medium text-gray-900">{contact.platform}</p>
                        <p className="text-sm text-gray-600">{contact.contact}</p>
                        <p className="text-sm text-gray-600">
                          {contact.phone} ({contact.timezone})
                        </p>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </AuthGuard>
  )
}
