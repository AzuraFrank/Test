"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Users,
  UserPlus,
  CheckCircle,
  TrendingUp,
  MessageSquare,
  Target,
  BarChart3,
  Settings,
  Shield,
} from "lucide-react"
import { AuthGuard } from "@/components/auth-guard"
import { supabase } from "@/lib/supabase"

export default function TeamManagementPage() {
  const [activeTab, setActiveTab] = useState("overview")
  const [teamData, setTeamData] = useState({
    members: [],
    tasks: [],
    campaigns: [],
    tickets: [],
    metrics: [],
  })

  useEffect(() => {
    fetchTeamData()
  }, [])

  const fetchTeamData = async () => {
    try {
      // Fetch team members
      const { data: members } = await supabase
        .from("team_members")
        .select(`
          *,
          profiles(full_name, email)
        `)
        .eq("status", "active")

      // Fetch tasks
      const { data: tasks } = await supabase
        .from("tasks")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(10)

      // Fetch marketing campaigns
      const { data: campaigns } = await supabase
        .from("marketing_campaigns")
        .select("*")
        .order("created_at", { ascending: false })

      // Fetch support tickets
      const { data: tickets } = await supabase
        .from("support_tickets")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(10)

      // Fetch performance metrics
      const { data: metrics } = await supabase
        .from("performance_metrics")
        .select("*")
        .order("timestamp", { ascending: false })
        .limit(20)

      setTeamData({
        members: members || [],
        tasks: tasks || [],
        campaigns: campaigns || [],
        tickets: tickets || [],
        metrics: metrics || [],
      })
    } catch (error) {
      console.error("Error fetching team data:", error)
    }
  }

  return (
    <AuthGuard>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Team Management</h1>
              <p className="text-gray-600">AI-Powered Team & Quality Management System</p>
            </div>
            <div className="flex items-center space-x-4">
              <Badge className="bg-gradient-to-r from-green-600 to-blue-600 text-white">
                <Shield className="w-3 h-3 mr-1" />
                System Stable
              </Badge>
              <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                <UserPlus className="w-4 h-4 mr-2" />
                Add Team Member
              </Button>
            </div>
          </div>
        </header>

        <div className="p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-6 bg-white">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="team">Team</TabsTrigger>
              <TabsTrigger value="marketing">AI Marketing</TabsTrigger>
              <TabsTrigger value="support">AI Support</TabsTrigger>
              <TabsTrigger value="quality">Quality Control</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              {/* Key Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Active Team Members</CardTitle>
                    <Users className="h-4 w-4" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{teamData.members.length}</div>
                    <p className="text-xs text-blue-100">Across 6 departments</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Tasks Completed</CardTitle>
                    <CheckCircle className="h-4 w-4" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {teamData.tasks.filter((task) => task.status === "completed").length}
                    </div>
                    <p className="text-xs text-green-100">This week</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">AI Campaigns Active</CardTitle>
                    <Target className="h-4 w-4" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {teamData.campaigns.filter((campaign) => campaign.status === "active").length}
                    </div>
                    <p className="text-xs text-purple-100">Automated marketing</p>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Support Tickets</CardTitle>
                    <MessageSquare className="h-4 w-4" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {teamData.tickets.filter((ticket) => ticket.status === "open").length}
                    </div>
                    <p className="text-xs text-orange-100">Open tickets</p>
                  </CardContent>
                </Card>
              </div>

              {/* System Health */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>System Performance</CardTitle>
                    <CardDescription>Real-time monitoring of platform health</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { name: "Website Uptime", value: "99.9%", status: "excellent", color: "green" },
                      { name: "API Response Time", value: "150ms", status: "good", color: "blue" },
                      { name: "Database Performance", value: "50ms", status: "excellent", color: "green" },
                      { name: "User Satisfaction", value: "4.8/5", status: "excellent", color: "green" },
                    ].map((metric, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div
                            className={`w-3 h-3 rounded-full ${
                              metric.color === "green" ? "bg-green-500" : "bg-blue-500"
                            }`}
                          ></div>
                          <span className="font-medium text-gray-700">{metric.name}</span>
                        </div>
                        <div className="text-right">
                          <span className="font-semibold text-gray-900">{metric.value}</span>
                          <Badge
                            variant="outline"
                            className={`ml-2 text-xs ${
                              metric.color === "green"
                                ? "border-green-500 text-green-700"
                                : "border-blue-500 text-blue-700"
                            }`}
                          >
                            {metric.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Recent Activities</CardTitle>
                    <CardDescription>Latest team and system activities</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      {
                        action: "AI Marketing Campaign Launched",
                        user: "Marketing Team",
                        time: "2 minutes ago",
                        type: "marketing",
                      },
                      {
                        action: "Quality Check Completed",
                        user: "QA System",
                        time: "5 minutes ago",
                        type: "quality",
                      },
                      {
                        action: "Support Ticket Resolved",
                        user: "AI Assistant",
                        time: "8 minutes ago",
                        type: "support",
                      },
                      {
                        action: "Performance Alert Cleared",
                        user: "Monitoring System",
                        time: "12 minutes ago",
                        type: "system",
                      },
                    ].map((activity, index) => (
                      <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                        <div
                          className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                            activity.type === "marketing"
                              ? "bg-purple-100"
                              : activity.type === "quality"
                                ? "bg-green-100"
                                : activity.type === "support"
                                  ? "bg-blue-100"
                                  : "bg-orange-100"
                          }`}
                        >
                          {activity.type === "marketing" ? (
                            <Target className="w-4 h-4 text-purple-600" />
                          ) : activity.type === "quality" ? (
                            <CheckCircle className="w-4 h-4 text-green-600" />
                          ) : activity.type === "support" ? (
                            <MessageSquare className="w-4 h-4 text-blue-600" />
                          ) : (
                            <BarChart3 className="w-4 h-4 text-orange-600" />
                          )}
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-gray-900">{activity.action}</p>
                          <p className="text-sm text-gray-600">
                            by {activity.user} • {activity.time}
                          </p>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="team" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Team Management</h2>
                <div className="flex items-center space-x-3">
                  <Select>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Filter by role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Roles</SelectItem>
                      <SelectItem value="admin">Admin</SelectItem>
                      <SelectItem value="manager">Manager</SelectItem>
                      <SelectItem value="marketing">Marketing</SelectItem>
                      <SelectItem value="support">Support</SelectItem>
                      <SelectItem value="developer">Developer</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                    <UserPlus className="w-4 h-4 mr-2" />
                    Add Member
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  {
                    name: "Sarah Johnson",
                    role: "Marketing Manager",
                    department: "Marketing",
                    status: "active",
                    tasks: 12,
                    performance: 95,
                  },
                  {
                    name: "Mike Chen",
                    role: "AI Support Specialist",
                    department: "Customer Service",
                    status: "active",
                    tasks: 8,
                    performance: 92,
                  },
                  {
                    name: "Emily Rodriguez",
                    role: "Quality Analyst",
                    department: "Quality Assurance",
                    status: "active",
                    tasks: 15,
                    performance: 98,
                  },
                  {
                    name: "David Kim",
                    role: "DevOps Engineer",
                    department: "Technology",
                    status: "active",
                    tasks: 6,
                    performance: 89,
                  },
                  {
                    name: "Lisa Wang",
                    role: "Data Analyst",
                    department: "Analytics",
                    status: "active",
                    tasks: 10,
                    performance: 94,
                  },
                  {
                    name: "Alex Thompson",
                    role: "Operations Manager",
                    department: "Operations",
                    status: "active",
                    tasks: 18,
                    performance: 96,
                  },
                ].map((member, index) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-12 h-12 bg-gradient-to-r from-purple-400 to-blue-400 rounded-full flex items-center justify-center">
                            <span className="text-white font-semibold">
                              {member.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </span>
                          </div>
                          <div>
                            <h3 className="font-semibold text-gray-900">{member.name}</h3>
                            <p className="text-sm text-gray-600">{member.role}</p>
                          </div>
                        </div>
                        <Badge variant={member.status === "active" ? "default" : "secondary"}>{member.status}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Department:</span>
                          <span className="font-medium">{member.department}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Active Tasks:</span>
                          <span className="font-medium">{member.tasks}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Performance:</span>
                          <span className="font-medium text-green-600">{member.performance}%</span>
                        </div>
                        <Button variant="outline" className="w-full bg-white text-gray-700">
                          <Settings className="w-4 h-4 mr-2" />
                          Manage
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="marketing" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">AI Marketing Management</h2>
                <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                  <Target className="w-4 h-4 mr-2" />
                  Create AI Campaign
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Active Campaigns</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">
                      {teamData.campaigns.filter((c) => c.status === "active").length}
                    </div>
                    <p className="text-sm text-green-600">AI-powered automation</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Total Reach</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">2.4M</div>
                    <p className="text-sm text-blue-600">Users reached this month</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Conversion Rate</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">8.7%</div>
                    <p className="text-sm text-purple-600">AI-optimized performance</p>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>AI Marketing Campaigns</CardTitle>
                  <CardDescription>Automated campaigns powered by artificial intelligence</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      {
                        name: "Artist Onboarding Sequence",
                        type: "Email",
                        status: "Active",
                        performance: "12.5% CTR",
                        audience: "New Artists",
                      },
                      {
                        name: "Social Media Engagement",
                        type: "Social",
                        status: "Active",
                        performance: "3.2% Engagement",
                        audience: "Music Lovers",
                      },
                      {
                        name: "Marketplace Promotion",
                        type: "Ads",
                        status: "Active",
                        performance: "5.8% Conversion",
                        audience: "Business Users",
                      },
                      {
                        name: "Retargeting Campaign",
                        type: "Display",
                        status: "Paused",
                        performance: "2.1% CTR",
                        audience: "Previous Visitors",
                      },
                    ].map((campaign, index) => (
                      <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-gradient-to-r from-purple-400 to-blue-400 rounded-lg flex items-center justify-center">
                            <Target className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h3 className="font-medium text-gray-900">{campaign.name}</h3>
                            <p className="text-sm text-gray-600">
                              {campaign.type} • {campaign.audience}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          <div className="text-right">
                            <p className="font-semibold text-gray-900">{campaign.performance}</p>
                            <Badge variant={campaign.status === "Active" ? "default" : "secondary"}>
                              {campaign.status}
                            </Badge>
                          </div>
                          <Button variant="outline" size="sm" className="bg-white text-gray-700">
                            Manage
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="support" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">AI Customer Support</h2>
                <Badge className="bg-gradient-to-r from-green-600 to-blue-600 text-white">
                  <MessageSquare className="w-3 h-3 mr-1" />
                  AI Active 24/7
                </Badge>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">AI Resolution Rate</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">87%</div>
                    <p className="text-sm text-green-600">Automated resolution</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Avg Response Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">12s</div>
                    <p className="text-sm text-blue-600">AI-powered instant response</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Satisfaction Score</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">4.8/5</div>
                    <p className="text-sm text-purple-600">Customer satisfaction</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Active Chats</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">23</div>
                    <p className="text-sm text-orange-600">Currently handling</p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Support Tickets</CardTitle>
                    <CardDescription>Latest customer support interactions</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      {
                        id: "#12345",
                        subject: "Music upload issue",
                        status: "Resolved",
                        priority: "Medium",
                        time: "2 hours ago",
                      },
                      {
                        id: "#12346",
                        subject: "Payment not processed",
                        status: "In Progress",
                        priority: "High",
                        time: "4 hours ago",
                      },
                      {
                        id: "#12347",
                        subject: "Account verification",
                        status: "Resolved",
                        priority: "Low",
                        time: "6 hours ago",
                      },
                      {
                        id: "#12348",
                        subject: "API integration help",
                        status: "Open",
                        priority: "Medium",
                        time: "8 hours ago",
                      },
                    ].map((ticket, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">{ticket.subject}</p>
                          <p className="text-sm text-gray-600">
                            {ticket.id} • {ticket.time}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge
                            variant={
                              ticket.priority === "High"
                                ? "destructive"
                                : ticket.priority === "Medium"
                                  ? "default"
                                  : "secondary"
                            }
                            className="text-xs"
                          >
                            {ticket.priority}
                          </Badge>
                          <Badge variant={ticket.status === "Resolved" ? "default" : "secondary"} className="text-xs">
                            {ticket.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>AI Assistant Performance</CardTitle>
                    <CardDescription>Real-time AI support metrics</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { metric: "Intent Recognition", value: "96.5%", trend: "up" },
                      { metric: "Sentiment Analysis", value: "94.2%", trend: "up" },
                      { metric: "Auto-Resolution", value: "87.3%", trend: "up" },
                      { metric: "Escalation Rate", value: "12.7%", trend: "down" },
                    ].map((item, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <span className="font-medium text-gray-700">{item.metric}</span>
                        <div className="flex items-center space-x-2">
                          <span className="font-semibold text-gray-900">{item.value}</span>
                          <TrendingUp
                            className={`w-4 h-4 ${item.trend === "up" ? "text-green-600" : "text-red-600"}`}
                          />
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="quality" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Quality Control System</h2>
                <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Run Quality Check
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Quality Score</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">98.5%</div>
                    <p className="text-sm text-green-600">Overall platform quality</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Automated Checks</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">1,247</div>
                    <p className="text-sm text-blue-600">Checks performed today</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Issues Detected</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">3</div>
                    <p className="text-sm text-orange-600">Requiring attention</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Auto-Fixed</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">18</div>
                    <p className="text-sm text-purple-600">Issues resolved automatically</p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Quality Checks</CardTitle>
                    <CardDescription>Automated quality assurance monitoring</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      {
                        check: "User Registration Flow",
                        status: "Passed",
                        lastRun: "5 minutes ago",
                        issues: 0,
                      },
                      {
                        check: "Music Upload Process",
                        status: "Passed",
                        lastRun: "10 minutes ago",
                        issues: 0,
                      },
                      {
                        check: "Payment Processing",
                        status: "Warning",
                        lastRun: "15 minutes ago",
                        issues: 1,
                      },
                      {
                        check: "API Endpoints",
                        status: "Passed",
                        lastRun: "20 minutes ago",
                        issues: 0,
                      },
                      {
                        check: "Database Performance",
                        status: "Passed",
                        lastRun: "25 minutes ago",
                        issues: 0,
                      },
                    ].map((check, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div
                            className={`w-3 h-3 rounded-full ${
                              check.status === "Passed"
                                ? "bg-green-500"
                                : check.status === "Warning"
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                            }`}
                          ></div>
                          <div>
                            <p className="font-medium text-gray-900">{check.check}</p>
                            <p className="text-sm text-gray-600">Last run: {check.lastRun}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge
                            variant={
                              check.status === "Passed"
                                ? "default"
                                : check.status === "Warning"
                                  ? "secondary"
                                  : "destructive"
                            }
                          >
                            {check.status}
                          </Badge>
                          {check.issues > 0 && <p className="text-xs text-orange-600 mt-1">{check.issues} issues</p>}
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>System Health Monitoring</CardTitle>
                    <CardDescription>Real-time platform monitoring</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { component: "Web Server", status: "Healthy", uptime: "99.9%" },
                      { component: "Database", status: "Healthy", uptime: "99.8%" },
                      { component: "API Gateway", status: "Healthy", uptime: "99.9%" },
                      { component: "File Storage", status: "Healthy", uptime: "99.7%" },
                      { component: "Payment System", status: "Warning", uptime: "99.5%" },
                    ].map((component, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div
                            className={`w-3 h-3 rounded-full ${
                              component.status === "Healthy" ? "bg-green-500" : "bg-yellow-500"
                            }`}
                          ></div>
                          <span className="font-medium text-gray-700">{component.component}</span>
                        </div>
                        <div className="text-right">
                          <span className="font-semibold text-gray-900">{component.uptime}</span>
                          <Badge
                            variant={component.status === "Healthy" ? "default" : "secondary"}
                            className="ml-2 text-xs"
                          >
                            {component.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Advanced Analytics</h2>
                <Button variant="outline" className="bg-white text-gray-700">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Export Report
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Daily Active Users</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">2,547</div>
                    <p className="text-sm text-green-600">+12.5% from yesterday</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Revenue Growth</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">+18.7%</div>
                    <p className="text-sm text-blue-600">Month over month</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Conversion Rate</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">8.9%</div>
                    <p className="text-sm text-purple-600">AI-optimized funnels</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Customer Satisfaction</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-gray-900">4.8/5</div>
                    <p className="text-sm text-orange-600">Based on 1,247 reviews</p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Performance Trends</CardTitle>
                    <CardDescription>Key metrics over time</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        { metric: "User Engagement", value: "+15.3%", period: "Last 30 days" },
                        { metric: "Platform Stability", value: "99.9%", period: "Uptime this month" },
                        { metric: "AI Accuracy", value: "96.8%", period: "Support resolution" },
                        { metric: "Revenue per User", value: "+22.1%", period: "Quarter over quarter" },
                      ].map((trend, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div>
                            <p className="font-medium text-gray-900">{trend.metric}</p>
                            <p className="text-sm text-gray-600">{trend.period}</p>
                          </div>
                          <div className="text-right">
                            <span className="text-lg font-semibold text-green-600">{trend.value}</span>
                            <TrendingUp className="w-4 h-4 text-green-600 inline ml-1" />
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>AI Performance Metrics</CardTitle>
                    <CardDescription>Artificial intelligence system performance</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        { system: "Marketing AI", accuracy: 94, efficiency: 97 },
                        { system: "Support AI", accuracy: 96, efficiency: 93 },
                        { system: "Quality AI", accuracy: 98, efficiency: 95 },
                        { system: "Analytics AI", accuracy: 92, efficiency: 98 },
                      ].map((ai, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="font-medium text-gray-700">{ai.system}</span>
                            <span className="text-gray-600">Accuracy: {ai.accuracy}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-gradient-to-r from-purple-600 to-blue-600 h-2 rounded-full"
                              style={{ width: `${ai.accuracy}%` }}
                            ></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </AuthGuard>
  )
}
