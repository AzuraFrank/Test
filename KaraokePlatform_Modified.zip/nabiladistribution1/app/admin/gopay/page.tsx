"use client"

import { GopayMonitoringDashboard } from "@/components/gopay-monitoring-dashboard"
import { AuthGuard } from "@/components/auth-guard"

export default function GopayAdminPage() {
  return (
    <AuthGuard>
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">GoPay Admin Panel</h1>
              <p className="text-gray-600">Real-time monitoring dan kontrol payment gateway</p>
            </div>
          </div>
        </header>

        <div className="p-6">
          <GopayMonitoringDashboard />
        </div>
      </div>
    </AuthGuard>
  )
}
