import { LogoShowcase } from "@/components/logo-showcase"

export default function LogoShowcasePage() {
  return <LogoShowcase />
}
