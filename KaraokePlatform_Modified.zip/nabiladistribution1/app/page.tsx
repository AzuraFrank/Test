import { Logo } from "@/components/logo"
import { UserMenu } from "@/components/user-menu"

export default function Home() {
  return (
    <div>
      <header className="border-b bg-white/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Logo variant="full" size="md" theme="gradient" />
          <UserMenu />
        </div>
      </header>
      <main className="container mx-auto px-4 py-8">
        {/* Your main content here */}
        <h1>Welcome to the Home Page</h1>
        <p>This is a basic home page structure.</p>
      </main>
    </div>
  )
}
