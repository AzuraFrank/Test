"use client"

import { AuthGuard } from "@/components/auth-guard"
import { AppLayout } from "@/components/layout/app-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Music, TrendingUp, DollarSign, Globe, Headphones, BarChart3, Zap, Shield, Sparkles, Play } from "lucide-react"
import { PartnerMonitoringWidget } from "@/components/partner-monitoring-widget"
import Link from "next/link"
import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"

export default function DashboardPage() {
  const { user, profile } = useAuth()
  const [stats, setStats] = useState({
    totalTracks: 1247,
    totalStreams: 2847392,
    totalRevenue: 45678.9,
    activeArtists: 89,
    platformsConnected: 152,
    monthlyGrowth: 23.5,
    pendingPayments: 12,
    activeDistributions: 45,
  })

  const [recentActivity, setRecentActivity] = useState([
    {
      id: 1,
      type: "music",
      title: "New Track Distributed",
      description: "'Summer Vibes' by Artist Name",
      timestamp: "2 min ago",
      status: "success",
    },
    {
      id: 2,
      type: "payment",
      title: "Royalty Payment Processed",
      description: "$1,234.56 to 12 artists",
      timestamp: "1 hour ago",
      status: "success",
    },
    {
      id: 3,
      type: "platform",
      title: "New Platform Connected",
      description: "TikTok Music integration active",
      timestamp: "3 hours ago",
      status: "success",
    },
    {
      id: 4,
      type: "legal",
      title: "Contract Signed",
      description: "Distribution agreement with Spotify",
      timestamp: "5 hours ago",
      status: "success",
    },
  ])

  const [topTracks, setTopTracks] = useState([
    { title: "Summer Vibes", artist: "Artist Name", streams: "456K", revenue: "$1,247", growth: "+12%" },
    { title: "Midnight Dreams", artist: "Another Artist", streams: "389K", revenue: "$1,089", growth: "+8%" },
    { title: "Electric Soul", artist: "Music Creator", streams: "298K", revenue: "$834", growth: "+15%" },
    { title: "Ocean Waves", artist: "Sound Artist", streams: "267K", revenue: "$748", growth: "+5%" },
  ])

  useEffect(() => {
    // Fetch real data in production
    // fetchDashboardData()
  }, [user])

  return (
    <AuthGuard>
      <AppLayout>
        <div className="container mx-auto px-4 py-8 space-y-8">
          {/* Welcome Section */}
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h1 className="text-3xl font-bold tracking-tight">Welcome back, {profile?.full_name || "User"}!</h1>
              <p className="text-muted-foreground">Here's what's happening with your music distribution today.</p>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="text-green-700 border-green-500">
                <Zap className="w-3 h-3 mr-1" />
                All Systems Operational
              </Badge>
            </div>
          </div>

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-8 gap-4">
            <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0 col-span-2">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100 text-sm font-medium">Total Tracks</p>
                    <p className="text-2xl font-bold">{stats.totalTracks.toLocaleString()}</p>
                    <p className="text-blue-200 text-xs">+{stats.activeDistributions} active</p>
                  </div>
                  <Music className="w-8 h-8 text-blue-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white border-0 col-span-2">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100 text-sm font-medium">Total Streams</p>
                    <p className="text-2xl font-bold">{(stats.totalStreams / 1000000).toFixed(1)}M</p>
                    <p className="text-green-200 text-xs">+{stats.monthlyGrowth}% this month</p>
                  </div>
                  <Headphones className="w-8 h-8 text-green-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0 col-span-2">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100 text-sm font-medium">Revenue</p>
                    <p className="text-2xl font-bold">${(stats.totalRevenue / 1000).toFixed(0)}K</p>
                    <p className="text-purple-200 text-xs">{stats.pendingPayments} pending</p>
                  </div>
                  <DollarSign className="w-8 h-8 text-purple-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white border-0 col-span-2">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-orange-100 text-sm font-medium">Platforms</p>
                    <p className="text-2xl font-bold">{stats.platformsConnected}</p>
                    <p className="text-orange-200 text-xs">Global reach</p>
                  </div>
                  <Globe className="w-8 h-8 text-orange-200" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Dashboard Tabs */}
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="music">Music</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
              <TabsTrigger value="payments">Payments</TabsTrigger>
              <TabsTrigger value="ai-tools">AI Tools</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Recent Activity */}
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <BarChart3 className="w-5 h-5" />
                      <span>Recent Activity</span>
                    </CardTitle>
                    <CardDescription>Latest updates from your distribution network</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {recentActivity.map((activity) => (
                      <div key={activity.id} className="flex items-center space-x-3 p-3 bg-muted/50 rounded-lg">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">{activity.title}</p>
                          <p className="text-xs text-muted-foreground">{activity.description}</p>
                        </div>
                        <span className="text-xs text-muted-foreground">{activity.timestamp}</span>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                {/* Quick Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Zap className="w-5 h-5" />
                      <span>Quick Actions</span>
                    </CardTitle>
                    <CardDescription>Common tasks and shortcuts</CardDescription>
                  </CardHeader>
                  <CardContent className="grid grid-cols-1 gap-3">
                    <Button asChild className="h-auto p-4 flex flex-col items-center space-y-2">
                      <Link href="/music/upload">
                        <Music className="w-6 h-6" />
                        <span className="text-sm">Upload Track</span>
                      </Link>
                    </Button>

                    <Button asChild variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                      <Link href="/analytics">
                        <BarChart3 className="w-6 h-6" />
                        <span className="text-sm">View Analytics</span>
                      </Link>
                    </Button>

                    <Button asChild variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                      <Link href="/partners">
                        <Globe className="w-6 h-6" />
                        <span className="text-sm">Manage Partners</span>
                      </Link>
                    </Button>

                    <Button asChild variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2">
                      <Link href="/admin/gopay">
                        <Shield className="w-6 h-6" />
                        <span className="text-sm">GoPay Monitor</span>
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* Top Performing Tracks */}
              <Card>
                <CardHeader>
                  <CardTitle>Top Performing Tracks</CardTitle>
                  <CardDescription>Your most successful releases this month</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {topTracks.map((track, index) => (
                      <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-gradient-to-r from-purple-400 to-blue-400 rounded-lg flex items-center justify-center">
                            <Play className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h3 className="font-medium">{track.title}</h3>
                            <p className="text-sm text-muted-foreground">{track.artist}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-6 text-sm">
                          <div className="text-center">
                            <p className="font-medium">{track.streams}</p>
                            <p className="text-muted-foreground">Streams</p>
                          </div>
                          <div className="text-center">
                            <p className="font-medium">{track.revenue}</p>
                            <p className="text-muted-foreground">Revenue</p>
                          </div>
                          <div className="text-center">
                            <p className="font-medium text-green-600">{track.growth}</p>
                            <p className="text-muted-foreground">Growth</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Partner Monitoring Widget */}
              <PartnerMonitoringWidget />
            </TabsContent>

            <TabsContent value="music" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle>Music Library</CardTitle>
                    <CardDescription>Manage your distributed tracks</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { title: "Summer Vibes", status: "Live", platforms: 15, streams: "456K" },
                      { title: "Midnight Dreams", status: "Live", platforms: 15, streams: "389K" },
                      { title: "Electric Soul", status: "Processing", platforms: 12, streams: "298K" },
                      { title: "Ocean Waves", status: "Live", platforms: 15, streams: "267K" },
                    ].map((track, index) => (
                      <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-gradient-to-r from-purple-400 to-blue-400 rounded-lg flex items-center justify-center">
                            <Music className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h3 className="font-medium">{track.title}</h3>
                            <p className="text-sm text-muted-foreground">
                              {track.platforms} platforms • {track.streams} streams
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <Badge variant={track.status === "Live" ? "default" : "secondary"}>{track.status}</Badge>
                          <Button variant="outline" size="sm">
                            View Details
                          </Button>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Distribution Status</CardTitle>
                    <CardDescription>Platform availability</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { platform: "Spotify", status: "Active", percentage: 100 },
                      { platform: "Apple Music", status: "Active", percentage: 100 },
                      { platform: "YouTube Music", status: "Active", percentage: 100 },
                      { platform: "Amazon Music", status: "Pending", percentage: 75 },
                      { platform: "TikTok", status: "Active", percentage: 100 },
                    ].map((item, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">{item.platform}</span>
                          <Badge variant={item.status === "Active" ? "default" : "secondary"}>{item.status}</Badge>
                        </div>
                        <Progress value={item.percentage} className="h-2" />
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Stream Growth</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-green-600">+23.5%</div>
                    <Progress value={75} className="mt-2" />
                    <p className="text-xs text-muted-foreground mt-1">vs last month</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Revenue Growth</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-blue-600">+18.2%</div>
                    <Progress value={60} className="mt-2" />
                    <p className="text-xs text-muted-foreground mt-1">vs last month</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">New Listeners</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-purple-600">12.4K</div>
                    <Progress value={85} className="mt-2" />
                    <p className="text-xs text-muted-foreground mt-1">this month</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Engagement Rate</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-orange-600">67.8%</div>
                    <Progress value={68} className="mt-2" />
                    <p className="text-xs text-muted-foreground mt-1">average</p>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Top Countries</CardTitle>
                    <CardDescription>Geographic performance</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { country: "United States", percentage: 35, streams: "840K" },
                      { country: "United Kingdom", percentage: 18, streams: "432K" },
                      { country: "Germany", percentage: 12, streams: "288K" },
                      { country: "Canada", percentage: 10, streams: "240K" },
                      { country: "Australia", percentage: 8, streams: "192K" },
                    ].map((item, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium">{item.country}</span>
                          <span className="text-muted-foreground">{item.streams}</span>
                        </div>
                        <Progress value={item.percentage} className="h-2" />
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Platform Performance</CardTitle>
                    <CardDescription>Revenue by platform</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { platform: "Spotify", revenue: "$4,247", percentage: 45 },
                      { platform: "Apple Music", revenue: "$2,891", percentage: 30 },
                      { platform: "YouTube Music", revenue: "$1,456", percentage: 15 },
                      { platform: "Amazon Music", revenue: "$967", percentage: 10 },
                    ].map((item, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="font-medium">{item.platform}</span>
                          <span className="text-muted-foreground">{item.revenue}</span>
                        </div>
                        <Progress value={item.percentage} className="h-2" />
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="payments" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>GoPay Integration</CardTitle>
                    <CardDescription>Real-time payment monitoring</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <div>
                        <p className="font-semibold">Current Balance</p>
                        <p className="text-2xl font-bold text-green-600">Rp 2,450,000</p>
                      </div>
                      <Badge variant="secondary" className="bg-green-100 text-green-800">
                        <Zap className="w-3 h-3 mr-1" />
                        Live
                      </Badge>
                    </div>

                    <Button asChild className="w-full">
                      <Link href="/admin/gopay">
                        <Shield className="w-4 h-4 mr-2" />
                        Open GoPay Dashboard
                      </Link>
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Recent Transactions</CardTitle>
                    <CardDescription>Latest payment activities</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {[
                      {
                        type: "Royalty Payment",
                        artist: "John Doe",
                        amount: "+$234.56",
                        time: "2 hours ago",
                        positive: true,
                      },
                      {
                        type: "Platform Fee",
                        artist: "Spotify Distribution",
                        amount: "-$12.50",
                        time: "5 hours ago",
                        positive: false,
                      },
                      {
                        type: "Royalty Payment",
                        artist: "Jane Smith",
                        amount: "+$456.78",
                        time: "1 day ago",
                        positive: true,
                      },
                    ].map((transaction, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium">{transaction.type}</p>
                          <p className="text-sm text-muted-foreground">{transaction.artist}</p>
                        </div>
                        <div className="text-right">
                          <p className={`font-semibold ${transaction.positive ? "text-green-600" : "text-red-600"}`}>
                            {transaction.amount}
                          </p>
                          <p className="text-xs text-muted-foreground">{transaction.time}</p>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="ai-tools" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  {
                    title: "AI Assistant",
                    description: "Get instant help with your music business",
                    icon: Sparkles,
                    href: "/ai-assistant",
                    badge: "NEW",
                  },
                  {
                    title: "Smart Analytics",
                    description: "AI-powered insights and predictions",
                    icon: BarChart3,
                    href: "/analytics",
                    badge: null,
                  },
                  {
                    title: "Legal Assistant",
                    description: "AI-powered legal support and contract analysis",
                    icon: Shield,
                    href: "/legal/ai-assistant",
                    badge: "BETA",
                  },
                  {
                    title: "Revenue Optimizer",
                    description: "Maximize your streaming revenue with AI",
                    icon: TrendingUp,
                    href: "/ai/revenue",
                    badge: "COMING SOON",
                  },
                  {
                    title: "Content Analyzer",
                    description: "AI analysis for better music categorization",
                    icon: Music,
                    href: "/ai/content",
                    badge: "COMING SOON",
                  },
                  {
                    title: "Market Predictor",
                    description: "Predict market trends with AI",
                    icon: Globe,
                    href: "/ai/trends",
                    badge: "COMING SOON",
                  },
                ].map((tool, index) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                    <CardHeader>
                      <div className="w-12 h-12 bg-gradient-to-r from-purple-100 to-blue-100 rounded-lg flex items-center justify-center mb-4">
                        <tool.icon className="w-6 h-6 text-purple-600" />
                      </div>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">{tool.title}</CardTitle>
                        {tool.badge && (
                          <Badge variant={tool.badge === "NEW" ? "default" : "secondary"} className="text-xs">
                            {tool.badge}
                          </Badge>
                        )}
                      </div>
                      <CardDescription>{tool.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button
                        asChild={tool.badge !== "COMING SOON"}
                        disabled={tool.badge === "COMING SOON"}
                        className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white"
                      >
                        {tool.badge === "COMING SOON" ? (
                          <span>Coming Soon</span>
                        ) : (
                          <Link href={tool.href}>Launch Tool</Link>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </AppLayout>
    </AuthGuard>
  )
}
