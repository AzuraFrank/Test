# NABILA Distribution - Music & Marketplace Platform

Platform terlengkap untuk distribusi musik, manajemen royalti, dan marketplace internasional dengan AI-powered tools dan GoPay integration.

## 🚀 Features

### 🎵 Music Distribution
- Distribusi ke 150+ platform streaming worldwide
- Spotify, Apple Music, YouTube Music, Amazon Music, dll
- Automatic metadata management
- Real-time distribution status tracking

### 💰 Royalty Management
- Transparent royalty tracking
- Automated payment processing
- Multi-currency support
- Real-time earnings dashboard

### 🤖 AI-Powered Tools
- Smart analytics dan insights
- Proposal generator
- Revenue optimizer
- Legal contract assistant
- Customer support chatbot

### 💳 GoPay Integration
- Real-time balance monitoring
- Automatic transaction sync
- Smart alerts system
- Admin dashboard untuk monitoring

### 🏪 International Marketplace
- Global marketplace untuk merchandise
- Integrated payment processing
- Multi-language support
- Commission tracking

### 📊 Advanced Analytics
- Streaming analytics
- Geographic insights
- Demographic data
- Performance trends
- Revenue breakdown

### ⚖️ Legal Protection
- AI Legal Assistant
- Contract management
- Entity registration
- Compliance monitoring

## 🛠️ Tech Stack

- **Frontend**: Next.js 14, React 18, TypeScript
- **Backend**: Next.js API Routes, Supabase
- **Database**: PostgreSQL (Supabase)
- **Authentication**: Supabase Auth
- **Styling**: Tailwind CSS, shadcn/ui
- **Payment**: GoPay/Midtrans Integration
- **Real-time**: Supabase Realtime

## 📦 Installation

1. **Clone repository**
\`\`\`bash
git clone https://github.com/your-username/nabila-distribution.git
cd nabila-distribution
\`\`\`

2. **Install dependencies**
\`\`\`bash
npm install
\`\`\`

3. **Setup environment variables**
\`\`\`bash
cp .env.example .env.local
\`\`\`

Edit `.env.local` dengan konfigurasi Anda:
\`\`\`env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key
\`\`\`

4. **Setup database**
- Buat project baru di [Supabase](https://supabase.com)
- Jalankan SQL scripts di folder `scripts/` secara berurutan
- Enable Row Level Security (RLS)

5. **Run development server**
\`\`\`bash
npm run dev
\`\`\`

Buka [http://localhost:3000](http://localhost:3000) di browser.

## 🗄️ Database Setup

Jalankan SQL scripts dalam urutan berikut:

1. `scripts/01-create-tables.sql` - Core tables
2. `scripts/02-enable-rls.sql` - Row Level Security
3. `scripts/03-create-functions.sql` - Database functions
4. `scripts/04-seed-data.sql` - Sample data
5. `scripts/05-team-management.sql` - Team management
6. `scripts/06-team-rls-policies.sql` - Team RLS policies
7. `scripts/07-seed-team-data.sql` - Team sample data
8. `scripts/08-streaming-partners.sql` - Streaming partners
9. `scripts/09-seed-streaming-partners.sql` - Partner data
10. `scripts/10-legal-contracts.sql` - Legal system
11. `scripts/11-legal-entity-registration.sql` - Entity registration
12. `scripts/12-seed-registration-data.sql` - Registration data
13. `scripts/13-international-affiliations.sql` - International affiliations
14. `scripts/14-payment-processing.sql` - Payment system
15. `scripts/15-complete-system-data.sql` - Complete system data
16. `scripts/16-gopay-monitoring.sql` - GoPay monitoring

## 💳 GoPay Configuration

GoPay sudah dikonfigurasi dengan kredensial berikut:
- **User ID**: G082083595
- **Phone**: 0895340205302
- **Client Key**: Mid-client-Xv_CpPRaXK_R-dj0
- **Server Key**: Mid-server-Gbr3kjXtYY88uEdxlD6LdazR

### GoPay Features:
- ✅ Real-time balance monitoring
- ✅ Automatic transaction sync
- ✅ Smart alerts (low balance, failed transactions)
- ✅ Admin dashboard (`/admin/gopay`)
- ✅ Live updates setiap 30 detik

## 🚀 Deployment

### Vercel (Recommended)

1. **Push ke GitHub**
\`\`\`bash
git add .
git commit -m "Initial commit"
git push origin main
\`\`\`

2. **Deploy ke Vercel**
- Import project dari GitHub di [Vercel](https://vercel.com)
- Add environment variables
- Deploy

3. **Setup domain dan SSL**
- Configure custom domain
- SSL otomatis enabled

### Manual Deployment

1. **Build project**
\`\`\`bash
npm run build
\`\`\`

2. **Start production server**
\`\`\`bash
npm start
\`\`\`

## 📱 API Endpoints

### Authentication
- `POST /api/auth/callback` - Auth callback
- `GET /api/auth/user` - Get current user

### Music Management
- `GET /api/tracks` - Get user tracks
- `POST /api/tracks` - Create new track
- `PUT /api/tracks/[id]` - Update track
- `DELETE /api/tracks/[id]` - Delete track

### Analytics
- `GET /api/analytics` - Get analytics data
- `GET /api/analytics/[trackId]` - Get track analytics

### GoPay Integration
- `GET /api/gopay/sync` - Get GoPay status
- `POST /api/gopay/sync` - Manual sync GoPay data

### AI Assistant
- `POST /api/ai/chat` - Chat with AI assistant

## 🔧 Configuration

### Supabase Setup
1. Create new project di Supabase
2. Copy project URL dan anon key
3. Setup database dengan SQL scripts
4. Configure RLS policies

### GoPay Setup
GoPay sudah dikonfigurasi dan siap digunakan. Untuk monitoring:
- Dashboard: `/admin/gopay`
- Auto-sync: Setiap 30 detik
- Manual sync: Button "Sync Now"

## 🎯 Key Features Implemented

### ✅ Authentication System
- Supabase Auth integration
- User registration/login
- Profile management
- Role-based access

### ✅ Music Distribution
- Track upload dan management
- Platform distribution tracking
- Metadata management
- Status monitoring

### ✅ Royalty Management
- Payment tracking
- Revenue analytics
- Multi-currency support
- Automated calculations

### ✅ GoPay Integration
- Real-time balance monitoring
- Transaction history
- Smart alerts
- Admin dashboard

### ✅ AI Assistant
- Natural language processing
- Context-aware responses
- Multi-domain support
- Suggestion system

### ✅ Analytics Dashboard
- Streaming analytics
- Revenue insights
- Geographic data
- Performance metrics

### ✅ Legal System
- Contract management
- Entity registration
- Compliance tracking
- Document generation

## 🔒 Security

- Row Level Security (RLS) enabled
- JWT-based authentication
- API rate limiting
- Input validation
- CORS configuration
- Environment variable protection

## 📊 Monitoring

### GoPay Monitoring
- Real-time balance tracking
- Transaction monitoring
- Alert system
- Performance metrics
- API status monitoring

### Application Monitoring
- Error tracking
- Performance monitoring
- User analytics
- System health checks

## 🤝 Contributing

1. Fork repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Create Pull Request

## 📄 License

Copyright © 2024 NABILA Collective Music Organization. All rights reserved.

## 🆘 Support

- Email: support@nabila-distribution.com
- Documentation: [docs.nabila-distribution.com](https://docs.nabila-distribution.com)
- Status: [status.nabila-distribution.com](https://status.nabila-distribution.com)

---

**NABILA Distribution** - Platform distribusi musik dan marketplace internasional terdepan dengan AI-powered tools dan real-time payment monitoring.
