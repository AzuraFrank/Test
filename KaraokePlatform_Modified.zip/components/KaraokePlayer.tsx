"use client";

import { useState, useEffect, useRef } from "react";
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Mic,
  Settings,
  Maximize,
  Minimize,
} from "lucide-react";

interface KaraokePlayerProps {
  song: {
    id: string;
    title: string;
    artist: string;
    duration: number;
    video_url?: string | null;
  };
  onClose: () => void;
}

export default function KaraokePlayer({ song, onClose }: KaraokePlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showLyrics, setShowLyrics] = useState(true);
  const [micVolume, setMicVolume] = useState(0.5);
  const playerRef = useRef<HTMLDivElement>(null);

  // Sample lyrics for demonstration
  const lyrics = [
    { time: 0, text: "♪ Instrumental ♪" },
    { time: 10, text: `Welcome to ${song.title}` },
    { time: 15, text: `by ${song.artist}` },
    { time: 20, text: "🎤 Start singing along! 🎤" },
    { time: 30, text: "Verse 1:" },
    { time: 35, text: "This is where the first verse would be..." },
    { time: 45, text: "Beautiful lyrics flowing with the melody..." },
    { time: 55, text: "Chorus:" },
    { time: 60, text: "The chorus is the most memorable part..." },
    { time: 70, text: "Everyone sings along here..." },
    { time: 80, text: "Verse 2:" },
    { time: 85, text: "Second verse with more story..." },
    { time: 95, text: "Building up to the final chorus..." },
    { time: 105, text: "Final Chorus:" },
    { time: 110, text: "The grand finale everyone waits for..." },
    { time: 120, text: "♪ Outro ♪" },
  ];

  const getCurrentLyric = () => {
    const currentLyric = lyrics
      .filter((lyric) => lyric.time <= currentTime)
      .pop();
    return currentLyric?.text || "";
  };

  const getUpcomingLyric = () => {
    const upcomingLyric = lyrics.find((lyric) => lyric.time > currentTime);
    return upcomingLyric?.text || "";
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const toggleFullscreen = () => {
    if (!isFullscreen) {
      playerRef.current?.requestFullscreen?.();
    } else {
      document.exitFullscreen?.();
    }
    setIsFullscreen(!isFullscreen);
  };

  // Simulate audio progress
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= song.duration) {
            setIsPlaying(false);
            return song.duration;
          }
          return prev + 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, song.duration]);

  const progress = (currentTime / song.duration) * 100;

  return (
    <>
      <div
        className={`karaoke-player ${isFullscreen ? "fullscreen" : ""}`}
        ref={playerRef}
      >
        <div className="player-header">
          <div className="song-info">
            <h2 className="song-title">{song.title}</h2>
            <p className="song-artist">{song.artist}</p>
          </div>
          <div className="player-controls-top">
            <button onClick={toggleFullscreen} className="control-btn">
              {isFullscreen ? <Minimize /> : <Maximize />}
            </button>
            <button onClick={onClose} className="control-btn close-btn">
              ×
            </button>
          </div>
        </div>

        <div className="video-container">
          <div className="video-placeholder">
            <div className="video-bg">🎵</div>
            {showLyrics && (
              <div className="lyrics-overlay">
                <div className="current-lyric">{getCurrentLyric()}</div>
                <div className="upcoming-lyric">{getUpcomingLyric()}</div>
              </div>
            )}
          </div>
        </div>

        <div className="progress-container">
          <span className="time-display">{formatTime(currentTime)}</span>
          <div className="progress-bar">
            <div
              className="progress-fill"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
          <span className="time-display">{formatTime(song.duration)}</span>
        </div>

        <div className="player-controls">
          <div className="main-controls">
            <button
              className="control-btn"
              onClick={() => setCurrentTime(Math.max(0, currentTime - 10))}
            >
              <SkipBack />
            </button>
            <button className="play-pause-btn" onClick={togglePlayPause}>
              {isPlaying ? <Pause /> : <Play />}
            </button>
            <button
              className="control-btn"
              onClick={() =>
                setCurrentTime(Math.min(song.duration, currentTime + 10))
              }
            >
              <SkipForward />
            </button>
          </div>

          <div className="volume-controls">
            <button
              className="control-btn"
              onClick={() => setIsMuted(!isMuted)}
            >
              {isMuted ? <VolumeX /> : <Volume2 />}
            </button>
            <input
              type="range"
              min="0"
              max="1"
              step="0.1"
              value={isMuted ? 0 : volume}
              onChange={(e) => setVolume(parseFloat(e.target.value))}
              className="volume-slider"
            />
          </div>

          <div className="mic-controls">
            <Mic className="mic-icon" />
            <input
              type="range"
              min="0"
              max="1"
              step="0.1"
              value={micVolume}
              onChange={(e) => setMicVolume(parseFloat(e.target.value))}
              className="mic-slider"
            />
          </div>

          <div className="settings-controls">
            <button
              className="control-btn"
              onClick={() => setShowLyrics(!showLyrics)}
            >
              <Settings />
            </button>
          </div>
        </div>
      </div>

      <style jsx>{`
        .karaoke-player {
          position: fixed;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          width: 90vw;
          max-width: 800px;
          height: 70vh;
          background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
          border-radius: 16px;
          color: white;
          display: flex;
          flex-direction: column;
          z-index: 1000;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
          overflow: hidden;
        }

        .karaoke-player.fullscreen {
          width: 100vw;
          height: 100vh;
          border-radius: 0;
          top: 0;
          left: 0;
          transform: none;
        }

        .player-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1rem 1.5rem;
          background: rgba(0, 0, 0, 0.2);
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .song-info {
          flex: 1;
        }

        .song-title {
          font-size: 1.5rem;
          font-weight: bold;
          margin: 0;
          margin-bottom: 0.25rem;
        }

        .song-artist {
          margin: 0;
          opacity: 0.8;
          font-size: 1rem;
        }

        .player-controls-top {
          display: flex;
          gap: 0.5rem;
        }

        .video-container {
          flex: 1;
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .video-placeholder {
          width: 100%;
          height: 100%;
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(
            45deg,
            rgba(255, 255, 255, 0.1) 0%,
            rgba(255, 255, 255, 0.05) 100%
          );
        }

        .video-bg {
          font-size: 8rem;
          opacity: 0.3;
          position: absolute;
        }

        .lyrics-overlay {
          position: absolute;
          bottom: 2rem;
          left: 50%;
          transform: translateX(-50%);
          text-align: center;
          width: 90%;
        }

        .current-lyric {
          font-size: 2rem;
          font-weight: bold;
          margin-bottom: 1rem;
          text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
          background: linear-gradient(45deg, #ff6b6b, #ffd93d);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .upcoming-lyric {
          font-size: 1.2rem;
          opacity: 0.7;
          text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
        }

        .progress-container {
          display: flex;
          align-items: center;
          gap: 1rem;
          padding: 1rem 1.5rem;
          background: rgba(0, 0, 0, 0.2);
        }

        .time-display {
          font-family: monospace;
          font-size: 0.9rem;
          min-width: 40px;
        }

        .progress-bar {
          flex: 1;
          height: 6px;
          background: rgba(255, 255, 255, 0.2);
          border-radius: 3px;
          overflow: hidden;
          cursor: pointer;
        }

        .progress-fill {
          height: 100%;
          background: linear-gradient(90deg, #ff6b6b, #ffd93d);
          transition: width 0.1s ease;
        }

        .player-controls {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 1rem 1.5rem;
          background: rgba(0, 0, 0, 0.3);
          gap: 1rem;
        }

        .main-controls {
          display: flex;
          align-items: center;
          gap: 1rem;
        }

        .control-btn {
          background: rgba(255, 255, 255, 0.1);
          border: none;
          color: white;
          padding: 0.75rem;
          border-radius: 50%;
          cursor: pointer;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .control-btn:hover {
          background: rgba(255, 255, 255, 0.2);
          transform: scale(1.1);
        }

        .close-btn {
          font-size: 1.5rem;
          font-weight: bold;
        }

        .play-pause-btn {
          background: linear-gradient(45deg, #ff6b6b, #ffd93d);
          border: none;
          color: white;
          padding: 1rem;
          border-radius: 50%;
          cursor: pointer;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.2rem;
        }

        .play-pause-btn:hover {
          transform: scale(1.1);
          box-shadow: 0 0 20px rgba(255, 107, 107, 0.5);
        }

        .volume-controls,
        .mic-controls {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .mic-icon {
          color: #ff6b6b;
        }

        .volume-slider,
        .mic-slider {
          width: 80px;
          -webkit-appearance: none;
          appearance: none;
          height: 4px;
          background: rgba(255, 255, 255, 0.2);
          border-radius: 2px;
          outline: none;
        }

        .volume-slider::-webkit-slider-thumb,
        .mic-slider::-webkit-slider-thumb {
          -webkit-appearance: none;
          appearance: none;
          width: 16px;
          height: 16px;
          background: #ffd93d;
          border-radius: 50%;
          cursor: pointer;
        }

        .settings-controls {
          display: flex;
          align-items: center;
        }

        @media (max-width: 768px) {
          .karaoke-player {
            width: 95vw;
            height: 80vh;
          }

          .player-controls {
            flex-direction: column;
            gap: 1rem;
          }

          .main-controls {
            order: 1;
          }

          .volume-controls,
          .mic-controls {
            order: 2;
          }

          .current-lyric {
            font-size: 1.5rem;
          }

          .upcoming-lyric {
            font-size: 1rem;
          }
        }
      `}</style>
    </>
  );
}
