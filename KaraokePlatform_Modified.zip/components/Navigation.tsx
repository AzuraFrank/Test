"use client";

import { useAuth } from "@/contexts/AuthContext";
import Link from "next/link";
import { Music, ShoppingBag, User, LogOut, Shield } from "lucide-react";

export default function Navigation() {
  const { user, profile, signInWithGoogle, signOut } = useAuth();

  return (
    <nav className="navigation">
      <div className="nav-container">
        <Link href="/" className="nav-logo">
          <Music className="nav-icon" />
          Azura Karaoke Streaming
        </Link>

        <div className="nav-links">
          <Link href="/gallery" className="nav-link">
            <Music className="nav-icon" />
            Song Gallery
          </Link>
          <Link href="/shop" className="nav-link">
            <ShoppingBag className="nav-icon" />
            Shop
          </Link>

          {user ? (
            <>
              <Link href="/profile" className="nav-link">
                <User className="nav-icon" />
                Profile
              </Link>
              {profile?.role === "admin" && (
                <Link href="/admin" className="nav-link admin-link">
                  <Shield className="nav-icon" />
                  Admin
                </Link>
              )}
              <button onClick={signOut} className="nav-link nav-button">
                <LogOut className="nav-icon" />
                Sign Out
              </button>
            </>
          ) : (
            <button onClick={signInWithGoogle} className="nav-link nav-button">
              <User className="nav-icon" />
              Sign In with Google
            </button>
          )}
        </div>
      </div>

      <style jsx>{`
        .navigation {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          padding: 1rem 0;
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .nav-container {
          max-width: 1200px;
          margin: 0 auto;
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 0 1rem;
        }

        .nav-logo {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          color: white;
          text-decoration: none;
          font-size: 1.5rem;
          font-weight: bold;
        }

        .nav-links {
          display: flex;
          align-items: center;
          gap: 1rem;
        }

        .nav-link {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          color: white;
          text-decoration: none;
          padding: 0.5rem 1rem;
          border-radius: 8px;
          transition: background-color 0.2s;
        }

        .nav-link:hover {
          background-color: rgba(255, 255, 255, 0.1);
        }

        .nav-button {
          background: none;
          border: none;
          cursor: pointer;
          font-size: inherit;
        }

        .admin-link {
          background-color: rgba(255, 215, 0, 0.2);
        }

        .nav-icon {
          width: 18px;
          height: 18px;
        }

        @media (max-width: 768px) {
          .nav-container {
            flex-direction: column;
            gap: 1rem;
          }

          .nav-links {
            flex-wrap: wrap;
            justify-content: center;
          }
        }
      `}</style>
    </nav>
  );
}
