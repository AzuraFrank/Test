"use client";

import { useState, useEffect, useRef } from "react";
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Mic,
  X,
  Maximize,
  Minimize,
} from "lucide-react";

interface EnhancedKaraokePlayerProps {
  song: {
    id: string;
    title: string;
    artist: string;
    duration: number;
  };
  onClose: () => void;
}

export default function EnhancedKaraokePlayer({
  song,
  onClose,
}: EnhancedKaraokePlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [micVolume, setMicVolume] = useState(0.5);
  const audioContextRef = useRef<AudioContext | null>(null);
  const oscillatorRef = useRef<OscillatorNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  // Enhanced lyrics with timing
  const lyrics = [
    { time: 0, text: "🎵 Music starts...", type: "intro" },
    { time: 5, text: `Welcome to ${song.title}`, type: "info" },
    { time: 8, text: `Performed by ${song.artist}`, type: "info" },
    { time: 12, text: "🎤 Get ready to sing! 🎤", type: "cue" },
    { time: 18, text: "[Verse 1]", type: "section" },
    { time: 20, text: "Beautiful melody flows through the air", type: "lyric" },
    {
      time: 25,
      text: "Every note tells a story of love and care",
      type: "lyric",
    },
    { time: 30, text: "Singing along with all your heart", type: "lyric" },
    { time: 35, text: "This is where the magic starts", type: "lyric" },
    { time: 40, text: "[Chorus]", type: "section" },
    { time: 42, text: "🎵 This is the chorus everyone knows", type: "lyric" },
    { time: 47, text: "🎵 Sing it loud and let it show", type: "lyric" },
    { time: 52, text: "🎵 Feel the rhythm, feel the beat", type: "lyric" },
    { time: 57, text: "🎵 Make this moment so complete", type: "lyric" },
    { time: 62, text: "[Verse 2]", type: "section" },
    { time: 64, text: "Dreams and hopes fill up the night", type: "lyric" },
    { time: 69, text: "Everything feels just right", type: "lyric" },
    { time: 74, text: "Music brings us all together", type: "lyric" },
    { time: 79, text: "Making memories that last forever", type: "lyric" },
    { time: 84, text: "[Final Chorus]", type: "section" },
    {
      time: 86,
      text: "🎵 This is the moment we've been waiting for",
      type: "lyric",
    },
    { time: 91, text: "🎵 Sing it like never before", type: "lyric" },
    { time: 96, text: "🎵 Let your voice reach the sky", type: "lyric" },
    { time: 101, text: "🎵 This feeling will never die", type: "lyric" },
    { time: 106, text: "[Outro]", type: "section" },
    { time: 108, text: "🎵 Thank you for singing along", type: "outro" },
    { time: 112, text: "🎵 Until we meet again in song", type: "outro" },
    { time: 116, text: "🎵 Music lives on...", type: "outro" },
  ];

  const getCurrentLyric = () => {
    const currentLyric = lyrics
      .filter((lyric) => lyric.time <= currentTime)
      .pop();
    return currentLyric || { text: "🎵 Get ready...", type: "intro" };
  };

  const getUpcomingLyric = () => {
    const upcomingLyric = lyrics.find((lyric) => lyric.time > currentTime);
    return upcomingLyric?.text || "";
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  // Create audio context and generate sound
  const initAudio = () => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext ||
        (window as any).webkitAudioContext)();
      gainNodeRef.current = audioContextRef.current.createGain();
      gainNodeRef.current.connect(audioContextRef.current.destination);
    }
  };

  const playBeep = (frequency: number, duration: number) => {
    if (!audioContextRef.current || !gainNodeRef.current) return;

    const oscillator = audioContextRef.current.createOscillator();
    const envelope = audioContextRef.current.createGain();

    oscillator.connect(envelope);
    envelope.connect(gainNodeRef.current);

    oscillator.frequency.value = frequency;
    oscillator.type = "sine";

    envelope.gain.setValueAtTime(0, audioContextRef.current.currentTime);
    envelope.gain.linearRampToValueAtTime(
      volume * 0.1,
      audioContextRef.current.currentTime + 0.01,
    );
    envelope.gain.exponentialRampToValueAtTime(
      0.001,
      audioContextRef.current.currentTime + duration,
    );

    oscillator.start(audioContextRef.current.currentTime);
    oscillator.stop(audioContextRef.current.currentTime + duration);
  };

  const togglePlayPause = () => {
    initAudio();

    if (!isPlaying) {
      // Play a pleasant chord progression
      playBeep(261.63, 0.5); // C4
      setTimeout(() => playBeep(329.63, 0.5), 200); // E4
      setTimeout(() => playBeep(392.0, 0.5), 400); // G4
    } else {
      // Stop sound
      if (oscillatorRef.current) {
        oscillatorRef.current.stop();
        oscillatorRef.current = null;
      }
    }

    setIsPlaying(!isPlaying);
  };

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  // Generate background music simulation
  useEffect(() => {
    let interval: NodeJS.Timeout;
    let musicInterval: NodeJS.Timeout;

    if (isPlaying) {
      // Progress timer
      interval = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= song.duration) {
            setIsPlaying(false);
            return song.duration;
          }
          return prev + 1;
        });
      }, 1000);

      // Background music simulation
      musicInterval = setInterval(() => {
        if (!isMuted && audioContextRef.current) {
          const frequencies = [
            261.63, 293.66, 329.63, 349.23, 392.0, 440.0, 493.88,
          ];
          const randomFreq =
            frequencies[Math.floor(Math.random() * frequencies.length)];
          playBeep(randomFreq, 0.3);
        }
      }, 2000);
    }

    return () => {
      clearInterval(interval);
      clearInterval(musicInterval);
    };
  }, [isPlaying, isMuted, volume]);

  const progress = (currentTime / song.duration) * 100;

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const newTime = (clickX / rect.width) * song.duration;
    setCurrentTime(Math.max(0, Math.min(song.duration, newTime)));
  };

  const currentLyric = getCurrentLyric();
  const upcomingLyric = getUpcomingLyric();

  return (
    <>
      <div className="karaoke-overlay" onClick={onClose}>
        <div
          className={`karaoke-player ${isFullscreen ? "fullscreen" : ""}`}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="player-header">
            <div className="song-info">
              <h2>{song.title}</h2>
              <p>{song.artist}</p>
            </div>
            <div className="header-controls">
              <button onClick={toggleFullscreen} className="control-btn">
                {isFullscreen ? <Minimize /> : <Maximize />}
              </button>
              <button onClick={onClose} className="control-btn close-btn">
                <X />
              </button>
            </div>
          </div>

          {/* Lyrics Display */}
          <div className="lyrics-container">
            <div className="background-animation"></div>
            <div className="lyrics-content">
              <div className={`current-lyric ${currentLyric.type}`}>
                {currentLyric.text}
              </div>
              {upcomingLyric && (
                <div className="upcoming-lyric">{upcomingLyric}</div>
              )}
            </div>
            <div className="beat-visualizer">
              {[...Array(20)].map((_, i) => (
                <div
                  key={i}
                  className={`beat-bar ${isPlaying ? "animate" : ""}`}
                  style={{ animationDelay: `${i * 0.1}s` }}
                />
              ))}
            </div>
          </div>

          {/* Progress */}
          <div className="progress-section">
            <span className="time-display">{formatTime(currentTime)}</span>
            <div className="progress-container" onClick={handleProgressClick}>
              <div className="progress-track">
                <div
                  className="progress-fill"
                  style={{ width: `${progress}%` }}
                />
                <div
                  className="progress-thumb"
                  style={{ left: `${progress}%` }}
                />
              </div>
            </div>
            <span className="time-display">{formatTime(song.duration)}</span>
          </div>

          {/* Controls */}
          <div className="controls-section">
            <div className="main-controls">
              <button
                onClick={() => setCurrentTime(Math.max(0, currentTime - 10))}
                className="control-btn"
              >
                <SkipBack />
              </button>
              <button onClick={togglePlayPause} className="play-btn">
                {isPlaying ? <Pause /> : <Play />}
              </button>
              <button
                onClick={() =>
                  setCurrentTime(Math.min(song.duration, currentTime + 10))
                }
                className="control-btn"
              >
                <SkipForward />
              </button>
            </div>

            <div className="volume-controls">
              <button
                onClick={() => setIsMuted(!isMuted)}
                className="control-btn"
              >
                {isMuted ? <VolumeX /> : <Volume2 />}
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={isMuted ? 0 : volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="volume-slider"
              />
            </div>

            <div className="mic-controls">
              <Mic className="mic-icon" />
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={micVolume}
                onChange={(e) => setMicVolume(parseFloat(e.target.value))}
                className="mic-slider"
              />
              <span className="mic-label">Mic</span>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .karaoke-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(
            135deg,
            rgba(0, 0, 0, 0.9) 0%,
            rgba(30, 60, 114, 0.95) 100%
          );
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 10000;
          backdrop-filter: blur(10px);
        }

        .karaoke-player {
          width: 95vw;
          max-width: 900px;
          height: 80vh;
          background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
          border-radius: 20px;
          color: white;
          display: flex;
          flex-direction: column;
          overflow: hidden;
          box-shadow: 0 25px 50px rgba(0, 0, 0, 0.5);
          border: 2px solid rgba(255, 255, 255, 0.1);
        }

        .karaoke-player.fullscreen {
          width: 100vw;
          height: 100vh;
          border-radius: 0;
        }

        .player-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1.5rem 2rem;
          background: rgba(0, 0, 0, 0.3);
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .song-info h2 {
          font-size: 1.8rem;
          font-weight: bold;
          margin: 0 0 0.5rem 0;
          text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }

        .song-info p {
          margin: 0;
          opacity: 0.9;
          font-size: 1.1rem;
        }

        .header-controls {
          display: flex;
          gap: 1rem;
        }

        .control-btn {
          background: rgba(255, 255, 255, 0.15);
          border: none;
          color: white;
          padding: 0.75rem;
          border-radius: 50%;
          cursor: pointer;
          transition: all 0.3s;
          display: flex;
          align-items: center;
          justify-content: center;
          backdrop-filter: blur(10px);
        }

        .control-btn:hover {
          background: rgba(255, 255, 255, 0.25);
          transform: scale(1.1);
        }

        .close-btn {
          background: rgba(255, 107, 107, 0.8);
        }

        .close-btn:hover {
          background: rgba(255, 107, 107, 1);
        }

        .lyrics-container {
          flex: 1;
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;
        }

        .background-animation {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(
            45deg,
            rgba(255, 107, 107, 0.1) 0%,
            rgba(255, 215, 0, 0.1) 25%,
            rgba(67, 56, 202, 0.1) 50%,
            rgba(16, 185, 129, 0.1) 75%,
            rgba(255, 107, 107, 0.1) 100%
          );
          background-size: 400% 400%;
          animation: gradientShift 8s ease infinite;
        }

        @keyframes gradientShift {
          0% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
          100% {
            background-position: 0% 50%;
          }
        }

        .lyrics-content {
          position: relative;
          text-align: center;
          z-index: 2;
          max-width: 80%;
        }

        .current-lyric {
          font-size: 2.5rem;
          font-weight: bold;
          margin-bottom: 2rem;
          text-shadow: 3px 3px 6px rgba(0, 0, 0, 0.7);
          animation: fadeInUp 0.5s ease;
          line-height: 1.2;
        }

        .current-lyric.intro,
        .current-lyric.outro {
          color: #ffd700;
          font-style: italic;
        }

        .current-lyric.section {
          color: #ff6b6b;
          font-size: 2rem;
          text-transform: uppercase;
          letter-spacing: 0.1em;
        }

        .current-lyric.lyric {
          background: linear-gradient(45deg, #ffd700, #ff6b6b, #67e8f9);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          background-size: 200% 200%;
          animation: textGradient 3s ease infinite;
        }

        .current-lyric.cue {
          color: #4ade80;
          animation: pulse 2s ease infinite;
        }

        @keyframes textGradient {
          0% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
          100% {
            background-position: 0% 50%;
          }
        }

        @keyframes pulse {
          0%,
          100% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.05);
          }
        }

        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .upcoming-lyric {
          font-size: 1.2rem;
          opacity: 0.6;
          font-style: italic;
          text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
        }

        .beat-visualizer {
          position: absolute;
          bottom: 2rem;
          left: 50%;
          transform: translateX(-50%);
          display: flex;
          gap: 0.25rem;
          z-index: 1;
        }

        .beat-bar {
          width: 4px;
          height: 20px;
          background: linear-gradient(to top, #ffd700, #ff6b6b);
          border-radius: 2px;
          transform-origin: bottom;
        }

        .beat-bar.animate {
          animation: beatPulse 1s ease infinite;
        }

        @keyframes beatPulse {
          0%,
          100% {
            transform: scaleY(0.3);
            opacity: 0.5;
          }
          50% {
            transform: scaleY(1);
            opacity: 1;
          }
        }

        .progress-section {
          display: flex;
          align-items: center;
          gap: 1rem;
          padding: 1rem 2rem;
          background: rgba(0, 0, 0, 0.2);
        }

        .time-display {
          font-family: monospace;
          font-size: 1rem;
          font-weight: bold;
          min-width: 45px;
          text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
        }

        .progress-container {
          flex: 1;
          cursor: pointer;
          padding: 0.5rem 0;
        }

        .progress-track {
          position: relative;
          height: 8px;
          background: rgba(255, 255, 255, 0.2);
          border-radius: 4px;
          overflow: visible;
        }

        .progress-fill {
          height: 100%;
          background: linear-gradient(90deg, #ff6b6b, #ffd700, #4ade80);
          border-radius: 4px;
          transition: width 0.1s ease;
        }

        .progress-thumb {
          position: absolute;
          top: 50%;
          width: 16px;
          height: 16px;
          background: white;
          border-radius: 50%;
          transform: translate(-50%, -50%);
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
          transition: left 0.1s ease;
        }

        .controls-section {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1.5rem 2rem;
          background: rgba(0, 0, 0, 0.3);
          border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .main-controls {
          display: flex;
          align-items: center;
          gap: 1rem;
        }

        .play-btn {
          width: 70px;
          height: 70px;
          background: linear-gradient(45deg, #ff6b6b, #ffd700);
          border: none;
          color: white;
          border-radius: 50%;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.5rem;
          transition: all 0.3s;
          box-shadow: 0 4px 15px rgba(255, 107, 107, 0.4);
        }

        .play-btn:hover {
          transform: scale(1.1);
          box-shadow: 0 6px 20px rgba(255, 107, 107, 0.6);
        }

        .volume-controls,
        .mic-controls {
          display: flex;
          align-items: center;
          gap: 0.75rem;
        }

        .volume-slider,
        .mic-slider {
          width: 100px;
          -webkit-appearance: none;
          appearance: none;
          height: 6px;
          background: rgba(255, 255, 255, 0.3);
          border-radius: 3px;
          outline: none;
        }

        .volume-slider::-webkit-slider-thumb,
        .mic-slider::-webkit-slider-thumb {
          -webkit-appearance: none;
          appearance: none;
          width: 18px;
          height: 18px;
          background: linear-gradient(45deg, #ffd700, #ff6b6b);
          border-radius: 50%;
          cursor: pointer;
          box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
        }

        .mic-icon {
          color: #ff6b6b;
        }

        .mic-label {
          font-size: 0.9rem;
          opacity: 0.8;
        }

        @media (max-width: 768px) {
          .karaoke-player {
            width: 100vw;
            height: 100vh;
            border-radius: 0;
          }

          .current-lyric {
            font-size: 1.8rem;
          }

          .controls-section {
            flex-direction: column;
            gap: 1rem;
          }

          .main-controls {
            order: 1;
          }

          .volume-controls,
          .mic-controls {
            order: 2;
          }
        }
      `}</style>
    </>
  );
}
