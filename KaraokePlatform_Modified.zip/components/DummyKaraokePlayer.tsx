
'use client';
import React, { useRef, useState } from 'react';

export default function DummyKaraokePlayer() {
  const audioRef = useRef(null);
  const [playing, setPlaying] = useState(false);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (playing) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setPlaying(!playing);
  };

  return (
    <div className="p-6 max-w-2xl mx-auto bg-white rounded-xl shadow-md flex flex-col items-center space-y-4">
      <h1 className="text-2xl font-bold text-center">🎤 Karaoke Demo Player</h1>
      <audio ref={audioRef} src="https://example.com/karaoke-dummy.mp3" controls className="w-full mt-4" />
      <button
        onClick={togglePlay}
        className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded"
      >
        {playing ? '⏸️ Pause' : '▶️ Play'}
      </button>
      <p className="text-gray-600 mt-4 text-center">🎶 Lagu: Dummy Karaoke Bebas Lisensi</p>
    </div>
  );
}
