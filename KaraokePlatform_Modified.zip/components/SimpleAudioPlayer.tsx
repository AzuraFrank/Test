"use client";

import { useState, useEffect } from "react";
import { Play, Pause, SkipBack, SkipForward, Volume2, X } from "lucide-react";

interface SimpleAudioPlayerProps {
  song: {
    id: string;
    title: string;
    artist: string;
    duration: number;
  };
  onClose: () => void;
}

export default function SimpleAudioPlayer({
  song,
  onClose,
}: SimpleAudioPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(0.7);

  // Sample lyrics for demonstration
  const lyrics = [
    { time: 0, text: "🎵 Instrumental intro..." },
    { time: 5, text: `Selamat datang di ${song.title}` },
    { time: 10, text: `Dibawakan oleh ${song.artist}` },
    { time: 15, text: "🎤 Mulai bernyanyi! 🎤" },
    { time: 20, text: "Bait pertama:" },
    { time: 25, text: "Lirik lagu akan muncul di sini..." },
    { time: 35, text: "Ikuti melodi dan tempo..." },
    { time: 45, text: "Reff:" },
    { time: 50, text: "Bagian reff yang mudah diingat..." },
    { time: 60, text: "Semua orang bisa ikut bernyanyi..." },
    { time: 70, text: "Bait kedua:" },
    { time: 75, text: "Lanjutkan dengan penuh semangat..." },
    { time: 85, text: "Menuju klimaks lagu..." },
    { time: 95, text: "Reff akhir:" },
    { time: 100, text: "Finale yang memukau..." },
    { time: 110, text: "🎵 Outro 🎵" },
  ];

  const getCurrentLyric = () => {
    const currentLyric = lyrics
      .filter((lyric) => lyric.time <= currentTime)
      .pop();
    return currentLyric?.text || "🎵 Musik dimulai...";
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  // Simulate audio progress
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= song.duration) {
            setIsPlaying(false);
            return song.duration;
          }
          return prev + 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, song.duration]);

  const progress = (currentTime / song.duration) * 100;

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const newTime = (clickX / rect.width) * song.duration;
    setCurrentTime(Math.max(0, Math.min(song.duration, newTime)));
  };

  return (
    <>
      <div className="audio-player-overlay" onClick={onClose}>
        <div className="audio-player" onClick={(e) => e.stopPropagation()}>
          {/* Header */}
          <div className="player-header">
            <div className="song-info">
              <h3>{song.title}</h3>
              <p>{song.artist}</p>
            </div>
            <button onClick={onClose} className="close-btn">
              <X />
            </button>
          </div>

          {/* Lyrics Display */}
          <div className="lyrics-display">
            <div className="current-lyric">{getCurrentLyric()}</div>
          </div>

          {/* Progress Bar */}
          <div className="progress-section">
            <span className="time-label">{formatTime(currentTime)}</span>
            <div className="progress-bar" onClick={handleProgressClick}>
              <div
                className="progress-fill"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            <span className="time-label">{formatTime(song.duration)}</span>
          </div>

          {/* Controls */}
          <div className="controls">
            <button
              onClick={() => setCurrentTime(Math.max(0, currentTime - 10))}
              className="control-btn"
            >
              <SkipBack />
            </button>

            <button onClick={togglePlayPause} className="play-btn">
              {isPlaying ? <Pause /> : <Play />}
            </button>

            <button
              onClick={() =>
                setCurrentTime(Math.min(song.duration, currentTime + 10))
              }
              className="control-btn"
            >
              <SkipForward />
            </button>
          </div>

          {/* Volume */}
          <div className="volume-section">
            <Volume2 className="volume-icon" />
            <input
              type="range"
              min="0"
              max="1"
              step="0.1"
              value={volume}
              onChange={(e) => setVolume(parseFloat(e.target.value))}
              className="volume-slider"
            />
          </div>
        </div>
      </div>

      <style jsx>{`
        .audio-player-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.8);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
        }

        .audio-player {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          padding: 2rem;
          border-radius: 20px;
          width: 90%;
          max-width: 500px;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
        }

        .player-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 2rem;
        }

        .song-info h3 {
          margin: 0 0 0.5rem 0;
          font-size: 1.5rem;
        }

        .song-info p {
          margin: 0;
          opacity: 0.8;
        }

        .close-btn {
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          padding: 0.5rem;
          border-radius: 50%;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .close-btn:hover {
          background: rgba(255, 255, 255, 0.3);
        }

        .lyrics-display {
          background: rgba(255, 255, 255, 0.1);
          padding: 2rem;
          border-radius: 15px;
          text-align: center;
          margin-bottom: 2rem;
          min-height: 80px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .current-lyric {
          font-size: 1.3rem;
          font-weight: 500;
          text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }

        .progress-section {
          display: flex;
          align-items: center;
          gap: 1rem;
          margin-bottom: 2rem;
        }

        .time-label {
          font-family: monospace;
          font-size: 0.9rem;
          min-width: 40px;
        }

        .progress-bar {
          flex: 1;
          height: 8px;
          background: rgba(255, 255, 255, 0.3);
          border-radius: 4px;
          cursor: pointer;
          position: relative;
        }

        .progress-fill {
          height: 100%;
          background: linear-gradient(90deg, #ff6b6b, #ffd93d);
          border-radius: 4px;
          transition: width 0.1s ease;
        }

        .controls {
          display: flex;
          justify-content: center;
          align-items: center;
          gap: 1rem;
          margin-bottom: 2rem;
        }

        .control-btn {
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          padding: 0.75rem;
          border-radius: 50%;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }

        .control-btn:hover {
          background: rgba(255, 255, 255, 0.3);
          transform: scale(1.1);
        }

        .play-btn {
          background: linear-gradient(45deg, #ff6b6b, #ffd93d);
          border: none;
          color: white;
          padding: 1rem;
          border-radius: 50%;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.2rem;
          transition: all 0.2s;
        }

        .play-btn:hover {
          transform: scale(1.1);
          box-shadow: 0 0 20px rgba(255, 107, 107, 0.5);
        }

        .volume-section {
          display: flex;
          align-items: center;
          gap: 1rem;
          justify-content: center;
        }

        .volume-icon {
          width: 20px;
          height: 20px;
        }

        .volume-slider {
          width: 100px;
          -webkit-appearance: none;
          appearance: none;
          height: 4px;
          background: rgba(255, 255, 255, 0.3);
          border-radius: 2px;
          outline: none;
        }

        .volume-slider::-webkit-slider-thumb {
          -webkit-appearance: none;
          appearance: none;
          width: 16px;
          height: 16px;
          background: #ffd93d;
          border-radius: 50%;
          cursor: pointer;
        }

        @media (max-width: 768px) {
          .audio-player {
            width: 95%;
            padding: 1.5rem;
          }

          .current-lyric {
            font-size: 1.1rem;
          }

          .controls {
            gap: 0.5rem;
          }
        }
      `}</style>
    </>
  );
}
