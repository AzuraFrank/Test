"use client";

import { useState, useEffect } from "react";
import { CheckCircle, X, Info, AlertCircle } from "lucide-react";

interface ToastProps {
  message: string;
  type: "success" | "error" | "info";
  onClose: () => void;
  duration?: number;
}

export default function Toast({
  message,
  type,
  onClose,
  duration = 3000,
}: ToastProps) {
  useEffect(() => {
    const timer = setTimeout(onClose, duration);
    return () => clearTimeout(timer);
  }, [onClose, duration]);

  const getIcon = () => {
    switch (type) {
      case "success":
        return <CheckCircle className="toast-icon" />;
      case "error":
        return <AlertCircle className="toast-icon" />;
      case "info":
      default:
        return <Info className="toast-icon" />;
    }
  };

  return (
    <>
      <div className={`toast toast-${type}`}>
        {getIcon()}
        <span className="toast-message">{message}</span>
        <button onClick={onClose} className="toast-close">
          <X className="close-icon" />
        </button>
      </div>

      <style jsx>{`
        .toast {
          position: fixed;
          top: 2rem;
          right: 2rem;
          background: white;
          padding: 1rem 1.5rem;
          border-radius: 12px;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
          display: flex;
          align-items: center;
          gap: 1rem;
          z-index: 10000;
          min-width: 300px;
          border-left: 4px solid;
          animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
          from {
            transform: translateX(100%);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }

        .toast-success {
          border-left-color: #4ecdc4;
        }

        .toast-success .toast-icon {
          color: #4ecdc4;
        }

        .toast-error {
          border-left-color: #ff6b6b;
        }

        .toast-error .toast-icon {
          color: #ff6b6b;
        }

        .toast-info {
          border-left-color: #667eea;
        }

        .toast-info .toast-icon {
          color: #667eea;
        }

        .toast-icon {
          width: 20px;
          height: 20px;
          flex-shrink: 0;
        }

        .toast-message {
          flex: 1;
          color: #333;
          font-weight: 500;
        }

        .toast-close {
          background: none;
          border: none;
          cursor: pointer;
          padding: 0.25rem;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: background-color 0.2s;
        }

        .toast-close:hover {
          background: #f0f0f0;
        }

        .close-icon {
          width: 16px;
          height: 16px;
          color: #666;
        }

        @media (max-width: 768px) {
          .toast {
            top: 1rem;
            right: 1rem;
            left: 1rem;
            min-width: auto;
          }
        }
      `}</style>
    </>
  );
}
