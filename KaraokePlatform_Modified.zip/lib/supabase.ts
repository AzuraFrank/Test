import { createClient } from "@supabase/supabase-js";

const supabaseUrl = "https://vgchzuqtrmohyzojvngw.supabase.co";
const supabaseAnonKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZnY2h6dXF0cm1vaHl6b2p2bmd3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTEyNzE1NzAsImV4cCI6MjA2Njg0NzU3MH0.WKcSXto5EXcS1fdScAKf6atW7tcXM9AB9jObapii_2g";

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string | null;
          avatar_url: string | null;
          role: "user" | "admin";
          created_at: string;
        };
        Insert: {
          id: string;
          email: string;
          full_name?: string | null;
          avatar_url?: string | null;
          role?: "user" | "admin";
          created_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          full_name?: string | null;
          avatar_url?: string | null;
          role?: "user" | "admin";
          created_at?: string;
        };
      };
      songs: {
        Row: {
          id: string;
          title: string;
          artist: string;
          duration: number;
          thumbnail_url: string | null;
          video_url: string | null;
          category: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          title: string;
          artist: string;
          duration: number;
          thumbnail_url?: string | null;
          video_url?: string | null;
          category: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          title?: string;
          artist?: string;
          duration?: number;
          thumbnail_url?: string | null;
          video_url?: string | null;
          category?: string;
          created_at?: string;
        };
      };
      shop_items: {
        Row: {
          id: string;
          name: string;
          description: string;
          price: number;
          image_url: string | null;
          category: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          description: string;
          price: number;
          image_url?: string | null;
          category: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          description?: string;
          price?: number;
          image_url?: string | null;
          category?: string;
          created_at?: string;
        };
      };
      orders: {
        Row: {
          id: string;
          user_id: string;
          item_id: string;
          quantity: number;
          total_amount: number;
          payment_proof: string | null;
          status: "pending" | "confirmed" | "delivered";
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          item_id: string;
          quantity: number;
          total_amount: number;
          payment_proof?: string | null;
          status?: "pending" | "confirmed" | "delivered";
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          item_id?: string;
          quantity?: number;
          total_amount?: number;
          payment_proof?: string | null;
          status?: "pending" | "confirmed" | "delivered";
          created_at?: string;
        };
      };
    };
  };
};
