"use client";

import { useAuth } from "@/contexts/AuthContext";
import Link from "next/link";
import {
  Music,
  ShoppingBag,
  Star,
  Mic,
  Play,
  Users,
  Sparkles,
  Headphones,
} from "lucide-react";

export default function Home() {
  const { user } = useAuth();

  return (
    <>
      <main className="homepage">
        {/* Hero Section */}
        <div className="hero-section">
          <div className="hero-background">
            <div className="gradient-orb orb-1"></div>
            <div className="gradient-orb orb-2"></div>
            <div className="gradient-orb orb-3"></div>
          </div>
          <div className="hero-content">
            <div className="hero-badge">
              <Sparkles className="badge-icon" />
              <span>Platform #1 Indonesia</span>
            </div>
            <h1 className="hero-title">
              <span className="title-main">Azura Karaoke</span>
              <span className="title-sub">Streaming</span>
            </h1>
            <p className="hero-subtitle">
              Platform karaoke streaming premium by{" "}
              <strong>Nabila Ahmad Studio Development</strong> dengan 50,000+
              lagu berkualitas tinggi, teknologi AI terdepan, dan pengalaman
              karaoke yang tak terlupakan
            </p>

            <div className="hero-stats">
              <div className="stat-item">
                <div className="stat-number">50K+</div>
                <div className="stat-label">Lagu Premium</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">100K+</div>
                <div className="stat-label">Pengguna Aktif</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">4.9⭐</div>
                <div className="stat-label">Rating</div>
              </div>
            </div>

            <div className="hero-buttons">
              <Link href="/gallery" className="cta-button primary">
                <Play className="button-icon" />
                <span>Mulai Karaoke Gratis</span>
                <div className="button-shine"></div>
              </Link>
              <Link href="/shop" className="cta-button secondary">
                <ShoppingBag className="button-icon" />
                <span>Lihat Premium Tools</span>
              </Link>
            </div>
          </div>
        </div>

        {/* Trending Songs */}
        <div className="trending-section">
          <div className="container">
            <h2 className="section-title">
              <Music className="title-icon" />
              Trending This Week
            </h2>
            <div className="trending-grid">
              {[
                {
                  rank: 1,
                  title: "Perfect",
                  artist: "Ed Sheeran",
                  plays: "2.1M",
                },
                {
                  rank: 2,
                  title: "Shallow",
                  artist: "Lady Gaga & Bradley Cooper",
                  plays: "1.8M",
                },
                {
                  rank: 3,
                  title: "Separuh Aku",
                  artist: "Noah",
                  plays: "1.5M",
                },
                { rank: 4, title: "Dynamite", artist: "BTS", plays: "1.2M" },
              ].map((song) => (
                <div key={song.rank} className="trending-item">
                  <div className="trending-rank">#{song.rank}</div>
                  <div className="trending-info">
                    <h4>{song.title}</h4>
                    <p>{song.artist}</p>
                  </div>
                  <div className="trending-plays">{song.plays} plays</div>
                  <button className="trending-play">
                    <Play className="play-icon" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Features Section */}
        <div className="features-section">
          <div className="container">
            <h2 className="section-title">
              <Star className="title-icon" />
              Fitur Premium Terbaru
            </h2>
            <div className="features-grid">
              <div className="feature-card">
                <div className="feature-icon ai">🤖</div>
                <h3>AI Vocal Coach</h3>
                <p>
                  Teknologi AI yang membantu meningkatkan teknik bernyanyi
                  dengan feedback real-time dan analisis suara
                </p>
                <div className="feature-badge new">NEW</div>
              </div>
              <div className="feature-card">
                <div className="feature-icon tools">🎛️</div>
                <h3>Professional Tools</h3>
                <p>
                  Peralatan karaoke grade studio mulai dari Rp.5.000 - 200.000
                  dengan kualitas terjamin
                </p>
                <div className="feature-badge premium">PREMIUM</div>
              </div>
              <div className="feature-card">
                <div className="feature-icon quality">💎</div>
                <h3>Studio Quality</h3>
                <p>
                  Audio 48kHz/24bit dan video 4K untuk pengalaman karaoke
                  seperti di studio profesional
                </p>
                <div className="feature-badge pro">PRO</div>
              </div>
              <div className="feature-card">
                <div className="feature-icon live">🎤</div>
                <h3>Live Collaboration</h3>
                <p>
                  Duet virtual dengan teman dari jarak jauh menggunakan
                  teknologi low-latency terdepan
                </p>
                <div className="feature-badge beta">BETA</div>
              </div>
            </div>
          </div>
        </div>

        {/* Testimonials */}
        <div className="testimonials-section">
          <div className="container">
            <h2 className="section-title">
              <Users className="title-icon" />
              Kata Mereka
            </h2>
            <div className="testimonials-grid">
              {[
                {
                  name: "Sarah M.",
                  role: "Penyanyi Amateur",
                  text: "Platform karaoke terbaik yang pernah saya coba! Kualitas suara jernih dan koleksi lagu sangat lengkap. AI Vocal Coach-nya membantu banget!",
                  rating: 5,
                  avatar: "🎤",
                },
                {
                  name: "Budi K.",
                  role: "Vocal Coach",
                  text: "Teknologi yang digunakan sangat canggih. Fitur real-time feedback membantu murid-murid saya improve dengan cepat. Recommended!",
                  rating: 5,
                  avatar: "🎵",
                },
                {
                  name: "Lisa T.",
                  role: "Content Creator",
                  text: "Tools yang dijual berkualitas tinggi dan harga terjangkau. Customer service responsif dan helpful. Perfect untuk content creation!",
                  rating: 5,
                  avatar: "✨",
                },
              ].map((testimonial, index) => (
                <div key={index} className="testimonial-card">
                  <div className="testimonial-header">
                    <div className="testimonial-avatar">
                      {testimonial.avatar}
                    </div>
                    <div className="testimonial-info">
                      <h4>{testimonial.name}</h4>
                      <p>{testimonial.role}</p>
                    </div>
                    <div className="testimonial-rating">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="star-icon filled" />
                      ))}
                    </div>
                  </div>
                  <p className="testimonial-text">"{testimonial.text}"</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Payment Info */}
        <div className="payment-section">
          <div className="container">
            <h2 className="section-title">
              <ShoppingBag className="title-icon" />
              Sistem Pembayaran Terpercaya
            </h2>
            <div className="payment-content">
              <div className="payment-card">
                <div className="payment-header">
                  <h3>💳 Gopay Premium</h3>
                  <div className="secure-badge">🔒 Secure</div>
                </div>
                <div className="payment-number">0895340205302</div>
                <p>Transfer cepat & aman dengan konfirmasi otomatis</p>
                <div className="payment-features">
                  <div className="feature">✅ Konfirmasi Instan</div>
                  <div className="feature">✅ Support 24/7</div>
                  <div className="feature">✅ Garansi Uang Kembali</div>
                </div>
              </div>
              <div className="payment-steps">
                <h4>Cara Pembayaran:</h4>
                <div className="steps-grid">
                  <div className="step">
                    <div className="step-number">1</div>
                    <p>Pilih produk favorit</p>
                  </div>
                  <div className="step">
                    <div className="step-number">2</div>
                    <p>Transfer ke Gopay</p>
                  </div>
                  <div className="step">
                    <div className="step-number">3</div>
                    <p>Upload bukti bayar</p>
                  </div>
                  <div className="step">
                    <div className="step-number">4</div>
                    <p>Konfirmasi instan</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="footer-section">
          <div className="container">
            <div className="footer-content">
              <div className="footer-brand">
                <h3>💫 Azura Karaoke Streaming</h3>
                <p>
                  Proudly developed by{" "}
                  <strong>Nabila Ahmad Studio Development</strong>
                </p>
                <p>Premium streaming karaoke experience for everyone</p>
              </div>
              <div className="footer-links">
                <Link href="/gallery">Song Gallery</Link>
                <Link href="/shop">Premium Shop</Link>
                <Link href="/profile">Profile</Link>
              </div>
            </div>
          </div>
        </div>
      </main>

      <style jsx>{`
        .homepage {
          min-height: 100vh;
        }

        .hero-section {
          position: relative;
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(
            135deg,
            #667eea 0%,
            #764ba2 50%,
            #667eea 100%
          );
          overflow: hidden;
        }

        .hero-background {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          z-index: 1;
        }

        .gradient-orb {
          position: absolute;
          border-radius: 50%;
          background: linear-gradient(
            45deg,
            rgba(255, 255, 255, 0.1),
            rgba(255, 215, 0, 0.2)
          );
          animation: float 6s ease-in-out infinite;
          backdrop-filter: blur(40px);
        }

        .orb-1 {
          width: 300px;
          height: 300px;
          top: 10%;
          left: 10%;
          animation-delay: 0s;
        }

        .orb-2 {
          width: 200px;
          height: 200px;
          top: 60%;
          right: 10%;
          animation-delay: 2s;
        }

        .orb-3 {
          width: 150px;
          height: 150px;
          bottom: 20%;
          left: 60%;
          animation-delay: 4s;
        }

        @keyframes float {
          0%,
          100% {
            transform: translateY(0px) rotate(0deg);
          }
          33% {
            transform: translateY(-20px) rotate(120deg);
          }
          66% {
            transform: translateY(10px) rotate(240deg);
          }
        }

        .hero-content {
          position: relative;
          z-index: 2;
          text-align: center;
          color: white;
          max-width: 900px;
          padding: 2rem;
        }

        .hero-badge {
          display: inline-flex;
          align-items: center;
          gap: 0.5rem;
          background: rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(10px);
          padding: 0.5rem 1rem;
          border-radius: 50px;
          margin-bottom: 2rem;
          border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .badge-icon {
          width: 16px;
          height: 16px;
          color: #ffd700;
        }

        .hero-title {
          margin-bottom: 2rem;
        }

        .title-main {
          display: block;
          font-size: 4rem;
          font-weight: 900;
          background: linear-gradient(
            45deg,
            #ffd700,
            #ff6b6b,
            #4ade80,
            #60a5fa
          );
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          text-shadow: 0 0 50px rgba(255, 255, 255, 0.5);
          margin-bottom: 0.5rem;
        }

        .title-sub {
          display: block;
          font-size: 2.5rem;
          font-weight: 300;
          opacity: 0.9;
        }

        .hero-subtitle {
          font-size: 1.3rem;
          line-height: 1.8;
          margin-bottom: 3rem;
          opacity: 0.95;
          max-width: 800px;
          margin-left: auto;
          margin-right: auto;
        }

        .hero-stats {
          display: flex;
          justify-content: center;
          gap: 4rem;
          margin-bottom: 3rem;
          flex-wrap: wrap;
        }

        .stat-item {
          text-align: center;
        }

        .stat-number {
          font-size: 3rem;
          font-weight: bold;
          color: #ffd700;
          text-shadow: 0 0 20px rgba(255, 215, 0, 0.5);
          margin-bottom: 0.5rem;
        }

        .stat-label {
          font-size: 1rem;
          opacity: 0.8;
        }

        .hero-buttons {
          display: flex;
          gap: 1.5rem;
          justify-content: center;
          flex-wrap: wrap;
        }

        .cta-button {
          position: relative;
          display: flex;
          align-items: center;
          gap: 0.75rem;
          padding: 1.25rem 2.5rem;
          border-radius: 15px;
          text-decoration: none;
          font-weight: 600;
          font-size: 1.1rem;
          transition: all 0.3s;
          overflow: hidden;
          border: 2px solid transparent;
        }

        .cta-button.primary {
          background: linear-gradient(45deg, #ff6b6b, #ffd700);
          color: white;
          box-shadow: 0 10px 30px rgba(255, 107, 107, 0.4);
        }

        .cta-button.primary:hover {
          transform: translateY(-3px);
          box-shadow: 0 15px 40px rgba(255, 107, 107, 0.6);
        }

        .cta-button.secondary {
          background: rgba(255, 255, 255, 0.15);
          color: white;
          backdrop-filter: blur(10px);
          border-color: rgba(255, 255, 255, 0.3);
        }

        .cta-button.secondary:hover {
          background: rgba(255, 255, 255, 0.25);
          transform: translateY(-3px);
        }

        .button-icon {
          width: 20px;
          height: 20px;
        }

        .button-shine {
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(
            90deg,
            transparent,
            rgba(255, 255, 255, 0.3),
            transparent
          );
          animation: shine 3s infinite;
        }

        @keyframes shine {
          0% {
            left: -100%;
          }
          100% {
            left: 100%;
          }
        }

        .trending-section {
          padding: 5rem 1rem;
          background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
          color: white;
        }

        .container {
          max-width: 1200px;
          margin: 0 auto;
        }

        .section-title {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 1rem;
          font-size: 2.5rem;
          font-weight: bold;
          margin-bottom: 3rem;
          text-align: center;
        }

        .title-icon {
          width: 2.5rem;
          height: 2.5rem;
        }

        .trending-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 1.5rem;
        }

        .trending-item {
          background: rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(10px);
          padding: 1.5rem;
          border-radius: 20px;
          display: flex;
          align-items: center;
          gap: 1rem;
          border: 1px solid rgba(255, 255, 255, 0.2);
          transition: all 0.3s;
        }

        .trending-item:hover {
          transform: translateY(-5px);
          background: rgba(255, 255, 255, 0.25);
        }

        .trending-rank {
          font-size: 2rem;
          font-weight: bold;
          color: #ffd700;
          min-width: 60px;
          text-shadow: 0 0 10px rgba(255, 215, 0, 0.5);
        }

        .trending-info {
          flex: 1;
        }

        .trending-info h4 {
          margin: 0 0 0.25rem 0;
          font-size: 1.1rem;
        }

        .trending-info p {
          margin: 0;
          opacity: 0.8;
          font-size: 0.95rem;
        }

        .trending-plays {
          font-size: 0.9rem;
          opacity: 0.8;
          margin-right: 1rem;
        }

        .trending-play {
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          padding: 0.75rem;
          border-radius: 50%;
          cursor: pointer;
          transition: all 0.3s;
        }

        .trending-play:hover {
          background: rgba(255, 255, 255, 0.3);
          transform: scale(1.1);
        }

        .play-icon {
          width: 16px;
          height: 16px;
        }

        .features-section {
          padding: 5rem 1rem;
          background: #f8f9fa;
        }

        .features-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 2rem;
        }

        .feature-card {
          background: white;
          padding: 2.5rem;
          border-radius: 25px;
          text-align: center;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
          transition: all 0.3s;
          position: relative;
          border: 2px solid transparent;
          overflow: hidden;
        }

        .feature-card:hover {
          transform: translateY(-10px);
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
          border-color: #667eea;
        }

        .feature-icon {
          font-size: 4rem;
          margin-bottom: 1.5rem;
          border-radius: 20px;
          width: 80px;
          height: 80px;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-left: auto;
          margin-right: auto;
        }

        .feature-icon.ai {
          background: linear-gradient(45deg, #667eea, #764ba2);
        }

        .feature-icon.tools {
          background: linear-gradient(45deg, #ff6b6b, #ffd93d);
        }

        .feature-icon.quality {
          background: linear-gradient(45deg, #4ecdc4, #44a08d);
        }

        .feature-icon.live {
          background: linear-gradient(45deg, #f093fb, #f5576c);
        }

        .feature-card h3 {
          font-size: 1.5rem;
          margin-bottom: 1rem;
          color: #333;
        }

        .feature-card p {
          color: #666;
          line-height: 1.6;
          margin-bottom: 1.5rem;
        }

        .feature-badge {
          position: absolute;
          top: 1rem;
          right: 1rem;
          padding: 0.25rem 0.75rem;
          border-radius: 50px;
          font-size: 0.8rem;
          font-weight: bold;
          text-transform: uppercase;
        }

        .feature-badge.new {
          background: linear-gradient(45deg, #4ade80, #22c55e);
          color: white;
        }

        .feature-badge.premium {
          background: linear-gradient(45deg, #ffd700, #f59e0b);
          color: #333;
        }

        .feature-badge.pro {
          background: linear-gradient(45deg, #8b5cf6, #a855f7);
          color: white;
        }

        .feature-badge.beta {
          background: linear-gradient(45deg, #06b6d4, #0891b2);
          color: white;
        }

        .testimonials-section {
          padding: 5rem 1rem;
          background: #2c3e50;
          color: white;
        }

        .testimonials-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
          gap: 2rem;
        }

        .testimonial-card {
          background: rgba(255, 255, 255, 0.1);
          backdrop-filter: blur(10px);
          padding: 2rem;
          border-radius: 20px;
          border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .testimonial-header {
          display: flex;
          align-items: center;
          gap: 1rem;
          margin-bottom: 1.5rem;
        }

        .testimonial-avatar {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          background: linear-gradient(45deg, #667eea, #764ba2);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 1.5rem;
        }

        .testimonial-info {
          flex: 1;
        }

        .testimonial-info h4 {
          margin: 0 0 0.25rem 0;
          font-size: 1.1rem;
        }

        .testimonial-info p {
          margin: 0;
          opacity: 0.8;
          font-size: 0.9rem;
        }

        .testimonial-rating {
          display: flex;
          gap: 0.25rem;
        }

        .star-icon {
          width: 16px;
          height: 16px;
          color: #ffd700;
        }

        .testimonial-text {
          font-style: italic;
          line-height: 1.6;
          margin: 0;
        }

        .payment-section {
          padding: 5rem 1rem;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
        }

        .payment-content {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 3rem;
          max-width: 1000px;
          margin: 0 auto;
        }

        .payment-card {
          background: rgba(255, 255, 255, 0.15);
          backdrop-filter: blur(10px);
          padding: 2.5rem;
          border-radius: 25px;
          border: 2px solid rgba(255, 215, 0, 0.3);
          box-shadow: 0 0 40px rgba(255, 215, 0, 0.2);
        }

        .payment-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1.5rem;
        }

        .secure-badge {
          background: rgba(34, 197, 94, 0.8);
          padding: 0.25rem 0.75rem;
          border-radius: 20px;
          font-size: 0.8rem;
        }

        .payment-number {
          font-size: 2rem;
          font-weight: bold;
          color: #ffd700;
          font-family: monospace;
          text-shadow: 0 0 20px rgba(255, 215, 0, 0.5);
          margin-bottom: 1rem;
        }

        .payment-features {
          margin-top: 1.5rem;
        }

        .payment-features .feature {
          margin: 0.75rem 0;
          font-size: 0.95rem;
        }

        .payment-steps h4 {
          margin-bottom: 2rem;
          color: #ffd700;
          font-size: 1.3rem;
        }

        .steps-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 1.5rem;
        }

        .step {
          display: flex;
          align-items: center;
          gap: 1rem;
        }

        .step-number {
          width: 40px;
          height: 40px;
          background: linear-gradient(45deg, #ffd700, #f59e0b);
          color: #333;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: bold;
          font-size: 1.2rem;
        }

        .step p {
          margin: 0;
          font-weight: 500;
        }

        .footer-section {
          padding: 3rem 1rem;
          background: #1a202c;
          color: white;
        }

        .footer-content {
          display: flex;
          justify-content: space-between;
          align-items: center;
          max-width: 1000px;
          margin: 0 auto;
        }

        .footer-brand h3 {
          font-size: 1.8rem;
          margin-bottom: 1rem;
          background: linear-gradient(45deg, #667eea, #764ba2);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .footer-brand p {
          margin: 0.5rem 0;
          opacity: 0.8;
        }

        .footer-brand strong {
          color: #ffd700;
        }

        .footer-links {
          display: flex;
          gap: 2rem;
        }

        .footer-links a {
          color: white;
          text-decoration: none;
          transition: color 0.3s;
        }

        .footer-links a:hover {
          color: #ffd700;
        }

        @media (max-width: 768px) {
          .title-main {
            font-size: 2.5rem;
          }

          .title-sub {
            font-size: 1.8rem;
          }

          .hero-stats {
            gap: 2rem;
          }

          .stat-number {
            font-size: 2rem;
          }

          .hero-buttons {
            flex-direction: column;
            align-items: center;
          }

          .cta-button {
            width: 100%;
            max-width: 300px;
            justify-content: center;
          }

          .payment-content {
            grid-template-columns: 1fr;
            gap: 2rem;
          }

          .steps-grid {
            grid-template-columns: 1fr;
          }

          .footer-content {
            flex-direction: column;
            gap: 2rem;
            text-align: center;
          }

          .footer-links {
            flex-direction: column;
            gap: 1rem;
          }
        }
      `}</style>
    </>
  );
}
