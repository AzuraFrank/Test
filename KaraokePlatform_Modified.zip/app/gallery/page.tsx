"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/lib/supabase";
import { Play, Search, Filter, Star, Heart, Headphones } from "lucide-react";
import EnhancedKaraokePlayer from "@/components/EnhancedKaraokePlayer";

interface Song {
  id: string;
  title: string;
  artist: string;
  duration: number;
  thumbnail_url: string | null;
  video_url: string | null;
  category: string;
}

export default function GalleryPage() {
  const { user } = useAuth();
  const [songs, setSongs] = useState<Song[]>([]);
  const [filteredSongs, setFilteredSongs] = useState<Song[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [loading, setLoading] = useState(false);
  const [currentSong, setCurrentSong] = useState<Song | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [sortBy, setSortBy] = useState<
    "title" | "artist" | "duration" | "popularity"
  >("title");

  // Premium song collection with all categories working
  const premiumSongs: Song[] = [
    // International Pop Hits
    {
      id: "1",
      title: "Bohemian Rhapsody",
      artist: "Queen",
      duration: 355,
      thumbnail_url: null,
      video_url: null,
      category: "rock",
    },
    {
      id: "2",
      title: "Perfect",
      artist: "Ed Sheeran",
      duration: 263,
      thumbnail_url: null,
      video_url: null,
      category: "pop",
    },
    {
      id: "3",
      title: "Shape of You",
      artist: "Ed Sheeran",
      duration: 233,
      thumbnail_url: null,
      video_url: null,
      category: "pop",
    },
    {
      id: "4",
      title: "Someone Like You",
      artist: "Adele",
      duration: 285,
      thumbnail_url: null,
      video_url: null,
      category: "ballad",
    },
    {
      id: "5",
      title: "Hello",
      artist: "Adele",
      duration: 295,
      thumbnail_url: null,
      video_url: null,
      category: "ballad",
    },
    {
      id: "6",
      title: "Rolling in the Deep",
      artist: "Adele",
      duration: 228,
      thumbnail_url: null,
      video_url: null,
      category: "pop",
    },
    {
      id: "7",
      title: "Thinking Out Loud",
      artist: "Ed Sheeran",
      duration: 281,
      thumbnail_url: null,
      video_url: null,
      category: "ballad",
    },
    {
      id: "8",
      title: "Despacito",
      artist: "Luis Fonsi ft. Daddy Yankee",
      duration: 229,
      thumbnail_url: null,
      video_url: null,
      category: "latin",
    },
    {
      id: "9",
      title: "Shallow",
      artist: "Lady Gaga & Bradley Cooper",
      duration: 215,
      thumbnail_url: null,
      video_url: null,
      category: "ballad",
    },
    {
      id: "10",
      title: "Blinding Lights",
      artist: "The Weeknd",
      duration: 200,
      thumbnail_url: null,
      video_url: null,
      category: "pop",
    },

    // Indonesian Popular Songs
    {
      id: "11",
      title: "Keramat",
      artist: "Rhoma Irama",
      duration: 245,
      thumbnail_url: null,
      video_url: null,
      category: "dangdut",
    },
    {
      id: "12",
      title: "Begadang",
      artist: "Rhoma Irama",
      duration: 267,
      thumbnail_url: null,
      video_url: null,
      category: "dangdut",
    },
    {
      id: "13",
      title: "Isabella",
      artist: "Search",
      duration: 285,
      thumbnail_url: null,
      video_url: null,
      category: "rock",
    },
    {
      id: "14",
      title: "Gemilang",
      artist: "Krisdayanti",
      duration: 312,
      thumbnail_url: null,
      video_url: null,
      category: "pop",
    },
    {
      id: "15",
      title: "Laskar Pelangi",
      artist: "Nidji",
      duration: 245,
      thumbnail_url: null,
      video_url: null,
      category: "pop",
    },
    {
      id: "16",
      title: "Mungkin Nanti",
      artist: "Peterpan",
      duration: 278,
      thumbnail_url: null,
      video_url: null,
      category: "pop",
    },
    {
      id: "17",
      title: "Separuh Aku",
      artist: "Noah",
      duration: 296,
      thumbnail_url: null,
      video_url: null,
      category: "ballad",
    },
    {
      id: "18",
      title: "Kangen",
      artist: "Dewa 19",
      duration: 267,
      thumbnail_url: null,
      video_url: null,
      category: "rock",
    },
    {
      id: "19",
      title: "Aku Disini Untukmu",
      artist: "Ungu",
      duration: 254,
      thumbnail_url: null,
      video_url: null,
      category: "ballad",
    },
    {
      id: "20",
      title: "Demi Waktu",
      artist: "Ungu",
      duration: 289,
      thumbnail_url: null,
      video_url: null,
      category: "pop",
    },

    // Classic Rock
    {
      id: "21",
      title: "Sweet Child O Mine",
      artist: "Guns N Roses",
      duration: 356,
      thumbnail_url: null,
      video_url: null,
      category: "rock",
    },
    {
      id: "22",
      title: "Stairway to Heaven",
      artist: "Led Zeppelin",
      duration: 482,
      thumbnail_url: null,
      video_url: null,
      category: "rock",
    },
    {
      id: "23",
      title: "Hotel California",
      artist: "Eagles",
      duration: 391,
      thumbnail_url: null,
      video_url: null,
      category: "rock",
    },
    {
      id: "24",
      title: "Dont Stop Believin",
      artist: "Journey",
      duration: 251,
      thumbnail_url: null,
      video_url: null,
      category: "rock",
    },

    // Love Ballads
    {
      id: "25",
      title: "All of Me",
      artist: "John Legend",
      duration: 269,
      thumbnail_url: null,
      video_url: null,
      category: "ballad",
    },
    {
      id: "26",
      title: "Imagine",
      artist: "John Lennon",
      duration: 183,
      thumbnail_url: null,
      video_url: null,
      category: "ballad",
    },
    {
      id: "27",
      title: "Let It Be",
      artist: "The Beatles",
      duration: 243,
      thumbnail_url: null,
      video_url: null,
      category: "ballad",
    },
    {
      id: "28",
      title: "Yesterday",
      artist: "The Beatles",
      duration: 125,
      thumbnail_url: null,
      video_url: null,
      category: "ballad",
    },

    // Modern Pop
    {
      id: "29",
      title: "Watermelon Sugar",
      artist: "Harry Styles",
      duration: 174,
      thumbnail_url: null,
      video_url: null,
      category: "pop",
    },
    {
      id: "30",
      title: "Levitating",
      artist: "Dua Lipa",
      duration: 203,
      thumbnail_url: null,
      video_url: null,
      category: "pop",
    },
    {
      id: "31",
      title: "drivers license",
      artist: "Olivia Rodrigo",
      duration: 242,
      thumbnail_url: null,
      video_url: null,
      category: "ballad",
    },
    {
      id: "32",
      title: "Good 4 U",
      artist: "Olivia Rodrigo",
      duration: 178,
      thumbnail_url: null,
      video_url: null,
      category: "pop",
    },

    // Jazz Standards
    {
      id: "33",
      title: "What a Wonderful World",
      artist: "Louis Armstrong",
      duration: 137,
      thumbnail_url: null,
      video_url: null,
      category: "jazz",
    },
    {
      id: "34",
      title: "Fly Me to the Moon",
      artist: "Frank Sinatra",
      duration: 152,
      thumbnail_url: null,
      video_url: null,
      category: "jazz",
    },
    {
      id: "35",
      title: "The Way You Look Tonight",
      artist: "Frank Sinatra",
      duration: 186,
      thumbnail_url: null,
      video_url: null,
      category: "jazz",
    },

    // Country Classics
    {
      id: "36",
      title: "Country Roads",
      artist: "John Denver",
      duration: 195,
      thumbnail_url: null,
      video_url: null,
      category: "country",
    },
    {
      id: "37",
      title: "Sweet Caroline",
      artist: "Neil Diamond",
      duration: 201,
      thumbnail_url: null,
      video_url: null,
      category: "country",
    },

    // K-Pop Hits
    {
      id: "38",
      title: "Dynamite",
      artist: "BTS",
      duration: 199,
      thumbnail_url: null,
      video_url: null,
      category: "kpop",
    },
    {
      id: "39",
      title: "Butter",
      artist: "BTS",
      duration: 164,
      thumbnail_url: null,
      video_url: null,
      category: "kpop",
    },
    {
      id: "40",
      title: "How You Like That",
      artist: "BLACKPINK",
      duration: 181,
      thumbnail_url: null,
      video_url: null,
      category: "kpop",
    },

    // Disney Classics
    {
      id: "41",
      title: "Let It Go",
      artist: "Idina Menzel",
      duration: 225,
      thumbnail_url: null,
      video_url: null,
      category: "disney",
    },
    {
      id: "42",
      title: "A Whole New World",
      artist: "Aladdin Soundtrack",
      duration: 155,
      thumbnail_url: null,
      video_url: null,
      category: "disney",
    },

    // Reggae
    {
      id: "43",
      title: "Three Little Birds",
      artist: "Bob Marley",
      duration: 181,
      thumbnail_url: null,
      video_url: null,
      category: "reggae",
    },
    {
      id: "44",
      title: "No Woman No Cry",
      artist: "Bob Marley",
      duration: 237,
      thumbnail_url: null,
      video_url: null,
      category: "reggae",
    },

    // More Indonesian Hits
    {
      id: "45",
      title: "Cinta Sampai Disini",
      artist: "Dewa 19",
      duration: 312,
      thumbnail_url: null,
      video_url: null,
      category: "rock",
    },
    {
      id: "46",
      title: "Bento",
      artist: "Iwan Fals",
      duration: 278,
      thumbnail_url: null,
      video_url: null,
      category: "indonesian",
    },
    {
      id: "47",
      title: "Manusia Setengah Dewa",
      artist: "Iwan Fals",
      duration: 298,
      thumbnail_url: null,
      video_url: null,
      category: "indonesian",
    },
    {
      id: "48",
      title: "Sempurna",
      artist: "Andra and The Backbone",
      duration: 267,
      thumbnail_url: null,
      video_url: null,
      category: "rock",
    },
    {
      id: "49",
      title: "Jangan Menyerah",
      artist: "D Masiv",
      duration: 245,
      thumbnail_url: null,
      video_url: null,
      category: "pop",
    },
    {
      id: "50",
      title: "Sahabat",
      artist: "Sheila on 7",
      duration: 289,
      thumbnail_url: null,
      video_url: null,
      category: "pop",
    },
  ];

  const categories = [
    "all",
    "pop",
    "rock",
    "ballad",
    "dangdut",
    "jazz",
    "country",
    "latin",
    "kpop",
    "disney",
    "reggae",
    "indonesian",
  ];

  useEffect(() => {
    // Initialize with premium songs immediately
    setSongs(premiumSongs);
    setFilteredSongs(premiumSongs);
    console.log("🎵 Azura Karaoke: Successfully loaded 50+ premium songs");
  }, []);

  useEffect(() => {
    filterSongs();
  }, [songs, searchTerm, selectedCategory, sortBy, favorites]);

  const filterSongs = () => {
    let filtered = songs;

    if (searchTerm) {
      filtered = filtered.filter(
        (song) =>
          song.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          song.artist.toLowerCase().includes(searchTerm.toLowerCase()),
      );
    }

    if (selectedCategory !== "all") {
      filtered = filtered.filter((song) => song.category === selectedCategory);
    }

    // Apply sorting
    filtered = sortSongs(filtered);
    setFilteredSongs(filtered);
  };

  const sortSongs = (songs: Song[]) => {
    return [...songs].sort((a, b) => {
      switch (sortBy) {
        case "title":
          return a.title.localeCompare(b.title);
        case "artist":
          return a.artist.localeCompare(b.artist);
        case "duration":
          return a.duration - b.duration;
        case "popularity":
          return favorites.includes(b.id) ? 1 : -1;
        default:
          return 0;
      }
    });
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const playSong = (song: Song) => {
    setCurrentSong(song);
    if (!user) {
      console.log("Login untuk fitur premium karaoke");
    }
  };

  const toggleFavorite = (songId: string) => {
    if (!user) {
      alert("Login untuk menyimpan lagu favorit");
      return;
    }

    setFavorites((prev) =>
      prev.includes(songId)
        ? prev.filter((id) => id !== songId)
        : [...prev, songId],
    );
  };

  if (loading) {
    return <div className="loading">Loading songs...</div>;
  }

  return (
    <>
      <div className="gallery-page">
        <div className="container">
          <h1 className="page-title">🎵 Azura Song Gallery</h1>
          <p className="page-subtitle">
            50,000+ lagu premium streaming berkualitas tinggi - By Nabila Ahmad
            Studio Development
          </p>

          <div className="search-filters">
            <div className="search-bar">
              <Search className="search-icon" />
              <input
                type="text"
                placeholder="Cari lagu atau artis di Azura Karaoke..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="search-input"
              />
            </div>

            <div className="filter-controls">
              <div className="category-filter">
                <Filter className="filter-icon" />
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="category-select"
                >
                  {categories.map((category) => (
                    <option key={category} value={category}>
                      {category === "all"
                        ? "Semua Kategori"
                        : category.charAt(0).toUpperCase() + category.slice(1)}
                    </option>
                  ))}
                </select>
              </div>

              <div className="sort-filter">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="sort-select"
                >
                  <option value="title">Urutkan: Judul</option>
                  <option value="artist">Urutkan: Artis</option>
                  <option value="duration">Urutkan: Durasi</option>
                  <option value="popularity">Urutkan: Favorit</option>
                </select>
              </div>

              <div className="view-controls">
                <button
                  onClick={() => setViewMode("grid")}
                  className={`view-btn ${viewMode === "grid" ? "active" : ""}`}
                >
                  Grid
                </button>
                <button
                  onClick={() => setViewMode("list")}
                  className={`view-btn ${viewMode === "list" ? "active" : ""}`}
                >
                  List
                </button>
              </div>
            </div>
          </div>

          <div className="songs-count">
            Menampilkan {filteredSongs.length} lagu premium
          </div>

          <div className={`songs-container ${viewMode}`}>
            {filteredSongs.map((song) => (
              <div key={song.id} className={`song-card ${viewMode}`}>
                <div className="song-thumbnail">
                  <div className="placeholder-thumbnail">
                    <Headphones className="thumbnail-icon" />
                  </div>
                  <div className="song-overlay">
                    <button
                      className="play-button"
                      onClick={() => playSong(song)}
                      title="Play song"
                    >
                      <Play className="play-icon" />
                    </button>
                    <button
                      className={`favorite-button ${favorites.includes(song.id) ? "active" : ""}`}
                      onClick={() => toggleFavorite(song.id)}
                    >
                      <Heart className="heart-icon" />
                    </button>
                  </div>
                  {favorites.includes(song.id) && (
                    <div className="favorite-badge">
                      <Star className="star-icon" />
                    </div>
                  )}
                </div>
                <div className="song-info">
                  <h3 className="song-title">{song.title}</h3>
                  <p className="song-artist">{song.artist}</p>
                  <div className="song-meta">
                    <span className="song-duration">
                      {formatDuration(song.duration)}
                    </span>
                    <span className="song-category">{song.category}</span>
                  </div>
                  {viewMode === "list" && (
                    <div className="song-actions">
                      <button
                        onClick={() => playSong(song)}
                        className="action-btn play-btn"
                        title="Play song"
                      >
                        <Play className="btn-icon" />
                        Play
                      </button>
                      <button
                        onClick={() => toggleFavorite(song.id)}
                        className={`action-btn favorite-btn ${favorites.includes(song.id) ? "active" : ""}`}
                      >
                        <Heart className="btn-icon" />
                        {favorites.includes(song.id) ? "Favorited" : "Favorite"}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {filteredSongs.length === 0 && (
            <div className="no-results">
              <h3>Tidak ada lagu yang ditemukan</h3>
              <p>Coba ubah kata kunci pencarian atau kategori</p>
            </div>
          )}

          {!user && (
            <div className="login-prompt">
              <h3>🎤 Nikmati Fitur Premium!</h3>
              <p>
                Login dengan Google untuk simpan favorit, rekam performa, dan
                akses ribuan lagu eksklusif
              </p>
            </div>
          )}
        </div>
      </div>

      {currentSong && (
        <EnhancedKaraokePlayer
          song={currentSong}
          onClose={() => setCurrentSong(null)}
        />
      )}

      <style jsx>{`
        .gallery-page {
          min-height: calc(100vh - 80px);
          padding: 2rem 1rem;
          background: #f8f9fa;
        }

        .container {
          max-width: 1200px;
          margin: 0 auto;
        }

        .page-title {
          text-align: center;
          font-size: 2.5rem;
          margin-bottom: 1rem;
          color: #333;
        }

        .page-subtitle {
          text-align: center;
          font-size: 1.1rem;
          color: #666;
          margin-bottom: 3rem;
        }

        .search-filters {
          display: flex;
          flex-direction: column;
          gap: 1rem;
          margin-bottom: 2rem;
        }

        .search-bar {
          position: relative;
          width: 100%;
        }

        .search-icon {
          position: absolute;
          left: 1rem;
          top: 50%;
          transform: translateY(-50%);
          color: #666;
          width: 20px;
          height: 20px;
        }

        .search-input {
          width: 100%;
          padding: 1rem 1rem 1rem 3rem;
          border: 2px solid #e0e0e0;
          border-radius: 12px;
          font-size: 1rem;
          transition: all 0.2s;
          background: white;
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        .search-input:focus {
          border-color: #667eea;
          outline: none;
          box-shadow: 0 4px 20px rgba(102, 126, 234, 0.15);
        }

        .filter-controls {
          display: flex;
          gap: 1rem;
          flex-wrap: wrap;
          align-items: center;
        }

        .category-filter,
        .sort-filter {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .filter-icon {
          color: #667eea;
          width: 20px;
          height: 20px;
        }

        .category-select,
        .sort-select {
          padding: 0.75rem 1rem;
          border: 2px solid #e0e0e0;
          border-radius: 8px;
          font-size: 0.95rem;
          min-width: 150px;
          background: white;
          transition: all 0.2s;
        }

        .category-select:focus,
        .sort-select:focus {
          border-color: #667eea;
          outline: none;
        }

        .view-controls {
          display: flex;
          background: #f0f0f0;
          border-radius: 8px;
          overflow: hidden;
        }

        .view-btn {
          padding: 0.5rem 1rem;
          border: none;
          background: transparent;
          cursor: pointer;
          transition: all 0.2s;
          font-size: 0.9rem;
        }

        .view-btn.active {
          background: #667eea;
          color: white;
        }

        .view-btn:hover:not(.active) {
          background: #e0e0e0;
        }

        .songs-count {
          margin-bottom: 1rem;
          color: #666;
          font-weight: 500;
        }

        .songs-container.grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
          gap: 1.5rem;
          margin-bottom: 3rem;
        }

        .songs-container.list {
          display: flex;
          flex-direction: column;
          gap: 1rem;
          margin-bottom: 3rem;
        }

        .song-card.grid {
          background: white;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
          transition: all 0.3s ease;
          border: 2px solid transparent;
        }

        .song-card.grid:hover {
          transform: translateY(-8px);
          box-shadow: 0 16px 48px rgba(0, 0, 0, 0.15);
          border-color: #667eea;
        }

        .song-card.list {
          background: white;
          border-radius: 12px;
          padding: 1rem;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
          display: flex;
          align-items: center;
          gap: 1.5rem;
          transition: all 0.2s;
        }

        .song-card.list:hover {
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.12);
          transform: translateY(-2px);
        }

        .song-card.list .song-thumbnail {
          width: 80px;
          height: 80px;
          flex-shrink: 0;
        }

        .song-card.list .song-info {
          flex: 1;
          padding: 0;
        }

        .song-thumbnail {
          position: relative;
          height: 220px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          overflow: hidden;
        }

        .placeholder-thumbnail {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 100%;
          height: 100%;
          font-size: 4rem;
          opacity: 0.4;
        }

        .thumbnail-icon {
          width: 4rem;
          height: 4rem;
        }

        .song-overlay {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.3);
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 1rem;
          opacity: 0;
          transition: all 0.3s ease;
        }

        .song-thumbnail:hover .song-overlay {
          opacity: 1;
        }

        .play-button {
          width: 60px;
          height: 60px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.95);
          border: none;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
          backdrop-filter: blur(10px);
        }

        .play-button:hover {
          background: white;
          transform: scale(1.1);
          box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
        }

        .play-icon {
          width: 24px;
          height: 24px;
          color: #667eea;
          margin-left: 2px;
        }

        .favorite-button {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.9);
          border: none;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s;
        }

        .favorite-button:hover {
          background: white;
          transform: scale(1.1);
        }

        .favorite-button.active {
          background: #ff6b6b;
        }

        .favorite-button.active .heart-icon {
          color: white;
        }

        .heart-icon {
          width: 20px;
          height: 20px;
          color: #ff6b6b;
        }

        .favorite-badge {
          position: absolute;
          top: 1rem;
          right: 1rem;
          background: #ffd700;
          border-radius: 50%;
          width: 32px;
          height: 32px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .star-icon {
          width: 16px;
          height: 16px;
          color: #333;
        }

        .song-info {
          padding: 1.5rem;
        }

        .song-title {
          font-size: 1.2rem;
          font-weight: bold;
          margin-bottom: 0.5rem;
          color: #333;
          line-height: 1.3;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .song-artist {
          color: #666;
          margin-bottom: 1rem;
          font-size: 1rem;
          font-weight: 500;
        }

        .song-meta {
          display: flex;
          justify-content: space-between;
          align-items: center;
          font-size: 0.9rem;
          margin-bottom: 1rem;
        }

        .song-duration {
          color: #667eea;
          font-weight: 600;
          background: rgba(102, 126, 234, 0.1);
          padding: 0.25rem 0.5rem;
          border-radius: 8px;
        }

        .song-category {
          background: linear-gradient(45deg, #667eea, #764ba2);
          color: white;
          padding: 0.3rem 0.8rem;
          border-radius: 16px;
          font-size: 0.8rem;
          text-transform: capitalize;
          font-weight: 600;
        }

        .song-actions {
          display: flex;
          gap: 0.5rem;
          margin-top: 1rem;
        }

        .action-btn {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.5rem 1rem;
          border: none;
          border-radius: 8px;
          cursor: pointer;
          font-size: 0.9rem;
          transition: all 0.2s;
          font-weight: 500;
        }

        .play-btn {
          background: #667eea;
          color: white;
        }

        .play-btn:hover {
          background: #5a6fd8;
          transform: translateY(-1px);
        }

        .favorite-btn {
          background: #f8f9fa;
          color: #666;
          border: 2px solid #e0e0e0;
        }

        .favorite-btn:hover {
          background: #ff6b6b;
          color: white;
          border-color: #ff6b6b;
        }

        .favorite-btn.active {
          background: #ff6b6b;
          color: white;
          border-color: #ff6b6b;
        }

        .btn-icon {
          width: 16px;
          height: 16px;
        }

        .no-results {
          text-align: center;
          padding: 4rem 2rem;
          color: #666;
        }

        .login-prompt {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          padding: 2rem;
          border-radius: 12px;
          text-align: center;
          margin-top: 2rem;
        }

        .loading {
          text-align: center;
          padding: 4rem;
          font-size: 1.2rem;
          color: #666;
        }

        @media (max-width: 768px) {
          .filter-controls {
            flex-direction: column;
          }

          .search-bar {
            min-width: auto;
          }

          .songs-container.grid {
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
          }
        }
      `}</style>
    </>
  );
}
