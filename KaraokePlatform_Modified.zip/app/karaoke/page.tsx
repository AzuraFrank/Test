
import DummyKaraokePlayer from '@/components/DummyKaraokePlayer';

export default function KaraokePage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-gray-50 p-10">
      <DummyKaraokePlayer />
    </main>
  );
}
