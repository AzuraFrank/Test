"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/lib/supabase";
import { ShoppingCart, Upload } from "lucide-react";

interface ShopItem {
  id: string;
  name: string;
  description: string;
  price: number;
  image_url: string | null;
  category: string;
}

export default function ShopPage() {
  const { user } = useAuth();
  const [items, setItems] = useState<ShopItem[]>([]);
  const [filteredItems, setFilteredItems] = useState<ShopItem[]>([]);
  const [cart, setCart] = useState<{ [key: string]: number }>({});
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [paymentProof, setPaymentProof] = useState<File | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState<
    "price-low" | "price-high" | "name" | "popular"
  >("name");

  useEffect(() => {
    // Initialize with sample items immediately for better UX
    setItems(sampleItems);
    setLoading(false);

    // Then try to fetch from database
    fetchShopItems();
  }, []);

  useEffect(() => {
    filterAndSortItems();
  }, [items, selectedCategory, searchTerm, sortBy]);

  const filterAndSortItems = () => {
    let filtered = items;

    // Filter by category
    if (selectedCategory !== "all") {
      filtered = filtered.filter((item) => item.category === selectedCategory);
    }

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(
        (item) =>
          item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.description.toLowerCase().includes(searchTerm.toLowerCase()),
      );
    }

    // Sort items
    filtered = [...filtered].sort((a, b) => {
      switch (sortBy) {
        case "price-low":
          return a.price - b.price;
        case "price-high":
          return b.price - a.price;
        case "name":
          return a.name.localeCompare(b.name);
        case "popular":
          return Object.keys(cart).includes(b.id) ? 1 : -1;
        default:
          return 0;
      }
    });

    setFilteredItems(filtered);
  };

  const fetchShopItems = async () => {
    try {
      const { data, error } = await supabase
        .from("shop_items")
        .select("*")
        .order("created_at", { ascending: false });

      if (!error && data && data.length > 0) {
        setItems(data);
      } else {
        // Always use sample items if database is empty or has error
        setItems(sampleItems);
      }
    } catch (err) {
      // Fallback to sample items on any error
      console.log("Using sample shop items as fallback");
      setItems(sampleItems);
    }
    setLoading(false);
  };

  const addToCart = (itemId: string) => {
    setCart((prev) => ({ ...prev, [itemId]: (prev[itemId] || 0) + 1 }));
  };

  const removeFromCart = (itemId: string) => {
    setCart((prev) => {
      const newCart = { ...prev };
      if (newCart[itemId] > 1) {
        newCart[itemId]--;
      } else {
        delete newCart[itemId];
      }
      return newCart;
    });
  };

  const getTotalAmount = () => {
    return Object.entries(cart).reduce((total, [itemId, quantity]) => {
      const item = items.find((i) => i.id === itemId);
      return total + (item ? item.price * quantity : 0);
    }, 0);
  };

  const submitOrder = async () => {
    if (!user || !paymentProof) return;

    const totalAmount = getTotalAmount();

    // Upload payment proof
    const fileName = `payment-proof-${Date.now()}.${paymentProof.name.split(".").pop()}`;
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from("payment-proofs")
      .upload(fileName, paymentProof);

    if (uploadError) {
      alert("Error uploading payment proof");
      return;
    }

    // Create orders for each item in cart
    for (const [itemId, quantity] of Object.entries(cart)) {
      const item = items.find((i) => i.id === itemId);
      if (item) {
        await supabase.from("orders").insert({
          user_id: user.id,
          item_id: itemId,
          quantity,
          total_amount: item.price * quantity,
          payment_proof: uploadData.path,
          status: "pending",
        });
      }
    }

    setCart({});
    setShowPaymentModal(false);
    setPaymentProof(null);
    alert("Pesanan berhasil dikirim! Menunggu konfirmasi admin.");
  };

  // Premium karaoke tools collection
  const sampleItems: ShopItem[] = [
    // Professional Audio Equipment
    {
      id: "1",
      name: "Microphone Wireless Professional",
      description:
        "Microphone wireless premium dengan kualitas studio, anti feedback, range 100m",
      price: 95000,
      image_url: null,
      category: "audio",
    },
    {
      id: "2",
      name: "Shure SM58 Dynamic Microphone",
      description:
        "Microphone legendaris untuk vokal, digunakan artis profesional worldwide",
      price: 85000,
      image_url: null,
      category: "audio",
    },
    {
      id: "3",
      name: "Speaker Bluetooth Premium",
      description:
        "Speaker bluetooth 50W dengan bass booster dan echo control khusus karaoke",
      price: 65000,
      image_url: null,
      category: "audio",
    },
    {
      id: "4",
      name: "Karaoke Mixer 4-Channel",
      description:
        "Mixer audio profesional dengan echo, reverb, dan vocal enhancer",
      price: 75000,
      image_url: null,
      category: "audio",
    },

    // Premium Software & Apps
    {
      id: "5",
      name: "Karaoke Pro Unlimited",
      description:
        "Akses seumur hidup ke 100,000+ lagu karaoke premium dengan lirik sinkron",
      price: 50000,
      image_url: null,
      category: "software",
    },
    {
      id: "6",
      name: "Vocal Trainer Premium",
      description:
        "AI vocal coach untuk melatih teknik bernyanyi dengan feedback real-time",
      price: 35000,
      image_url: null,
      category: "software",
    },
    {
      id: "7",
      name: "Voice Effects Studio",
      description:
        "Koleksi 50+ efek suara profesional: autotune, harmonizer, distortion",
      price: 25000,
      image_url: null,
      category: "software",
    },
    {
      id: "8",
      name: "Karaoke Recording Studio",
      description:
        "Software untuk merekam dan edit performa karaoke dengan kualitas studio",
      price: 45000,
      image_url: null,
      category: "software",
    },

    // Hardware Accessories
    {
      id: "9",
      name: "Pop Filter Professional",
      description:
        'Pop filter ganda untuk mengurangi suara "p" dan "b" saat recording',
      price: 15000,
      image_url: null,
      category: "accessories",
    },
    {
      id: "10",
      name: "Microphone Stand Heavy Duty",
      description:
        "Stand microphone adjustable dengan boom arm dan shock mount",
      price: 25000,
      image_url: null,
      category: "accessories",
    },
    {
      id: "11",
      name: "Headphones Monitor Studio",
      description:
        "Headphones monitor untuk mixing dan monitoring audio karaoke",
      price: 55000,
      image_url: null,
      category: "accessories",
    },
    {
      id: "12",
      name: "Cable XLR Premium",
      description:
        "Kabel XLR berkualitas tinggi 5 meter untuk koneksi microphone profesional",
      price: 12000,
      image_url: null,
      category: "accessories",
    },

    // Lighting & Stage Equipment
    {
      id: "13",
      name: "LED Stage Lights RGB",
      description:
        "Lampu panggung LED dengan remote control, 16 warna, efek disco",
      price: 40000,
      image_url: null,
      category: "lighting",
    },
    {
      id: "14",
      name: "Karaoke Machine Complete Set",
      description:
        "Set lengkap karaoke: speaker, mic wireless, remote, 10,000 lagu",
      price: 100000,
      image_url: null,
      category: "complete-set",
    },
    {
      id: "15",
      name: "Fog Machine Mini",
      description: "Mesin asap mini untuk efek panggung yang dramatis",
      price: 30000,
      image_url: null,
      category: "lighting",
    },

    // Digital Content & Services
    {
      id: "16",
      name: "Song Request Service",
      description:
        "Layanan request lagu custom yang tidak ada di database (max 5 lagu/bulan)",
      price: 20000,
      image_url: null,
      category: "service",
    },
    {
      id: "17",
      name: "Personal Vocal Coach Session",
      description:
        "Sesi private 1 jam dengan vocal coach profesional via video call",
      price: 80000,
      image_url: null,
      category: "service",
    },
    {
      id: "18",
      name: "Custom Backing Track",
      description: "Pembuatan backing track custom dari lagu favorit Anda",
      price: 35000,
      image_url: null,
      category: "service",
    },

    // Subscription Plans
    {
      id: "19",
      name: "Monthly Premium Subscription",
      description:
        "Akses bulanan: unlimited songs, vocal effects, no ads, priority support",
      price: 15000,
      image_url: null,
      category: "subscription",
    },
    {
      id: "20",
      name: "Yearly Premium Subscription",
      description: "Hemat 40%! Akses tahunan dengan bonus exclusive content",
      price: 99000,
      image_url: null,
      category: "subscription",
    },

    // Special Bundles
    {
      id: "21",
      name: "Starter Karaoke Bundle",
      description:
        "Paket pemula: mic wireless + speaker bluetooth + premium app (3 bulan)",
      price: 85000,
      image_url: null,
      category: "bundle",
    },
    {
      id: "22",
      name: "Professional Karaoke Bundle",
      description:
        "Paket pro: mixer + mic premium + effects software + coaching session",
      price: 200000,
      image_url: null,
      category: "bundle",
    },

    // Budget Options
    {
      id: "23",
      name: "Basic Mic Wired",
      description:
        "Microphone kabel basic untuk pemula, kualitas bagus harga terjangkau",
      price: 8000,
      image_url: null,
      category: "budget",
    },
    {
      id: "24",
      name: "Mini Speaker Portable",
      description: "Speaker mini dengan input aux, cocok untuk karaoke pribadi",
      price: 15000,
      image_url: null,
      category: "budget",
    },
    {
      id: "25",
      name: "Basic Karaoke App",
      description: "Akses basic ke 1000+ lagu popular dengan fitur standar",
      price: 5000,
      image_url: null,
      category: "budget",
    },
  ];

  const categories = [
    "all",
    "audio",
    "software",
    "accessories",
    "lighting",
    "complete-set",
    "service",
    "subscription",
    "bundle",
    "budget",
  ];

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  return (
    <>
      <div className="shop-page">
        <div className="container">
          <h1 className="page-title">🛒 Azura Premium Shop</h1>
          <p className="page-subtitle">
            Koleksi lengkap peralatan karaoke profesional grade studio - By
            Nabila Ahmad Studio Development
          </p>

          <div className="shop-controls">
            <div className="search-bar">
              <input
                type="text"
                placeholder="Cari produk karaoke..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="search-input"
              />
            </div>

            <div className="filter-controls">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="category-select"
              >
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category === "all"
                      ? "Semua Kategori"
                      : category === "complete-set"
                        ? "Complete Set"
                        : category.charAt(0).toUpperCase() + category.slice(1)}
                  </option>
                ))}
              </select>

              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="sort-select"
              >
                <option value="name">Urutkan: Nama</option>
                <option value="price-low">Harga: Terendah</option>
                <option value="price-high">Harga: Tertinggi</option>
                <option value="popular">Paling Populer</option>
              </select>
            </div>
          </div>

          <div className="results-info">
            Menampilkan {filteredItems.length} produk
          </div>

          <div className="shop-grid">
            {filteredItems.map((item) => (
              <div key={item.id} className="shop-item">
                <div className="item-image">
                  {item.image_url ? (
                    <img src={item.image_url} alt={item.name} />
                  ) : (
                    <div className="placeholder-image">
                      {item.category === "audio"
                        ? "🎤"
                        : item.category === "software"
                          ? "💻"
                          : item.category === "accessories"
                            ? "🔧"
                            : item.category === "lighting"
                              ? "💡"
                              : item.category === "service"
                                ? "👨‍🏫"
                                : item.category === "subscription"
                                  ? "⭐"
                                  : item.category === "bundle"
                                    ? "📦"
                                    : "🛍️"}
                    </div>
                  )}
                  <div className="category-badge">{item.category}</div>
                  {item.price >= 80000 && (
                    <div className="premium-badge">Premium</div>
                  )}
                </div>
                <div className="item-content">
                  <h3 className="item-name">{item.name}</h3>
                  <p className="item-description">{item.description}</p>
                  <div className="price-section">
                    <div className="item-price">
                      Rp {item.price.toLocaleString("id-ID")}
                    </div>
                    {item.price < 20000 && (
                      <div className="budget-label">Budget Friendly</div>
                    )}
                  </div>
                  <div className="item-actions">
                    {cart[item.id] > 0 && (
                      <div className="quantity-controls">
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="quantity-btn"
                        >
                          -
                        </button>
                        <span className="quantity">{cart[item.id]}</span>
                        <button
                          onClick={() => addToCart(item.id)}
                          className="quantity-btn"
                        >
                          +
                        </button>
                      </div>
                    )}
                    <button
                      onClick={() => addToCart(item.id)}
                      className="add-to-cart-btn"
                      title={!user ? "Login untuk checkout" : "Add to Cart"}
                    >
                      <ShoppingCart className="btn-icon" />
                      Add to Cart
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {Object.keys(cart).length > 0 && (
            <div className="cart-summary">
              <h3>Cart Summary</h3>
              <div className="total-amount">
                Total: Rp {getTotalAmount().toLocaleString("id-ID")}
              </div>
              <button
                onClick={() => {
                  if (!user) {
                    alert(
                      "Silakan login terlebih dahulu untuk melakukan checkout",
                    );
                    return;
                  }
                  setShowPaymentModal(true);
                }}
                className="checkout-btn"
              >
                {!user ? "Login untuk Checkout" : "Checkout"}
              </button>
            </div>
          )}

          <div className="payment-instructions">
            <h3>Cara Pembayaran</h3>
            <div className="payment-method">
              <h4>Gopay: 0895340205302</h4>
              <ol>
                <li>Transfer sesuai total belanja</li>
                <li>Screenshot bukti pembayaran</li>
                <li>Upload bukti saat checkout</li>
                <li>Tunggu konfirmasi admin</li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      {showPaymentModal && (
        <div className="modal-overlay">
          <div className="modal">
            <h3>Upload Bukti Pembayaran</h3>
            <p>Total: Rp {getTotalAmount().toLocaleString("id-ID")}</p>
            <p>Gopay: 0895340205302</p>
            <input
              type="file"
              accept="image/*"
              onChange={(e) => setPaymentProof(e.target.files?.[0] || null)}
              className="file-input"
            />
            <div className="modal-actions">
              <button
                onClick={() => setShowPaymentModal(false)}
                className="cancel-btn"
              >
                Cancel
              </button>
              <button
                onClick={submitOrder}
                disabled={!paymentProof}
                className="submit-btn"
              >
                <Upload className="btn-icon" />
                Submit Order
              </button>
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        .shop-page {
          min-height: calc(100vh - 80px);
          padding: 2rem 1rem;
          background: #f8f9fa;
        }

        .container {
          max-width: 1200px;
          margin: 0 auto;
        }

        .page-title {
          text-align: center;
          font-size: 3rem;
          margin-bottom: 1rem;
          background: linear-gradient(45deg, #667eea, #764ba2);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          font-weight: bold;
        }

        .page-subtitle {
          text-align: center;
          font-size: 1.2rem;
          color: #666;
          margin-bottom: 3rem;
          max-width: 600px;
          margin-left: auto;
          margin-right: auto;
        }

        .shop-controls {
          margin-bottom: 2rem;
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }

        .search-bar {
          width: 100%;
        }

        .search-input {
          width: 100%;
          padding: 1rem 1.5rem;
          border: 2px solid #e0e0e0;
          border-radius: 12px;
          font-size: 1rem;
          transition: all 0.2s;
          background: white;
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        .search-input:focus {
          border-color: #667eea;
          outline: none;
          box-shadow: 0 4px 20px rgba(102, 126, 234, 0.15);
        }

        .filter-controls {
          display: flex;
          gap: 1rem;
          flex-wrap: wrap;
        }

        .category-select,
        .sort-select {
          padding: 0.75rem 1rem;
          border: 2px solid #e0e0e0;
          border-radius: 8px;
          font-size: 1rem;
          background: white;
          min-width: 180px;
          transition: all 0.2s;
        }

        .category-select:focus,
        .sort-select:focus {
          border-color: #667eea;
          outline: none;
        }

        .results-info {
          margin-bottom: 2rem;
          color: #666;
          font-weight: 500;
          font-size: 1rem;
        }

        .shop-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
          gap: 2rem;
          margin-bottom: 3rem;
        }

        .shop-item {
          background: white;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
          transition: all 0.3s ease;
          border: 2px solid transparent;
          position: relative;
        }

        .shop-item:hover {
          transform: translateY(-8px);
          box-shadow: 0 16px 48px rgba(0, 0, 0, 0.15);
          border-color: #667eea;
        }

        .item-image {
          height: 220px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
          position: relative;
          overflow: hidden;
        }

        .placeholder-image {
          font-size: 4rem;
          opacity: 0.6;
        }

        .category-badge {
          position: absolute;
          top: 1rem;
          left: 1rem;
          background: rgba(102, 126, 234, 0.9);
          color: white;
          padding: 0.25rem 0.75rem;
          border-radius: 12px;
          font-size: 0.8rem;
          font-weight: 600;
          text-transform: capitalize;
          backdrop-filter: blur(10px);
        }

        .premium-badge {
          position: absolute;
          top: 1rem;
          right: 1rem;
          background: linear-gradient(45deg, #ffd700, #ffed4e);
          color: #333;
          padding: 0.25rem 0.75rem;
          border-radius: 12px;
          font-size: 0.8rem;
          font-weight: bold;
          animation: shimmer 2s infinite;
        }

        @keyframes shimmer {
          0%,
          100% {
            opacity: 1;
          }
          50% {
            opacity: 0.8;
          }
        }

        .item-content {
          padding: 1.5rem;
        }

        .item-name {
          font-size: 1.3rem;
          font-weight: bold;
          margin-bottom: 0.75rem;
          color: #333;
          line-height: 1.3;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }

        .item-description {
          color: #666;
          line-height: 1.6;
          margin-bottom: 1.5rem;
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
          font-size: 0.95rem;
        }

        .price-section {
          margin-bottom: 1rem;
        }

        .item-price {
          font-size: 1.5rem;
          font-weight: bold;
          background: linear-gradient(45deg, #667eea, #764ba2);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          margin-bottom: 0.5rem;
        }

        .budget-label {
          display: inline-block;
          background: #4ecdc4;
          color: white;
          padding: 0.25rem 0.5rem;
          border-radius: 8px;
          font-size: 0.8rem;
          font-weight: 600;
        }

        .item-actions {
          display: flex;
          gap: 1rem;
          align-items: center;
        }

        .quantity-controls {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .quantity-btn {
          width: 30px;
          height: 30px;
          border: 1px solid #ddd;
          background: white;
          border-radius: 4px;
          cursor: pointer;
        }

        .quantity {
          min-width: 20px;
          text-align: center;
          font-weight: bold;
        }

        .add-to-cart-btn {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.5rem 1rem;
          background: #667eea;
          color: white;
          border: none;
          border-radius: 8px;
          cursor: pointer;
          transition: background-color 0.2s;
        }

        .add-to-cart-btn:hover:not(:disabled) {
          background: #5a6fd8;
        }

        .add-to-cart-btn:disabled {
          background: #667eea;
          cursor: pointer;
        }

        .btn-icon {
          width: 16px;
          height: 16px;
        }

        .cart-summary {
          background: white;
          padding: 2rem;
          border-radius: 12px;
          text-align: center;
          margin-bottom: 2rem;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .total-amount {
          font-size: 1.5rem;
          font-weight: bold;
          color: #667eea;
          margin: 1rem 0;
        }

        .checkout-btn {
          padding: 1rem 2rem;
          background: #ff6b6b;
          color: white;
          border: none;
          border-radius: 8px;
          font-size: 1.1rem;
          cursor: pointer;
          transition: background-color 0.2s;
        }

        .checkout-btn:hover {
          background: #ff5252;
        }

        .payment-instructions {
          background: white;
          padding: 2rem;
          border-radius: 12px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .payment-method h4 {
          color: #667eea;
          margin-bottom: 1rem;
        }

        .payment-method ol {
          line-height: 1.8;
          color: #666;
        }

        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.5);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
        }

        .modal {
          background: white;
          padding: 2rem;
          border-radius: 12px;
          max-width: 400px;
          width: 90%;
        }

        .file-input {
          width: 100%;
          padding: 0.5rem;
          border: 1px solid #ddd;
          border-radius: 4px;
          margin: 1rem 0;
        }

        .modal-actions {
          display: flex;
          gap: 1rem;
          justify-content: flex-end;
        }

        .cancel-btn {
          padding: 0.5rem 1rem;
          background: #ccc;
          color: #333;
          border: none;
          border-radius: 4px;
          cursor: pointer;
        }

        .submit-btn {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.5rem 1rem;
          background: #667eea;
          color: white;
          border: none;
          border-radius: 4px;
          cursor: pointer;
        }

        .submit-btn:disabled {
          background: #ccc;
          cursor: not-allowed;
        }

        .loading {
          text-align: center;
          padding: 4rem;
          font-size: 1.2rem;
          color: #666;
        }
      `}</style>
    </>
  );
}
