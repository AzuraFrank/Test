import type { Metadata } from "next";
import { AuthProvider } from "@/contexts/AuthContext";
import Navigation from "@/components/Navigation";
import "./globals.css";

export const metadata: Metadata = {
  title: "Azura Karaoke Streaming By Nabila Ahmad Studio Development",
  description:
    "Platform karaoke streaming terbaik dengan 50,000+ lagu premium dan tools profesional - By Nabila Ahmad Studio Development",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <AuthProvider>
          <Navigation />
          {children}
        </AuthProvider>
      </body>
    </html>
  );
}
