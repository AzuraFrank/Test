"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/lib/supabase";
import { Camera, Save, User, Mail, Calendar } from "lucide-react";

export default function ProfilePage() {
  const { user, profile } = useAuth();
  const [fullName, setFullName] = useState("");
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarUrl, setAvatarUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [posts, setPosts] = useState<any[]>([]);
  const [newPost, setNewPost] = useState("");

  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name || "");
      setAvatarUrl(profile.avatar_url || "");
    }
    fetchPosts();
  }, [profile]);

  const fetchPosts = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from("posts")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (!error && data) {
      setPosts(data);
    }
  };

  const updateProfile = async () => {
    if (!user) return;

    setLoading(true);

    let newAvatarUrl = avatarUrl;

    // Upload new avatar if selected
    if (avatarFile) {
      const fileName = `avatar-${user.id}-${Date.now()}.${avatarFile.name.split(".").pop()}`;
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from("avatars")
        .upload(fileName, avatarFile);

      if (!uploadError && uploadData) {
        const {
          data: { publicUrl },
        } = supabase.storage.from("avatars").getPublicUrl(uploadData.path);
        newAvatarUrl = publicUrl;
      }
    }

    // Update profile
    const { error } = await supabase.from("profiles").upsert({
      id: user.id,
      email: user.email!,
      full_name: fullName,
      avatar_url: newAvatarUrl,
      role: profile?.role || "user",
    });

    if (!error) {
      alert("Profile updated successfully!");
      setAvatarUrl(newAvatarUrl);
      setAvatarFile(null);
    } else {
      alert("Error updating profile");
    }

    setLoading(false);
  };

  const createPost = async () => {
    if (!user || !newPost.trim()) return;

    const { error } = await supabase.from("posts").insert({
      user_id: user.id,
      content: newPost,
      created_at: new Date().toISOString(),
    });

    if (!error) {
      setNewPost("");
      fetchPosts();
    }
  };

  const handleAvatarChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setAvatarFile(file);
      // Preview the image
      const reader = new FileReader();
      reader.onload = (e) => {
        setAvatarUrl(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  if (!user) {
    return (
      <div className="profile-page">
        <div className="container">
          <div className="login-required">
            <h2>Login Required</h2>
            <p>Please log in to view your profile</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="profile-page">
        <div className="container">
          <h1 className="page-title">My Profile</h1>

          <div className="profile-section">
            <div className="profile-card">
              <div className="avatar-section">
                <div className="avatar-container">
                  {avatarUrl ? (
                    <img src={avatarUrl} alt="Avatar" className="avatar" />
                  ) : (
                    <div className="avatar-placeholder">
                      <User className="avatar-icon" />
                    </div>
                  )}
                  <label className="avatar-upload">
                    <Camera className="camera-icon" />
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleAvatarChange}
                      style={{ display: "none" }}
                    />
                  </label>
                </div>
              </div>

              <div className="profile-form">
                <div className="form-group">
                  <label className="form-label">
                    <User className="form-icon" />
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="form-input"
                    placeholder="Enter your full name"
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">
                    <Mail className="form-icon" />
                    Email
                  </label>
                  <input
                    type="email"
                    value={user.email || ""}
                    disabled
                    className="form-input disabled"
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">
                    <Calendar className="form-icon" />
                    Member Since
                  </label>
                  <input
                    type="text"
                    value={new Date(user.created_at).toLocaleDateString()}
                    disabled
                    className="form-input disabled"
                  />
                </div>

                <button
                  onClick={updateProfile}
                  disabled={loading}
                  className="save-button"
                >
                  <Save className="button-icon" />
                  {loading ? "Saving..." : "Save Changes"}
                </button>
              </div>
            </div>
          </div>

          <div className="posts-section">
            <h2>My Posts</h2>

            <div className="new-post">
              <textarea
                value={newPost}
                onChange={(e) => setNewPost(e.target.value)}
                placeholder="What's on your mind about karaoke?"
                className="post-textarea"
                rows={3}
              />
              <button
                onClick={createPost}
                disabled={!newPost.trim()}
                className="post-button"
              >
                Post
              </button>
            </div>

            <div className="posts-list">
              {posts.length === 0 ? (
                <div className="no-posts">
                  <p>No posts yet. Share your first karaoke experience!</p>
                </div>
              ) : (
                posts.map((post) => (
                  <div key={post.id} className="post-card">
                    <div className="post-header">
                      <div className="post-avatar">
                        {avatarUrl ? (
                          <img src={avatarUrl} alt="Avatar" />
                        ) : (
                          <User className="post-avatar-icon" />
                        )}
                      </div>
                      <div className="post-info">
                        <h4>{fullName || user.email}</h4>
                        <p>{new Date(post.created_at).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <div className="post-content">{post.content}</div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .profile-page {
          min-height: calc(100vh - 80px);
          padding: 2rem 1rem;
          background: #f8f9fa;
        }

        .container {
          max-width: 800px;
          margin: 0 auto;
        }

        .page-title {
          text-align: center;
          font-size: 2.5rem;
          margin-bottom: 3rem;
          color: #333;
        }

        .login-required {
          text-align: center;
          padding: 4rem 2rem;
          background: white;
          border-radius: 12px;
          color: #666;
        }

        .profile-section {
          margin-bottom: 3rem;
        }

        .profile-card {
          background: white;
          padding: 2rem;
          border-radius: 12px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .avatar-section {
          text-align: center;
          margin-bottom: 2rem;
        }

        .avatar-container {
          position: relative;
          display: inline-block;
        }

        .avatar {
          width: 120px;
          height: 120px;
          border-radius: 50%;
          object-fit: cover;
          border: 4px solid #667eea;
        }

        .avatar-placeholder {
          width: 120px;
          height: 120px;
          border-radius: 50%;
          background: #eee;
          display: flex;
          align-items: center;
          justify-content: center;
          border: 4px solid #667eea;
        }

        .avatar-icon {
          width: 40px;
          height: 40px;
          color: #666;
        }

        .avatar-upload {
          position: absolute;
          bottom: 0;
          right: 0;
          width: 40px;
          height: 40px;
          background: #667eea;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: background-color 0.2s;
        }

        .avatar-upload:hover {
          background: #5a6fd8;
        }

        .camera-icon {
          width: 20px;
          height: 20px;
          color: white;
        }

        .profile-form {
          display: flex;
          flex-direction: column;
          gap: 1.5rem;
        }

        .form-group {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }

        .form-label {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-weight: 500;
          color: #333;
        }

        .form-icon {
          width: 18px;
          height: 18px;
          color: #667eea;
        }

        .form-input {
          padding: 0.75rem;
          border: 1px solid #ddd;
          border-radius: 8px;
          font-size: 1rem;
        }

        .form-input.disabled {
          background: #f8f9fa;
          color: #666;
        }

        .save-button {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          padding: 1rem;
          background: #667eea;
          color: white;
          border: none;
          border-radius: 8px;
          font-size: 1rem;
          cursor: pointer;
          transition: background-color 0.2s;
        }

        .save-button:hover:not(:disabled) {
          background: #5a6fd8;
        }

        .save-button:disabled {
          background: #ccc;
          cursor: not-allowed;
        }

        .button-icon {
          width: 18px;
          height: 18px;
        }

        .posts-section h2 {
          margin-bottom: 1.5rem;
          color: #333;
        }

        .new-post {
          background: white;
          padding: 1.5rem;
          border-radius: 12px;
          margin-bottom: 2rem;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .post-textarea {
          width: 100%;
          padding: 1rem;
          border: 1px solid #ddd;
          border-radius: 8px;
          resize: vertical;
          font-family: inherit;
          margin-bottom: 1rem;
        }

        .post-button {
          padding: 0.5rem 1.5rem;
          background: #667eea;
          color: white;
          border: none;
          border-radius: 8px;
          cursor: pointer;
          transition: background-color 0.2s;
        }

        .post-button:hover:not(:disabled) {
          background: #5a6fd8;
        }

        .post-button:disabled {
          background: #ccc;
          cursor: not-allowed;
        }

        .posts-list {
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }

        .no-posts {
          text-align: center;
          padding: 2rem;
          color: #666;
          background: white;
          border-radius: 12px;
        }

        .post-card {
          background: white;
          padding: 1.5rem;
          border-radius: 12px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .post-header {
          display: flex;
          align-items: center;
          gap: 1rem;
          margin-bottom: 1rem;
        }

        .post-avatar img {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          object-fit: cover;
        }

        .post-avatar-icon {
          width: 40px;
          height: 40px;
          color: #666;
        }

        .post-info h4 {
          margin: 0;
          color: #333;
        }

        .post-info p {
          margin: 0;
          color: #666;
          font-size: 0.9rem;
        }

        .post-content {
          line-height: 1.6;
          color: #333;
        }
      `}</style>
    </>
  );
}
