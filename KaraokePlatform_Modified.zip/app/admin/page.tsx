"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/lib/supabase";
import {
  Shield,
  CheckCircle,
  XCircle,
  Eye,
  Package,
  Users,
  Music,
} from "lucide-react";

interface Order {
  id: string;
  user_id: string;
  item_id: string;
  quantity: number;
  total_amount: number;
  payment_proof: string | null;
  status: "pending" | "confirmed" | "delivered";
  created_at: string;
  profiles: { full_name: string | null; email: string };
  shop_items: { name: string };
}

export default function AdminPage() {
  const { user, profile } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [stats, setStats] = useState({
    totalOrders: 0,
    pendingOrders: 0,
    totalRevenue: 0,
    totalUsers: 0,
  });
  const [selectedProof, setSelectedProof] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (profile?.role === "admin") {
      fetchOrders();
      fetchStats();
    }
  }, [profile]);

  const fetchOrders = async () => {
    const { data, error } = await supabase
      .from("orders")
      .select(
        `
        *,
        profiles (full_name, email),
        shop_items (name)
      `,
      )
      .order("created_at", { ascending: false });

    if (!error && data) {
      setOrders(data);
    }
    setLoading(false);
  };

  const fetchStats = async () => {
    // Fetch total orders
    const { count: totalOrders } = await supabase
      .from("orders")
      .select("*", { count: "exact", head: true });

    // Fetch pending orders
    const { count: pendingOrders } = await supabase
      .from("orders")
      .select("*", { count: "exact", head: true })
      .eq("status", "pending");

    // Fetch total revenue
    const { data: revenueData } = await supabase
      .from("orders")
      .select("total_amount")
      .eq("status", "confirmed");

    const totalRevenue =
      revenueData?.reduce((sum, order) => sum + order.total_amount, 0) || 0;

    // Fetch total users
    const { count: totalUsers } = await supabase
      .from("profiles")
      .select("*", { count: "exact", head: true });

    setStats({
      totalOrders: totalOrders || 0,
      pendingOrders: pendingOrders || 0,
      totalRevenue,
      totalUsers: totalUsers || 0,
    });
  };

  const updateOrderStatus = async (
    orderId: string,
    status: "confirmed" | "delivered",
  ) => {
    const { error } = await supabase
      .from("orders")
      .update({ status })
      .eq("id", orderId);

    if (!error) {
      fetchOrders();
      fetchStats();
      alert(`Order ${status} successfully!`);
    } else {
      alert("Error updating order status");
    }
  };

  const viewPaymentProof = (proofUrl: string) => {
    if (proofUrl.startsWith("payment-proof-")) {
      // Get public URL from storage
      const { data } = supabase.storage
        .from("payment-proofs")
        .getPublicUrl(proofUrl);
      setSelectedProof(data.publicUrl);
    } else {
      setSelectedProof(proofUrl);
    }
  };

  // Sample admin account setup
  useEffect(() => {
    const setupAdminAccount = async () => {
      if (user?.email === "jesikamahjong@gmail.com") {
        const { error } = await supabase.from("profiles").upsert({
          id: user.id,
          email: user.email,
          full_name: "Admin Jesika",
          role: "admin",
        });
      }
    };

    if (user) {
      setupAdminAccount();
    }
  }, [user]);

  if (!user) {
    return (
      <div className="admin-page">
        <div className="container">
          <div className="access-denied">
            <h2>Access Denied</h2>
            <p>Please log in to access admin panel</p>
          </div>
        </div>
      </div>
    );
  }

  if (profile?.role !== "admin") {
    return (
      <div className="admin-page">
        <div className="container">
          <div className="access-denied">
            <h2>Access Denied</h2>
            <p>You don't have permission to access this page</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="admin-page">
        <div className="container">
          <div className="admin-header">
            <h1 className="page-title">
              <Shield className="title-icon" />
              Admin Dashboard
            </h1>
            <p className="admin-info">
              Welcome, {profile.full_name || user.email}
            </p>
          </div>

          <div className="stats-grid">
            <div className="stat-card">
              <Package className="stat-icon" />
              <div className="stat-content">
                <h3>Total Orders</h3>
                <p className="stat-number">{stats.totalOrders}</p>
              </div>
            </div>
            <div className="stat-card pending">
              <XCircle className="stat-icon" />
              <div className="stat-content">
                <h3>Pending Orders</h3>
                <p className="stat-number">{stats.pendingOrders}</p>
              </div>
            </div>
            <div className="stat-card revenue">
              <CheckCircle className="stat-icon" />
              <div className="stat-content">
                <h3>Total Revenue</h3>
                <p className="stat-number">
                  Rp {stats.totalRevenue.toLocaleString("id-ID")}
                </p>
              </div>
            </div>
            <div className="stat-card users">
              <Users className="stat-icon" />
              <div className="stat-content">
                <h3>Total Users</h3>
                <p className="stat-number">{stats.totalUsers}</p>
              </div>
            </div>
          </div>

          <div className="orders-section">
            <h2>Order Management</h2>

            {loading ? (
              <div className="loading">Loading orders...</div>
            ) : orders.length === 0 ? (
              <div className="no-orders">
                <p>No orders found</p>
              </div>
            ) : (
              <div className="orders-table">
                {orders.map((order) => (
                  <div key={order.id} className={`order-card ${order.status}`}>
                    <div className="order-header">
                      <div className="order-id">#{order.id.slice(0, 8)}</div>
                      <div className={`order-status ${order.status}`}>
                        {order.status.toUpperCase()}
                      </div>
                    </div>

                    <div className="order-details">
                      <div className="order-info">
                        <p>
                          <strong>Customer:</strong>{" "}
                          {order.profiles.full_name || order.profiles.email}
                        </p>
                        <p>
                          <strong>Item:</strong> {order.shop_items.name}
                        </p>
                        <p>
                          <strong>Quantity:</strong> {order.quantity}
                        </p>
                        <p>
                          <strong>Amount:</strong> Rp{" "}
                          {order.total_amount.toLocaleString("id-ID")}
                        </p>
                        <p>
                          <strong>Date:</strong>{" "}
                          {new Date(order.created_at).toLocaleDateString()}
                        </p>
                      </div>

                      <div className="order-actions">
                        {order.payment_proof && (
                          <button
                            onClick={() =>
                              viewPaymentProof(order.payment_proof!)
                            }
                            className="action-btn view-btn"
                          >
                            <Eye className="btn-icon" />
                            View Proof
                          </button>
                        )}

                        {order.status === "pending" && (
                          <button
                            onClick={() =>
                              updateOrderStatus(order.id, "confirmed")
                            }
                            className="action-btn confirm-btn"
                          >
                            <CheckCircle className="btn-icon" />
                            Confirm
                          </button>
                        )}

                        {order.status === "confirmed" && (
                          <button
                            onClick={() =>
                              updateOrderStatus(order.id, "delivered")
                            }
                            className="action-btn deliver-btn"
                          >
                            <Package className="btn-icon" />
                            Mark Delivered
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="payment-info">
            <h3>Payment Information</h3>
            <div className="payment-details">
              <p>
                <strong>Gopay:</strong> 0895340205302
              </p>
              <p>
                All payments should be made to this number. Confirm orders after
                verifying payment proof.
              </p>
            </div>
          </div>
        </div>
      </div>

      {selectedProof && (
        <div className="modal-overlay" onClick={() => setSelectedProof(null)}>
          <div className="proof-modal" onClick={(e) => e.stopPropagation()}>
            <img
              src={selectedProof}
              alt="Payment Proof"
              className="proof-image"
            />
            <button
              onClick={() => setSelectedProof(null)}
              className="close-modal"
            >
              ×
            </button>
          </div>
        </div>
      )}

      <style jsx>{`
        .admin-page {
          min-height: calc(100vh - 80px);
          padding: 2rem 1rem;
          background: #f8f9fa;
        }

        .container {
          max-width: 1200px;
          margin: 0 auto;
        }

        .admin-header {
          text-align: center;
          margin-bottom: 3rem;
        }

        .page-title {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 1rem;
          font-size: 2.5rem;
          margin-bottom: 0.5rem;
          color: #333;
        }

        .title-icon {
          width: 2.5rem;
          height: 2.5rem;
          color: #ffd700;
        }

        .admin-info {
          color: #666;
          font-size: 1.1rem;
        }

        .access-denied {
          text-align: center;
          padding: 4rem 2rem;
          background: white;
          border-radius: 12px;
          color: #666;
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 1.5rem;
          margin-bottom: 3rem;
        }

        .stat-card {
          background: white;
          padding: 1.5rem;
          border-radius: 12px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
          display: flex;
          align-items: center;
          gap: 1rem;
        }

        .stat-card.pending {
          border-left: 4px solid #ff6b6b;
        }

        .stat-card.revenue {
          border-left: 4px solid #4ecdc4;
        }

        .stat-card.users {
          border-left: 4px solid #667eea;
        }

        .stat-icon {
          width: 2.5rem;
          height: 2.5rem;
          color: #667eea;
        }

        .stat-content h3 {
          margin: 0 0 0.5rem 0;
          color: #333;
          font-size: 0.9rem;
          text-transform: uppercase;
          font-weight: 600;
        }

        .stat-number {
          margin: 0;
          font-size: 1.8rem;
          font-weight: bold;
          color: #667eea;
        }

        .orders-section h2 {
          margin-bottom: 1.5rem;
          color: #333;
        }

        .loading,
        .no-orders {
          text-align: center;
          padding: 2rem;
          color: #666;
          background: white;
          border-radius: 12px;
        }

        .orders-table {
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }

        .order-card {
          background: white;
          padding: 1.5rem;
          border-radius: 12px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
          border-left: 4px solid #ddd;
        }

        .order-card.pending {
          border-left-color: #ff6b6b;
        }

        .order-card.confirmed {
          border-left-color: #ffd700;
        }

        .order-card.delivered {
          border-left-color: #4ecdc4;
        }

        .order-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1rem;
          padding-bottom: 1rem;
          border-bottom: 1px solid #eee;
        }

        .order-id {
          font-family: monospace;
          font-weight: bold;
          color: #333;
        }

        .order-status {
          padding: 0.25rem 0.75rem;
          border-radius: 12px;
          font-size: 0.8rem;
          font-weight: bold;
        }

        .order-status.pending {
          background: #ffe6e6;
          color: #ff6b6b;
        }

        .order-status.confirmed {
          background: #fff8e1;
          color: #ffd700;
        }

        .order-status.delivered {
          background: #e6fffd;
          color: #4ecdc4;
        }

        .order-details {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 2rem;
        }

        .order-info {
          flex: 1;
        }

        .order-info p {
          margin: 0.5rem 0;
          color: #666;
        }

        .order-actions {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
          min-width: 140px;
        }

        .action-btn {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          padding: 0.5rem 1rem;
          border: none;
          border-radius: 6px;
          cursor: pointer;
          font-size: 0.9rem;
          transition: background-color 0.2s;
        }

        .view-btn {
          background: #667eea;
          color: white;
        }

        .view-btn:hover {
          background: #5a6fd8;
        }

        .confirm-btn {
          background: #4ecdc4;
          color: white;
        }

        .confirm-btn:hover {
          background: #45b7aa;
        }

        .deliver-btn {
          background: #ffd700;
          color: #333;
        }

        .deliver-btn:hover {
          background: #ffed4e;
        }

        .btn-icon {
          width: 16px;
          height: 16px;
        }

        .payment-info {
          background: white;
          padding: 2rem;
          border-radius: 12px;
          margin-top: 3rem;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .payment-details p {
          margin: 0.5rem 0;
          color: #666;
        }

        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.8);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
        }

        .proof-modal {
          position: relative;
          max-width: 90vw;
          max-height: 90vh;
        }

        .proof-image {
          max-width: 100%;
          max-height: 100%;
          border-radius: 8px;
        }

        .close-modal {
          position: absolute;
          top: -10px;
          right: -10px;
          width: 30px;
          height: 30px;
          border-radius: 50%;
          background: white;
          border: none;
          font-size: 1.5rem;
          cursor: pointer;
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
        }

        @media (max-width: 768px) {
          .order-details {
            flex-direction: column;
            gap: 1rem;
          }

          .order-actions {
            flex-direction: row;
            min-width: auto;
          }
        }
      `}</style>
    </>
  );
}
